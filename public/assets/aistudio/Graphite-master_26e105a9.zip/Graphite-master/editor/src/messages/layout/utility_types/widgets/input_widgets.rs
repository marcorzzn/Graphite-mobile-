use crate::messages::frontend::IconName;
use crate::messages::input_mapper::utility_types::misc::ActionShortcut;
use crate::messages::layout::utility_types::widget_prelude::*;
use crate::messages::message::Message;
use crate::messages::portfolio::document::node_graph::document_node_definitions::DefinitionIdentifier;
use derivative::*;
use graphene_std::Color;
use graphene_std::color::SRGBA8;
use graphene_std::transform::ReferencePoint;
use graphene_std::vector::style::{FillChoice, GradientHueDirection, GradientInterpolation, GradientSpace, GradientStops};
use graphite_proc_macros::WidgetBuilder;

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, Default, PartialEq)]
pub struct CheckboxInput {
	// Content
	#[widget_builder(constructor)]
	pub checked: bool,
	#[widget_builder(string)]
	pub icon: Option<IconName>,
	#[serde(rename = "forLabel")]
	pub for_label: CheckboxId,
	pub disabled: bool,
	pub mixed: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<CheckboxInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash, serde::Serialize, serde::Deserialize)]
pub struct CheckboxId(pub u64);

impl CheckboxId {
	pub fn new() -> Self {
		Self(graphene_std::uuid::generate_uuid())
	}
}
impl Default for CheckboxId {
	fn default() -> Self {
		Self::new()
	}
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct DropdownInput {
	// Content
	// This uses `u32` instead of `usize` since it will be serialized as a normal JS number (we can replace this with `usize` if we switch to a Rust-based GUI)
	#[serde(rename = "selectedIndex")]
	pub selected_index: Option<u32>,
	#[serde(rename = "drawIcon")]
	pub draw_icon: bool,
	pub disabled: bool,

	// Children
	#[widget_builder(constructor)]
	pub entries: MenuListEntrySections,
	#[serde(rename = "entriesHash")]
	#[widget_builder(skip)]
	pub entries_hash: u64,

	// Styling
	pub narrow: bool,
	pub sizing: WidgetSizing,
	// Sized to the selected entry, rather than the widest, so its width changes with the selection
	#[serde(rename = "sizedToSelection")]
	pub sized_to_selection: bool,

	// Behavior
	#[serde(rename = "virtualScrolling")]
	pub virtual_scrolling: bool,
	// Set along with the `on_file_drop` callback
	#[serde(rename = "takesFileDrop")]
	#[widget_builder(skip)]
	pub takes_file_drop: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	#[widget_builder(skip)]
	pub on_file_drop: WidgetCallback<DroppedFile>,
}

impl DropdownInput {
	/// Makes the widget take a file dropped on it, which is handed to the callback.
	pub fn on_file_drop(mut self, callback: impl Fn(&DroppedFile) -> Message + 'static + Send + Sync) -> Self {
		self.takes_file_drop = true;
		self.on_file_drop = WidgetCallback::new(callback);
		self
	}
}

#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct DroppedFile {
	pub name: String,
	pub mime_type: String,
	pub data: Vec<u8>,
}

pub type MenuListEntrySections = Vec<Vec<MenuListEntry>>;

#[cfg_attr(feature = "wasm", derive(tsify::Tsify), tsify(large_number_types_as_bigints))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, Default, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
#[widget_builder(not_widget_instance)]
pub struct MenuListEntry {
	// Content
	#[widget_builder(constructor)]
	pub value: String,
	pub label: String,
	#[widget_builder(string)]
	pub icon: Option<IconName>,
	/// Text at the row's right end, in the place of a shortcut, like the name of a completion.
	pub annotation: String,
	pub disabled: bool,

	// Children
	pub children: MenuListEntrySections,
	#[serde(rename = "childrenHash")]
	#[widget_builder(skip)]
	pub children_hash: u64,

	// Styling
	pub font: Option<String>,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,
	/// Code at the right of the tooltip's header, like a completion's signature.
	#[serde(rename = "tooltipCode")]
	pub tooltip_code: String,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<()>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

impl std::hash::Hash for MenuListEntry {
	fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
		self.value.hash(state);
		self.label.hash(state);
		self.icon.hash(state);
		self.annotation.hash(state);
		self.disabled.hash(state);
	}
}

impl MenuListEntry {
	/// One entry per variant of a choice type enum, keeping the choice type's section groupings, shown as the variant's label alongside its icon when it has one.
	pub fn sections_from_choice_type<E>(to_message: impl Fn(E) -> Message + Clone + Send + Sync + 'static) -> MenuListEntrySections
	where
		E: graphene_std::choice_type::ChoiceTypeStatic + 'static,
	{
		E::list()
			.iter()
			.map(|section| {
				section
					.iter()
					.map(|(variant, metadata)| {
						let to_message = to_message.clone();
						let variant = *variant;

						let entry = MenuListEntry::new(metadata.name)
							.label(metadata.label)
							.tooltip_label(metadata.label)
							.tooltip_description(metadata.description.unwrap_or_default())
							.on_update(move |_| to_message(variant));

						if let Some(icon) = metadata.icon { entry.icon(icon) } else { entry }
					})
					.collect()
			})
			.collect()
	}
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct NumberInput {
	// Content
	#[widget_builder(constructor)]
	pub value: Option<f64>,
	pub label: String,
	pub disabled: bool,

	// Styling
	pub narrow: bool,
	pub sizing: WidgetSizing,

	// Behavior
	pub mode: NumberInputMode,
	#[widget_builder(skip)]
	pub min: Option<f64>,
	#[widget_builder(skip)]
	pub max: Option<f64>,
	// TODO: Make this (and range_max) apply to both Range and Increment modes when dragging with the mouse
	#[serde(rename = "rangeMin")]
	pub range_min: Option<f64>,
	#[serde(rename = "rangeMax")]
	pub range_max: Option<f64>,
	#[derivative(Default(value = "1."))]
	pub step: f64,
	#[serde(rename = "isInteger")]
	pub is_integer: bool,
	#[serde(rename = "incrementBehavior")]
	pub increment_behavior: NumberInputIncrementBehavior,
	#[serde(rename = "displayDecimalPlaces")]
	#[derivative(Default(value = "2"))]
	pub display_decimal_places: u32,
	pub unit: String,
	#[serde(rename = "unitIsHiddenWhenEditing")]
	#[derivative(Default(value = "true"))]
	pub unit_is_hidden_when_editing: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub increment_callback_increase: WidgetCallback<NumberInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub increment_callback_decrease: WidgetCallback<NumberInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<NumberInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

impl NumberInput {
	pub fn int(mut self) -> Self {
		self.is_integer = true;
		self
	}
	pub fn min(mut self, val: f64) -> Self {
		self.min = Some(val);
		self.range_min = Some(val);
		self
	}
	pub fn max(mut self, val: f64) -> Self {
		self.max = Some(val);
		self.range_max = Some(val);
		self
	}
	pub fn mode_range(mut self) -> Self {
		self.mode = NumberInputMode::Range;
		self
	}
	pub fn mode_increment(mut self) -> Self {
		self.mode = NumberInputMode::Increment;
		self
	}
	pub fn increment_step(mut self, step: f64) -> Self {
		self.step = step;
		self
	}
	pub fn percentage(self) -> Self {
		self.min(0.).max(100.).mode_range().unit("%").display_decimal_places(2)
	}
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Debug, Default, PartialEq, Eq)]
pub enum NumberInputIncrementBehavior {
	/// The value is added by `step`.
	#[default]
	Add,
	/// The value is multiplied by `step`.
	Multiply,
	/// The functions `incrementCallbackIncrease` and `incrementCallbackDecrease` call custom behavior.
	Callback,
	/// The increment arrows are not shown.
	None,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Debug, Default, PartialEq, Eq)]
pub enum NumberInputMode {
	#[default]
	Increment,
	Range,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct NodeCatalog {
	// Content
	pub disabled: bool,

	// Behavior
	#[serde(rename = "initialSearchTerm")]
	pub initial_search: String,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<DefinitionIdentifier>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Default, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct RadioInput {
	// Content
	// This uses `u32` instead of `usize` since it will be serialized as a normal JS number (replace this with `usize` after switching to a Rust-based GUI)
	#[serde(rename = "selectedIndex")]
	pub selected_index: Option<u32>,
	pub disabled: bool,

	// Children
	#[widget_builder(constructor)]
	pub entries: Vec<RadioEntryData>,

	// Styling
	pub narrow: bool,
	pub sizing: WidgetSizing,
	//
	// Callbacks exists on the `RadioEntryData` children, not this parent `RadioInput`
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Default, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
#[widget_builder(not_widget_instance)]
pub struct RadioEntryData {
	// Content
	#[widget_builder(constructor)]
	pub value: String,
	pub label: String,
	#[widget_builder(string)]
	pub icon: Option<IconName>,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<()>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

impl RadioEntryData {
	/// One entry per variant of a choice type enum, shown as the variant's icon when it has one and its text label otherwise.
	pub fn list_from_choice_type<E>(to_message: impl Fn(E) -> Message + Clone + Send + Sync + 'static) -> Vec<Self>
	where
		E: graphene_std::choice_type::ChoiceTypeStatic + 'static,
	{
		E::list()
			.iter()
			.flat_map(|section| section.iter())
			.map(|(variant, metadata)| {
				let to_message = to_message.clone();
				let variant = *variant;

				let entry = RadioEntryData::new(metadata.name)
					.tooltip_label(metadata.label)
					.tooltip_description(metadata.description.unwrap_or_default())
					.on_update(move |_| to_message(variant));

				if let Some(icon) = metadata.icon { entry.icon(icon) } else { entry.label(metadata.label) }
			})
			.collect()
	}
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct WorkingColorsInput {
	// Content
	#[widget_builder(constructor)]
	pub primary: SRGBA8,
	#[widget_builder(constructor)]
	pub secondary: SRGBA8,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct TextAreaInput {
	// Content
	#[widget_builder(constructor)]
	pub value: String,
	pub label: Option<String>,
	pub disabled: bool,
	pub monospace: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<TextAreaInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct TextInput {
	// Content
	#[widget_builder(constructor)]
	pub value: String,
	pub label: Option<String>,
	pub placeholder: Option<String>,
	pub disabled: bool,

	// Styling
	pub narrow: bool,
	pub centered: bool,
	pub sizing: WidgetSizing,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<TextInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

/// A math expression's text field, typeset with math italics and syntax highlighting as it is edited.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct MathExpressionInput {
	// Content
	#[widget_builder(constructor)]
	pub value: String,
	/// The value's tokens, which the frontend colors and typesets, as it does the tokens sent for each edit while typing.
	pub tokens: Vec<MathExpressionToken>,
	/// What hovering each token shows, listed once each however many tokens share one.
	pub tooltips: Vec<MathExpressionTooltip>,
	/// The stretches of the value its parse errors point at, which the frontend underlines.
	pub errors: Vec<MathExpressionRange>,
	/// Whether a lone operator or function name like `+` or `max` is an expression, applied across a list as by the Math node.
	#[serde(skip)]
	pub accepts_reducers: bool,
	pub disabled: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<MathExpressionInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

/// A stretch of a math expression with the role its spelling gives it, in the UTF-16 code units the frontend's strings use.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct MathExpressionToken {
	pub start: u32,
	pub end: u32,
	pub role: MathExpressionRole,
	/// How many exponents deep it stands, 0 outside any.
	pub superscript: u8,
	/// Where a name's subscript begins, in code units from its start.
	pub subscript: Option<u32>,
	/// The index among the tokens of the delimiter pairing with this one.
	pub partner: Option<u32>,
	/// For a comma or semicolon, the index among the tokens of the opener of the group whose parts it separates.
	pub separates: Option<u32>,
	/// The index among the tooltips of what hovering the token shows: a builtin's, constant's, or operator's documentation, or the
	/// drawing of a matrix or range literal.
	pub tooltip: Option<u32>,
	/// For a finite number, the literal it's part of, which the frontend can adjust as one value.
	pub literal: Option<MathExpressionLiteral>,
}

/// A number as the frontend may adjust it as one value, written from its start to the end of the number's token.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct MathExpressionLiteral {
	/// Where it begins, at any sign right before the number.
	pub start: u32,
	/// Whether it follows an operand it multiplies, where a sign written before it would subtract instead.
	#[serde(rename = "afterOperand")]
	pub after_operand: bool,
}

/// A math expression token's hover text, in the tooltip Markdown subset.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct MathExpressionTooltip {
	pub label: String,
	/// How it's written, like `sin(θ)`, `a + b`, or `π`, which the frontend shows beside the label.
	pub form: Option<String>,
	pub description: String,
	/// The signature of a call or matrix literal, which its form shows, for the frontend to mark the argument or entry being typed in it.
	pub signature: Option<MathExpressionSignature>,
}

/// A call's or matrix literal's parameters between its delimiters, like `sin(` and `)` or `[` and `]`.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct MathExpressionSignature {
	pub opening: String,
	pub parameters: Vec<String>,
	pub separator: String,
	pub closing: String,
	/// For a call, the range of its results, like `[0, ∞]`, written after an arrow.
	pub range: String,
	/// For a drawn matrix literal, the arrow pointing at each entry's row or column, for the frontend to draw at the one being typed.
	pub pointers: Vec<MathExpressionPointer>,
	/// For a call, the description line explaining each parameter, for the frontend to mark the one being typed.
	pub lines: Vec<u32>,
}

/// An arrow to draw into a tooltip description's code block, at a character of one of its lines.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct MathExpressionPointer {
	pub line: u32,
	pub column: u32,
	pub arrow: String,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Copy, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum MathExpressionRole {
	Number,
	Variable,
	Matrix,
	Basis,
	Function,
	Keyword,
	Operator,
	Bracket,
	MatrixLiteral,
	Error,
}

impl From<math_parser::highlight::Role> for MathExpressionRole {
	fn from(role: math_parser::highlight::Role) -> Self {
		use math_parser::highlight::Role;
		match role {
			Role::Number => Self::Number,
			Role::Variable => Self::Variable,
			Role::Matrix => Self::Matrix,
			Role::Basis => Self::Basis,
			Role::Function => Self::Function,
			Role::Keyword => Self::Keyword,
			Role::Operator => Self::Operator,
			Role::Bracket => Self::Bracket,
			Role::MatrixLiteral => Self::MatrixLiteral,
			Role::Error => Self::Error,
		}
	}
}

/// A stretch of a math expression, in the UTF-16 code units the frontend's strings use.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct MathExpressionRange {
	pub start: u32,
	pub end: u32,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Default, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct VisualColorPickersInput {
	// Content
	pub hue: f64,
	pub saturation: f64,
	pub value: f64,
	pub alpha: f64,
	#[serde(rename = "isNone")]
	pub is_none: bool,
	pub disabled: bool,

	// Callbacks
	// `on_update` receives the raw `VisualColorPickersInputUpdate` (not the mutated widget) so the layout diffing can still detect a change between the stored layout and the rebuilt one, otherwise the selection circle and slider needles never re-render after a drag.
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<VisualColorPickersInputUpdate>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct VisualColorPickersInputUpdate {
	pub hue: f64,
	pub saturation: f64,
	pub value: f64,
	pub alpha: f64,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Default, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct ColorComparisonInput {
	// Content
	#[widget_builder(constructor)]
	#[serde(rename = "newColor")]
	pub new_color: Option<SRGBA8>,
	#[widget_builder(constructor)]
	#[serde(rename = "oldColor")]
	pub old_color: Option<SRGBA8>,
	#[serde(rename = "isNone")]
	pub is_none: bool,
	#[serde(rename = "oldIsNone")]
	pub old_is_none: bool,
	pub disabled: bool,
	pub differs: bool,
	#[serde(rename = "outlineAmount")]
	pub outline_amount: f64,
	/// Hex CSS string for the new color (with alpha if not fully opaque), or empty when `is_none`. Auto-populated from `new_color` at layout-send time.
	#[serde(rename = "newColorCSS")]
	#[widget_builder(skip)]
	pub new_color_css: String,
	/// Black or white, whichever contrasts the new color for legible label text. Auto-populated.
	#[serde(rename = "newColorContrasting")]
	#[widget_builder(skip)]
	pub new_color_contrasting: String,
	/// Hex CSS string for the old color (with alpha if not fully opaque), or empty when `old_is_none`. Auto-populated.
	#[serde(rename = "oldColorCSS")]
	#[widget_builder(skip)]
	pub old_color_css: String,
	/// Black or white, whichever contrasts the old color for legible label text. Auto-populated.
	#[serde(rename = "oldColorContrasting")]
	#[widget_builder(skip)]
	pub old_color_contrasting: String,

	// Callbacks
	// The `swap` event has no payload — it just signals the user requested a swap.
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<()>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Default, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct ColorPresetsInput {
	// Content
	pub disabled: bool,
	#[serde(rename = "showNoneOption")]
	pub show_none_option: bool,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<ColorPresetsInputUpdate>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum ColorPresetsInputUpdate {
	Preset(FillChoice<SRGBA8>),
	EyedropperColorCode(String),
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct TransferCurveInput {
	// Content
	/// The control points in the units of `domain` and `range`, in any x order, since sampling sorts them.
	#[widget_builder(constructor)]
	pub points: Vec<(f64, f64)>,
	/// The x extent the box spans, left to right.
	pub domain: [f64; 2],
	/// The y extent the box spans, bottom to top.
	pub range: [f64; 2],
	/// Whether the drawn curve and a dragged point's y stay inside `range`. A point's x always stays inside `domain`.
	#[serde(rename = "clampToRange")]
	pub clamp_to_range: bool,
	/// Polyline of the curve in box-normalized 0..1 coordinates with y upward. Auto-populated from `points` at layout-send time.
	#[widget_builder(skip)]
	pub samples: Vec<(f64, f64)>,
	/// Whether clicking empty space inserts a point.
	#[serde(rename = "allowInsert")]
	pub allow_insert: bool,
	/// Whether double-click or right-click removes a point. The handler still has the final say (e.g., enforcing a minimum count).
	#[serde(rename = "allowDelete")]
	pub allow_delete: bool,
	pub disabled: bool,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<TransferCurveInputUpdate>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum TransferCurveInputUpdate {
	MovePoint { index: u32, x: f64, y: f64 },
	InsertPoint { x: f64, y: f64 },
	DeletePoint { index: u32 },
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct SliderInput {
	// Content
	/// The colored gradient drawn behind the markers (display-only, caller-owned).
	#[widget_builder(constructor)]
	pub track: GradientStops<SRGBA8>,
	/// The color space the track's stops interpolate in, used to bake `track_samples`. Not sent to the frontend.
	#[serde(skip)]
	pub track_space: GradientSpace,
	/// Whether the track's stops wrap as a cycle, used to bake `track_samples` and by the frontend to draw the wrapped interval's midpoint diamond.
	#[serde(rename = "trackCyclic")]
	pub track_cyclic: bool,
	/// The hue direction the track's stops interpolate with in a polar space, used to bake `track_samples`. Not sent to the frontend.
	#[serde(skip)]
	pub track_hue_direction: GradientHueDirection,
	/// The path the track's stops interpolate along, used to bake `track_samples` and by the frontend to suppress the midpoint diamonds when stepped.
	#[serde(rename = "trackInterpolation")]
	pub track_interpolation: GradientInterpolation,
	/// Straight-alpha color samples drawn by the frontend as the stops of an SVG gradient filling the track strip. Auto-populated from `track` at layout-send time.
	#[serde(rename = "trackSamples")]
	#[widget_builder(skip)]
	pub track_samples: Vec<GradientSample>,
	/// Hex string for the track strip's leftmost solid-color end-cap. Auto-populated by evaluating `track` at position 0.
	#[serde(rename = "trackStartCSS")]
	#[widget_builder(skip)]
	pub track_start_css: String,
	/// Hex string for the track strip's rightmost solid-color end-cap. Auto-populated by evaluating `track` at position 1.
	#[serde(rename = "trackEndCSS")]
	#[widget_builder(skip)]
	pub track_end_css: String,
	/// The handles the user can drag along the track. Their handle colors are caller-owned (e.g., for a gradient editor they follow the stop colors, for a "Shadows/Midpoints/Highlights" widget they're hardcoded).
	pub markers: Vec<SliderMarker>,
	#[serde(rename = "activeMarkerIndex")]
	pub active_marker_index: Option<u32>,
	#[serde(rename = "activeMarkerIsMidpoint")]
	pub active_marker_is_midpoint: bool,
	/// Whether to render midpoint diamonds between adjacent markers (only meaningful for gradient-like uses).
	#[serde(rename = "showMidpoints")]
	pub show_midpoints: bool,
	/// Whether clicking the track inserts a new marker at the click position. Otherwise the click picks up the nearest marker.
	#[serde(rename = "allowInsert")]
	pub allow_insert: bool,
	/// Whether right-click or pressing Delete removes a marker. The handler still has the final say on whether the deletion goes through (e.g., enforcing a minimum count).
	#[serde(rename = "allowDelete")]
	pub allow_delete: bool,
	/// Whether dragging a marker past another reorders them, which also needs `allow_select`. Otherwise the dragged marker is clamped between its neighbors.
	#[serde(rename = "allowReorder")]
	pub allow_reorder: bool,
	/// Whether the track's ends meet, as on a hue wheel: a run dragged by its strip or dashed link wraps past them, a lone marker stops.
	#[serde(rename = "allowWrap")]
	pub allow_wrap: bool,
	/// Whether clicking a marker selects it, keeping it highlighted and reported as the active marker until another is chosen,
	/// as a gradient editor needs for the stop being edited. Otherwise the highlight only follows the pointer and the drag.
	#[serde(rename = "allowSelect")]
	pub allow_select: bool,
	/// Compact mode: 8px track height with 8px top padding, for use in rows alongside other widgets.
	pub narrow: bool,
	/// Plain range-slider mode, for a number beside its number input: a flat 4px track is drawn in place of the gradient, so `track` is never shown.
	#[serde(rename = "rangeSlider")]
	pub range_slider: bool,
	/// Whether the input is disabled (dimmed and read-only).
	pub disabled: bool,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<SliderInputUpdate>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, Default, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct SliderMarker {
	/// Position along the track, normally 0..1. A shifted or stretched non-cyclic ramp can push it outside, where it is not drawn.
	position: f64,
	/// Midpoint (0..1) of the interval to the next marker, used only with `show_midpoints`. The last marker's midpoint spans the wrap of a cyclic track, or is otherwise ignored.
	midpoint: f64,
	/// CSS color string for the marker handle's fill. Set via `SliderMarker::new` from a linear [`Color`],
	/// discarding any transparency so the handle always shows the RGB that steers the interpolation.
	#[serde(rename = "handleColorCSS")]
	handle_color_css: String,
	/// Whether this marker and the next form a split handle: one marker split down the middle while they coincide, two halves joined by a strip once apart.
	#[serde(rename = "pairedWithNext")]
	paired_with_next: bool,
	/// Whether a dashed line runs from this marker to the next through the lane below the track. Dragging it carries both markers, along with any split-handle halves attached to them.
	#[serde(rename = "dashedToNext")]
	dashed_to_next: bool,
	/// Whether this marker follows its neighbors instead of bounding them, so they may drag past its drawn position.
	#[serde(rename = "betweenNeighbors")]
	between_neighbors: bool,
}

impl SliderMarker {
	pub fn new(position: f64, midpoint: f64, handle_color: Color) -> Self {
		let handle_color_css = format!("#{}", SRGBA8::from(handle_color).to_rgb_hex());
		Self {
			position,
			midpoint,
			handle_color_css,
			paired_with_next: false,
			dashed_to_next: false,
			between_neighbors: false,
		}
	}

	pub fn between_neighbors(mut self) -> Self {
		self.between_neighbors = true;
		self
	}

	pub fn pair_with_next(mut self) -> Self {
		self.paired_with_next = true;
		self
	}

	pub fn dash_to_next(mut self) -> Self {
		self.dashed_to_next = true;
		self
	}
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, Default, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct GradientSample {
	/// Position (0..1) of the sample along the gradient, drawn as the SVG stop's `offset`.
	position: f64,
	/// `#rrggbb` hex of the sample's color, drawn as the SVG stop's `stop-color`.
	color: String,
	/// Straight alpha (0..1) of the sample, drawn as the SVG stop's `stop-opacity`.
	alpha: f32,
}

impl GradientSample {
	pub fn new(position: f64, color: Color) -> Self {
		Self {
			position,
			color: format!("#{}", SRGBA8::from(color).to_rgb_hex()),
			alpha: color.a(),
		}
	}
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum SliderInputUpdate {
	MoveMarker {
		index: u32,
		position: f64,
	},
	MoveMidpoint {
		index: u32,
		position: f64,
	},
	InsertMarker {
		position: f64,
	},
	DeleteMarker {
		index: u32,
	},
	/// Insert a copy (same color and midpoint) of the marker at `index` at `position`, keeping the marker at `index` active.
	InsertDuplicate {
		index: u32,
		position: f64,
	},
	/// Remove the marker at `index` while keeping the currently active marker active (renumbered to account for the removal).
	/// Used to un-duplicate when Alt is released mid-drag, deleting the frozen copy left by [`InsertDuplicate`](Self::InsertDuplicate).
	RemoveDuplicate {
		index: u32,
	},
	/// Emitted when the user double-clicks a marker. The consumer decides what (if anything) to reset the marker to.
	ResetMarker {
		index: u32,
	},
	ResetMidpoint {
		index: u32,
	},
	ActiveMarker {
		#[serde(rename = "activeMarkerIndex")]
		active_marker_index: Option<u32>,
		#[serde(rename = "activeMarkerIsMidpoint")]
		active_marker_is_midpoint: bool,
	},
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Default, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct ReferencePointInput {
	// Content
	#[widget_builder(constructor)]
	pub value: ReferencePoint,
	pub disabled: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<ReferencePointInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}
