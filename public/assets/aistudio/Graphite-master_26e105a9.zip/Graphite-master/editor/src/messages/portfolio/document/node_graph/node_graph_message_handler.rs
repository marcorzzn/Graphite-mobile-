use super::node_inspector;
use super::utility_types::{BoxSelection, ContextMenuInformation, DragStart, FrontendNode};
use crate::consts::{DOUBLE_CLICK_ALLOWED_TRAVEL, DOUBLE_CLICK_MILLISECONDS, GRID_SIZE, NODE_GLIDE_TIME_CONSTANT_MILLISECONDS, WIRE_DRAG_NODE_EXPAND_DELAY_MILLISECONDS};
use crate::messages::input_mapper::utility_types::macros::{action_shortcut, action_shortcut_manual};
use crate::messages::layout::utility_types::widget_prelude::*;
use crate::messages::portfolio::document::document_message_handler::navigation_controls;
use crate::messages::portfolio::document::graph_operation::utility_types::ModifyInputsContext;
use crate::messages::portfolio::document::node_graph::document_node_definitions::{DefinitionIdentifier, NodeInspectorContext, resolve_document_node_type, resolve_network_node_type};
use crate::messages::portfolio::document::node_graph::utility_types::{ContextMenuData, Direction, FrontendGraphDataType, NodeEvaluationError, NodeGraphErrorDiagnostic};
use crate::messages::portfolio::document::utility_types::document_metadata::LayerNodeIdentifier;
use crate::messages::portfolio::document::utility_types::layers_in_view::LayersInView;
use crate::messages::portfolio::document::utility_types::misc::GroupFolderType;
use crate::messages::portfolio::document::utility_types::network_interface::{
	self, FlowType, GlideOffsets, ImportOrExport, InputConnector, NodeNetworkInterface, NodeTypePersistentMetadata, OutputConnector, Previewing, RootNode, TransactionCheckpoint,
};
use crate::messages::portfolio::document::utility_types::nodes::{CollapsedLayers, LayerPanelChainInsertion, LayerPanelChainNode, LayerPanelEntry};
use crate::messages::portfolio::document::utility_types::wires::{GraphWireStyle, WirePath, WirePathUpdate, build_vector_wire};
use crate::messages::prelude::*;
use crate::messages::tool::common_functionality::auto_panning::AutoPanning;
use crate::messages::tool::common_functionality::edit_target::{EditTarget, ResolvedEditTarget};
use crate::messages::tool::common_functionality::graph_modification_utils::get_clip_mode;
use crate::messages::tool::common_functionality::utility_functions::make_path_editable_is_allowed;
use crate::messages::tool::tool_messages::tool_prelude::{Key, MouseMotion};
use crate::messages::tool::utility_types::{HintData, HintGroup, HintInfo};
use crate::messages::viewport::Position;
use glam::{DAffine2, DVec2, IVec2};
use graph_craft::document::value::TaggedValue;
use graph_craft::document::{DocumentNodeImplementation, NodeId, NodeInput};
use graphene_std::math::math_ext::QuadExt;
use graphene_std::vector::algorithms::bezpath_algorithms::bezpath_is_inside_bezpath;
use graphene_std::*;
use kurbo::{DEFAULT_ACCURACY, Shape};
use renderer::Quad;
use std::cmp::Ordering;

#[derive(Debug, ExtractField)]
pub struct NodeGraphMessageContext<'a> {
	pub network_interface: &'a mut NodeNetworkInterface,
	pub selection_network_path: &'a [NodeId],
	pub breadcrumb_network_path: &'a [NodeId],
	pub document_id: DocumentId,
	pub collapsed: &'a mut CollapsedLayers,
	pub inspector_collapsed_sections: &'a mut Vec<NodeId>,
	pub inspector_expanded_input_chains: &'a mut Vec<(NodeId, Option<usize>)>,
	pub layers_panel_expanded_chains: &'a mut Vec<NodeId>,
	pub layers_in_view: &'a mut LayersInView,
	pub ipp: &'a InputPreprocessorMessageHandler,
	pub graph_view_overlay_open: bool,
	pub graph_fade_artwork_percentage: f64,
	pub navigation_handler: &'a NavigationMessageHandler,
	pub preferences: &'a PreferencesMessageHandler,
	pub layers_panel_open: bool,
	pub tool_edit_target: &'a EditTarget,
	pub viewport: &'a ViewportMessageHandler,
}

#[derive(Debug, Clone, ExtractField)]
pub struct NodeGraphMessageHandler {
	// TODO: Remove network and move to NodeNetworkInterface
	pub network: Vec<NodeId>,
	has_selection: bool,
	widgets: [LayoutGroup; 2],
	/// Used to add a transaction for the first node move when dragging.
	begin_dragging: bool,
	/// Whether the current drag added the nodes it drags, as duplicates from an Alt-drag or as a redirect dot from a double-press, which shaking keeps rather than undoing to before the drag.
	pub nodes_added_in_drag: bool,
	/// Whether the current press has moved a node to another grid cell, in which case the double-click it ends does nothing.
	node_has_moved_in_drag: bool,
	/// The latest press of the left mouse button, which tells whether the next press is the second of a double-click as soon as it lands.
	latest_left_press: Option<LeftPress>,
	/// Whether the current press, as the second of a double-click, already used it to add a redirect dot or to start dragging one out of a connector,
	/// so the double-click arriving after its release does nothing more, even if no dot was dragged out.
	double_click_used_by_press: bool,
	/// The connector a double-press is dragging a redirect dot out of, with where the press began in node graph space, until the pointer moves far enough to place the dot.
	pub dot_drag_out: Option<(DotDragOutSource, DVec2)>,
	/// If dragging the selected nodes, this stores the starting position both in viewport and node graph coordinates,
	/// plus a flag indicating if it has been dragged since the mousedown began.
	pub drag_start: Option<(DragStart, bool)>,
	// Store the selected chain nodes on drag start so they can be reconnected if shaken
	pub drag_start_chain_nodes: Vec<NodeId>,
	/// The wire a dragged node would be inserted onto if dropped now, which the frontend shows undimmed.
	wire_insertion_preview: Option<InputConnector>,
	/// The center of the connector a press at the pointer would grab, in node graph space, which the frontend shows hovered.
	hovered_connector: Option<DVec2>,
	/// If dragging the background to create a box selection, this stores its starting point in node graph coordinates,
	/// plus a flag indicating if it has been dragged since the mousedown began.
	pub box_selection_start: Option<(DVec2, bool)>,
	/// Restore the selection before box selection if it is aborted
	pub selection_before_pointer_down: Vec<NodeId>,
	/// If the grip icon is held during a drag, then shift without pushing other nodes
	shift_without_push: bool,
	disconnecting: Option<InputConnector>,
	initial_disconnecting: bool,
	/// Node to select on pointer up if multiple nodes are selected and they were not dragged.
	pub select_if_not_dragged: Option<NodeId>,
	/// The output end of the dragged wire in node graph coordinates, which follows the pointer when the wire is dragged backward.
	pub wire_in_progress_from_connector: Option<DVec2>,
	/// The input end of the dragged wire in node graph coordinates, which follows the pointer when the wire is dragged forward.
	pub wire_in_progress_to_connector: Option<DVec2>,
	/// The data type determining the color of the wire being dragged.
	pub wire_in_progress_type: FrontendGraphDataType,
	/// The import a wire dragged from a dimmed connector for adding one would add, which only happens once it connects to something.
	wire_in_progress_from_new_import: Option<usize>,
	/// The empty input or export a wire is dragged backward from, which stays its end while its other end is taken to an output.
	wire_in_progress_from_input: Option<InputConnector>,
	/// The export a wire dragged backward from a dimmed connector for adding one would add, which only happens once it connects to something.
	wire_in_progress_from_new_export: Option<usize>,
	/// The node hovered by the wire in progress and when the hover began, in milliseconds.
	wire_hovered_node: Option<(NodeId, u64)>,
	/// The node expanded for the wire in progress, the indices of the inputs it temporarily exposed, and the prior transaction state.
	wire_expanded_node: Option<(NodeId, Vec<usize>, TransactionCheckpoint)>,
	/// Whether [`NodeGraphMessage::WireHoverTick`] is subscribed to animation frames.
	wire_hover_tick_subscribed: bool,
	/// The network with whatever is gliding into the place it moved to, which keeps its own glide offsets.
	glide_network_path: Vec<NodeId>,
	/// When the gliding nodes were last brought closer to their grid cells, in milliseconds, once an animation frame has arrived.
	glide_last_tick_time: Option<u64>,
	/// Whether [`NodeGraphMessage::GlideTick`] is subscribed to animation frames.
	glide_tick_subscribed: bool,
	/// State for the context menus.
	pub context_menu: Option<ContextMenuInformation>,
	/// Index of selected node to be deselected on pointer up when shift clicking an already selected node
	pub deselect_on_pointer_up: Option<usize>,
	/// Adds the auto panning functionality to the node graph when dragging a node or selection box to the edge of the viewport.
	auto_panning: AutoPanning,
	/// The node to preview on mouse up if alt-clicked
	preview_on_mouse_up: Option<NodeId>,
	/// The index of the import that is being moved
	reordering_import: Option<usize>,
	/// The index of the export that is being moved
	reordering_export: Option<usize>,
	/// The end index of the moved connector
	end_index: Option<usize>,
	/// Used to keep track of what nodes are sent to the front end so that only visible ones are sent to the frontend
	frontend_nodes: Vec<NodeId>,
	/// Used to keep track of what wires are sent to the front end so the old ones can be removed
	frontend_wires: HashSet<(NodeId, usize)>,
	evaluation_errors: Vec<NodeEvaluationError>,
}

/// NodeGraphMessageHandler always modifies the network which the selected nodes are in. No GraphOperationMessages should be added here, since those messages will always affect the document network.
#[message_handler_data]
impl<'a> MessageHandler<NodeGraphMessage, NodeGraphMessageContext<'a>> for NodeGraphMessageHandler {
	fn process_message(&mut self, message: NodeGraphMessage, responses: &mut VecDeque<Message>, context: NodeGraphMessageContext<'a>) {
		let NodeGraphMessageContext {
			network_interface,
			selection_network_path,
			breadcrumb_network_path,
			document_id,
			collapsed,
			inspector_collapsed_sections,
			inspector_expanded_input_chains,
			layers_panel_expanded_chains,
			layers_in_view,
			ipp,
			graph_view_overlay_open,
			graph_fade_artwork_percentage,
			navigation_handler,
			preferences,
			layers_panel_open,
			tool_edit_target,
			viewport,
		} = context;

		match message {
			// TODO: automatically remove broadcast messages.
			NodeGraphMessage::AddNodes { nodes, new_ids } => {
				let Some(new_layer_id) = new_ids.get(&NodeId(0)).cloned().or_else(|| nodes.first().map(|(node_id, _)| *node_id)) else {
					log::error!("No nodes to add in AddNodes");
					return;
				};
				network_interface.insert_node_group(nodes, new_ids, selection_network_path);

				responses.add(NodeGraphMessage::SelectedNodesSet { nodes: vec![new_layer_id] });
			}
			NodeGraphMessage::AddPathNode => {
				if let Some(layer) = make_path_editable_is_allowed(network_interface) {
					responses.add(NodeGraphMessage::CreateNodeInLayerWithTransaction {
						node_type: DefinitionIdentifier::Network("Path".into()),
						layer,
					});
					responses.add(EventMessage::SelectionChanged);
				}
			}
			NodeGraphMessage::AddImport => {
				network_interface.add_import(graph_craft::document::value::TaggedValue::None, true, -1, "", "", breadcrumb_network_path);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::AddImportAndConnect { import_index, input_connector } => {
				// The import takes over the value its wire displaces, or else the one a disconnect would leave, so it has the type the input accepts
				let import_value = match network_interface.input_from_connector(&input_connector, breadcrumb_network_path) {
					Some(NodeInput::Value { tagged_value, .. }) => (**tagged_value).clone(),
					Some(_) => network_interface.tagged_value_from_input(&input_connector, breadcrumb_network_path),
					None => {
						log::error!("Could not get the input {input_connector:?} to connect a new import to");
						return;
					}
				};

				let import_count = network_interface.number_of_imports(breadcrumb_network_path);
				let wired_import_index = if import_index == 0 && import_count > 0 {
					// The empty primary is a hidden input, so it's shown
					if let Some((node_id, encapsulating_path)) = breadcrumb_network_path.split_last() {
						let primary_input = InputConnector::primary_input(*node_id);
						if let Some(NodeInput::Value { exposed: false, .. }) = network_interface.input_from_connector(&primary_input, encapsulating_path) {
							network_interface.set_input(&primary_input, NodeInput::value(import_value, true), encapsulating_path);
						}
					}
					0
				} else {
					// A secondary import follows an empty primary added first when there are no imports yet
					if import_index > 0 && import_count == 0 {
						network_interface.add_import(TaggedValue::None, false, -1, "", "", breadcrumb_network_path);
					}
					network_interface.add_import(import_value, true, -1, "", "", breadcrumb_network_path);
					network_interface.number_of_imports(breadcrumb_network_path).saturating_sub(1)
				};

				responses.add(NodeGraphMessage::CreateWire {
					output_connector: OutputConnector::Import(wired_import_index),
					input_connector,
				});
				responses.add(NodeGraphMessage::UpdateImportsExports);
				responses.add(NodeGraphMessage::RunDocumentGraph);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::AddExport => {
				network_interface.add_export(graph_craft::document::value::TaggedValue::None, -1, "", breadcrumb_network_path);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::AddPrimaryExport => {
				if network_interface.number_of_exports(breadcrumb_network_path) == 0 {
					responses.add(NodeGraphMessage::AddExport);
				} else {
					responses.add(NodeGraphMessage::ExposePrimaryExport { exposed: true });
				}
			}
			NodeGraphMessage::AddSecondaryExport => {
				// If necessary, add a hidden primary export before the secondary export
				if network_interface.number_of_exports(breadcrumb_network_path) == 0 {
					responses.add(NodeGraphMessage::AddExport);
					responses.add(NodeGraphMessage::ExposePrimaryExport { exposed: false });
				}

				// Add the secondary export
				responses.add(NodeGraphMessage::AddExport);
			}
			NodeGraphMessage::Init => {
				responses.add(BroadcastMessage::SubscribeEvent {
					on: EventMessage::SelectionChanged,
					send: Box::new(NodeGraphMessage::SelectedNodesUpdated.into()),
				});

				network_interface.load_structure();

				// Prune the Layers panel collapsed state for any layer tree paths whose nodes no longer exist, so it doesn't accumulate across loads
				collapsed.0.retain(|path| path.iter().all(|&node_id| network_interface.document_network().nodes.contains_key(&node_id)));

				// Prune the Inspector node section collapsed state for any nodes (in any nested network) that no longer exist, so it doesn't accumulate across loads
				let existing_nodes = network_interface.document_network().recursive_nodes().map(|(node_id, ..)| *node_id).collect::<HashSet<_>>();
				inspector_collapsed_sections.retain(|node_id| existing_nodes.contains(node_id));

				// Likewise for the Inspector's expanded input chains and the Layers panel's expanded layer chains
				inspector_expanded_input_chains.retain(|(node_id, _)| existing_nodes.contains(node_id));
				layers_panel_expanded_chains.retain(|node_id| existing_nodes.contains(node_id));
			}
			NodeGraphMessage::SelectedNodesUpdated => {
				let selected_layers = network_interface.selected_nodes().selected_layers(network_interface.document_metadata()).collect::<Vec<_>>();
				if selected_layers.len() <= 1 {
					responses.add(DocumentMessage::SetRangeSelectionLayer {
						new_layer: selected_layers.first().cloned(),
					});
				}
				responses.add(MenuBarMessage::SendLayout);
				// Refreshes the Selection button in the view options popover
				if graph_view_overlay_open {
					responses.add(NodeGraphMessage::UpdateGraphBarRight);
				} else {
					responses.add(PortfolioMessage::UpdateDocumentWidgets);
				}
				responses.add(NodeGraphMessage::UpdateLayerPanel);
				responses.add(InspectorMessage::Refresh);
				responses.add(NodeGraphMessage::SendSelectedNodes);
				responses.add(ArtboardToolMessage::UpdateSelectedArtboard);
				responses.add(DocumentMessage::DocumentStructureChanged);
				responses.add(OverlaysMessage::Draw);
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(PortfolioMessage::SubmitActiveGraphRender);
			}
			NodeGraphMessage::CreateWire { output_connector, input_connector } => {
				network_interface.create_wire(&output_connector, &input_connector, selection_network_path);
			}
			NodeGraphMessage::CreateWires { output_connector, input_connectors } => {
				network_interface.create_wires(&output_connector, &input_connectors, selection_network_path);
			}
			// Copies and cuts the same way as anywhere else
			NodeGraphMessage::Copy => responses.add(ClipboardMessage::CopyLayers),
			NodeGraphMessage::CreateNodeInLayerNoTransaction { node_type, layer } => {
				let Some(mut modify_inputs) = ModifyInputsContext::new_with_layer(layer, network_interface, responses) else {
					return;
				};
				modify_inputs.create_node(&node_type);
			}
			NodeGraphMessage::CreateNodeInLayerWithTransaction { node_type, layer } => {
				responses.add(DocumentMessage::AddTransaction);
				responses.add(NodeGraphMessage::CreateNodeInLayerNoTransaction { node_type, layer });
				responses.add(InspectorMessage::Refresh);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::CreateNodeFromContextMenu {
				node_id,
				node_type,
				xy,
				add_transaction,
			} => {
				let (x, y) = if let Some((x, y)) = xy {
					(x, y)
				} else if let Some(node_graph_ptz) = network_interface.node_graph_ptz(breadcrumb_network_path) {
					((-node_graph_ptz.pan.x / GRID_SIZE as f64) as i32, (-node_graph_ptz.pan.y / GRID_SIZE as f64) as i32)
				} else {
					(0, 0)
				};

				let node_id = node_id.unwrap_or_else(NodeId::new);

				let Some(document_node_type) = resolve_document_node_type(&node_type) else {
					responses.add(DialogMessage::DisplayDialogError {
						title: "Cannot insert node".to_string(),
						description: format!("The document node '{node_type:?}' does not exist in the document node list"),
					});
					return;
				};

				let mut node_template = document_node_type.default_node_template();
				self.context_menu = None;

				// A freshly added Text node carries no font, so give it the default font (registered like the Text tool does)
				if node_type == DefinitionIdentifier::ProtoNode(graphene_std::text::text::IDENTIFIER) {
					let font_resource_id = graph_craft::application_io::resource::ResourceId::new();
					if let Some(font_input) = node_template.input_mut(graphene_std::text::text::FontInput) {
						*font_input = NodeInput::value(TaggedValue::Resource(font_resource_id), false);
					}
					responses.add(DocumentMessage::Resource(ResourceMessage::AddFont {
						resource_id: font_resource_id,
						font: graphene_std::text::Font::default(),
					}));
				}

				if add_transaction {
					responses.add(DocumentMessage::AddTransaction);
				}

				responses.add(NodeGraphMessage::InsertNode {
					node_id,
					node_template: Box::new(node_template.clone()),
				});
				responses.add(NodeGraphMessage::ShiftNodePosition { node_id, x, y });
				// A wire dragged backward is taken by the new node's primary output, adding the export first if it's at a dimmed connector for adding one
				if self.wire_in_progress_is_backward() {
					let input_connector = match self.wire_in_progress_from_new_export {
						Some(export_index) => {
							responses.add(add_export_at(export_index));
							Some(InputConnector::Export(export_index))
						}
						None => self.wire_in_progress_from_input,
					};
					if let Some(input_connector) = input_connector {
						responses.add(NodeGraphMessage::CreateWire {
							output_connector: OutputConnector::primary_output(node_id),
							input_connector,
						});
						responses.add(NodeGraphMessage::RunDocumentGraph);
					}
				}
				// A wire dragged out of a dimmed connector for adding an import adds that import, wired to the new node's first exposed input
				else if let Some(import_index) = self.wire_in_progress_from_new_import {
					if let Some((input_index, _)) = node_template.inputs.iter().enumerate().find(|(_, input)| input.is_exposed()) {
						responses.add(NodeGraphMessage::AddImportAndConnect {
							import_index,
							input_connector: InputConnector::node_at_index(node_id, input_index),
						});
					}
				}
				// Only auto connect to the dragged wire if the node is being added to the currently opened network
				else if let Some(output_connector_position) = self.wire_in_progress_from_connector {
					let Some(network_metadata) = network_interface.network_metadata(selection_network_path) else {
						log::error!("Could not get network metadata in CreateNodeFromContextMenu");
						return;
					};
					let output_connector_position_viewport = network_metadata
						.persistent_metadata
						.navigation_metadata
						.node_graph_to_viewport
						.transform_point2(output_connector_position);
					let Some(output_connector) = &network_interface.output_connector_from_click(output_connector_position_viewport, breadcrumb_network_path) else {
						log::error!("Could not get output from connector start");
						return;
					};

					// Ensure connection is to correct input of new node. If it does not have an input then do not connect
					if let Some((input_index, _)) = node_template.inputs.iter().enumerate().find(|(_, input)| input.is_exposed()) {
						responses.add(NodeGraphMessage::CreateWire {
							output_connector: *output_connector,
							input_connector: InputConnector::node_at_index(node_id, input_index),
						});

						responses.add(NodeGraphMessage::RunDocumentGraph);
					}
				}
				self.end_wire_in_progress(network_interface, selection_network_path, responses);
				responses.add(FrontendMessage::UpdateContextMenuInformation {
					context_menu_information: self.context_menu.clone(),
				});
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::ConnectUpstreamOutputToInput { downstream_input, input_connector } => {
				let Some(upstream_node) = network_interface.upstream_output_connector(&downstream_input, selection_network_path) else {
					log::error!("Failed to find upstream node for downstream_input");
					return;
				};
				responses.add(NodeGraphMessage::CreateWire {
					output_connector: upstream_node,
					input_connector,
				});
			}
			NodeGraphMessage::Cut => responses.add(ClipboardMessage::CutLayers),
			NodeGraphMessage::DeleteNodes { node_ids, delete_children } => {
				// Detect stroke/fill proto nodes among the doomed nodes before they're gone so the tool control bars can re-sync
				let stroke = DefinitionIdentifier::ProtoNode(graphene_std::vector::stroke::IDENTIFIER);
				let fill = DefinitionIdentifier::ProtoNode(graphene_std::vector::fill::IDENTIFIER);
				let any_fill_or_stroke_deleted = node_ids.iter().any(|node_id| {
					network_interface
						.reference(node_id, selection_network_path)
						.is_some_and(|reference| reference == stroke || reference == fill)
				});
				network_interface.delete_nodes(node_ids, delete_children, selection_network_path);
				if any_fill_or_stroke_deleted {
					responses.add(PenToolMessage::SelectionChanged);
					responses.add(FreehandToolMessage::SelectionChanged);
					responses.add(SplineToolMessage::SelectionChanged);
					responses.add(ShapeToolMessage::SelectionChanged);
					responses.add(TextToolMessage::SelectionChanged);
				}
			}
			// Deletes selected_nodes. If `reconnect` is true, then all children nodes (secondary input) of the selected nodes are deleted and the siblings (primary input/output) are reconnected.
			// If `reconnect` is false, then only the selected nodes are deleted and not reconnected.
			NodeGraphMessage::DeleteSelectedNodes { delete_children } => {
				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
					log::error!("Could not get selected nodes in DeleteSelectedNodes");
					return;
				};
				responses.add(DocumentMessage::AddTransaction);
				responses.add(NodeGraphMessage::DeleteNodes {
					node_ids: selected_nodes.selected_nodes().cloned().collect::<Vec<_>>(),
					delete_children,
				});
				responses.add(NodeGraphMessage::RunDocumentGraph);
				responses.add(NodeGraphMessage::SelectedNodesUpdated);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::RemoveOrphanedDots => {
				network_interface.remove_orphaned_dots(selection_network_path);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::DisconnectInput { input_connector } => {
				// The operation this is a step of removes any dots it orphans once it's done
				network_interface.disconnect_input(&input_connector, selection_network_path);
			}
			NodeGraphMessage::DisconnectImportExport { index } => {
				match index {
					ImportOrExport::Import(import_index) => {
						network_interface.disconnect_import_wires(import_index, breadcrumb_network_path);
					}
					// While previewing, drop the wire the preview would restore, as dragging it off does
					ImportOrExport::Export(0) if matches!(network_interface.previewing(breadcrumb_network_path), Previewing::Yes { root_node_to_restore: Some(_) }) => {
						network_interface.start_previewing_without_restore(breadcrumb_network_path);
					}
					ImportOrExport::Export(export_index) => network_interface.disconnect_input(&InputConnector::Export(export_index), breadcrumb_network_path),
				}
				network_interface.remove_orphaned_dots(breadcrumb_network_path);

				responses.add(NodeGraphMessage::SendGraph);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::DisconnectRootNode => {
				network_interface.start_previewing_without_restore(selection_network_path);
			}
			NodeGraphMessage::SetRootNodeToRestore { root_node_to_restore } => {
				network_interface.set_root_node_to_restore(root_node_to_restore, selection_network_path);
			}
			// Duplicates in the flow like everywhere else
			NodeGraphMessage::DuplicateSelectedNodes => responses.add(DocumentMessage::DuplicateSelectedLayers),
			NodeGraphMessage::EnterNestedNetwork => {
				// Nothing more happens if the second press dragged a node, or already used the double-click to add a dot or drag one out of a connector
				if self.node_has_moved_in_drag || self.double_click_used_by_press {
					return;
				}

				let Some(node_id) = network_interface.node_from_click(ipp.mouse.position, selection_network_path) else {
					return;
				};

				// Double-clicking a redirect dot dissolves it, so the wires it bent run straight from what fed it
				if network_interface.is_redirect_dot(&node_id, selection_network_path) {
					responses.add(DocumentMessage::AddTransaction);
					responses.add(NodeGraphMessage::DeleteNodes {
						node_ids: vec![node_id],
						delete_children: false,
					});
					responses.add(NodeGraphMessage::RunDocumentGraph);
					responses.add(NodeGraphMessage::SelectedNodesUpdated);
					responses.add(NodeGraphMessage::SendGraph);
					return;
				}

				if network_interface
					.layer_click_target_from_click(ipp.mouse.position, network_interface::LayerClickTargetTypes::Visibility, selection_network_path)
					.is_some()
				{
					return;
				};
				// Double-clicking the layer's name area triggers inline rename instead of drilling into the subgraph.
				if let Some(layer_id) = network_interface.layer_click_target_from_click(ipp.mouse.position, network_interface::LayerClickTargetTypes::Name, selection_network_path) {
					responses.add(NodeGraphMessage::BeginEditLayerName { node_id: layer_id });
					return;
				}
				if let Some(DocumentNodeImplementation::Network(_)) = network_interface.implementation(&node_id, selection_network_path) {
					responses.add(DocumentMessage::EnterNestedNetwork { node_id });
				}
			}
			NodeGraphMessage::BeginEditLayerName { node_id } => {
				responses.add(FrontendMessage::TriggerEditLayerNameInGraph { node_id });
			}
			NodeGraphMessage::ExposeInput {
				input_connector,
				set_to_exposed,
				start_transaction,
			} => {
				let InputConnector::Node { node_id, input_index } = input_connector else {
					log::error!("Cannot expose/hide export");
					return;
				};
				let Some(node) = network_interface.document_node(&node_id, selection_network_path) else {
					log::error!("Could not find node {node_id} in NodeGraphMessage::ExposeInput");
					return;
				};
				let Some(mut node_input) = node.inputs.get(input_index).cloned() else {
					log::error!("Could not find input {input_index} in NodeGraphMessage::ExposeInput");
					return;
				};

				// If we're un-exposing an input that is not a value, then disconnect it. This will convert it to a value input,
				// so we can come back to handle this message again to set the exposed value in the second run-through.
				if !set_to_exposed && node_input.as_value().is_none() {
					// Reversed order because we are pushing front
					responses.add_front(NodeGraphMessage::ExposeInput {
						input_connector,
						set_to_exposed,
						start_transaction: false,
					});
					responses.add_front(NodeGraphMessage::DisconnectInput { input_connector });
					responses.add_front(DocumentMessage::StartTransaction);
					return;
				}

				// Add a history step, but only do so if we didn't already start a transaction in the first run-through of this message in the above code
				if start_transaction {
					responses.add_front(DocumentMessage::StartTransaction);
				}

				// If this node's input is a value type, we set its chosen exposed state
				if let NodeInput::Value { exposed, .. } = &mut node_input {
					*exposed = set_to_exposed;
				}
				responses.add(NodeGraphMessage::SetInput {
					input_connector: InputConnector::node_at_index(node_id, input_index),
					input: node_input,
				});
				// Hiding an input takes away the wire it was fed by, along with any dot it ran through
				responses.add(NodeGraphMessage::RemoveOrphanedDots);

				// Finish the history step
				responses.add(DocumentMessage::CommitTransaction);

				// Update the graph UI and re-render
				if graph_view_overlay_open {
					responses.add(InspectorMessage::Refresh);
					responses.add(NodeGraphMessage::SendGraph);
				} else {
					responses.add(DocumentMessage::GraphViewOverlay { open: true });
					responses.add(NavigationMessage::FitViewportToSelection);
					responses.add(DocumentMessage::ZoomCanvasTo100Percent);
				}
			}
			NodeGraphMessage::ExposeEncapsulatingInput { input_index, exposed } => {
				let Some((node_id, network_path)) = breadcrumb_network_path.split_last() else {
					return;
				};

				let encapsulating_connector = InputConnector::node_at_index(*node_id, input_index);
				if !exposed {
					network_interface.disconnect_input(&encapsulating_connector, network_path);
				}

				let Some(mut input) = network_interface.input_from_connector(&encapsulating_connector, network_path).cloned() else {
					return;
				};

				if let NodeInput::Value { exposed: old_exposed, .. } = &mut input {
					*old_exposed = exposed;
				}

				network_interface.set_input(&encapsulating_connector, input, network_path);

				// Disconnect all connections fed by the hidden primary import in the nested network
				if input_index == 0 && !exposed {
					network_interface.disconnect_import_wires(0, breadcrumb_network_path);
				}

				network_interface.remove_orphaned_dots(network_path);
				network_interface.remove_orphaned_dots(breadcrumb_network_path);

				responses.add(NodeGraphMessage::UpdateImportsExports);
				responses.add(NodeGraphMessage::SendWires);
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::ExposePrimaryExport { exposed } => {
				let export_connector: InputConnector = InputConnector::Export(0);
				if !exposed {
					network_interface.disconnect_input(&export_connector, breadcrumb_network_path);
				}

				let Some(mut input) = network_interface.input_from_connector(&export_connector, breadcrumb_network_path).cloned() else {
					return;
				};

				if let NodeInput::Value { exposed: old_exposed, .. } = &mut input {
					*old_exposed = exposed;
				}

				network_interface.set_input(&export_connector, input, breadcrumb_network_path);

				// Disconnect all connections in the encapsulating network
				if let Some((encapsulating_node, encapsulating_path)) = breadcrumb_network_path.split_last() {
					network_interface.disconnect_output_wires(&OutputConnector::primary_output(*encapsulating_node), encapsulating_path);
					network_interface.remove_orphaned_dots(encapsulating_path);
				}
				network_interface.remove_orphaned_dots(breadcrumb_network_path);

				responses.add(NodeGraphMessage::UpdateImportsExports);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::InsertNode { node_id, node_template } => {
				network_interface.insert_node(node_id, *node_template, selection_network_path);
			}
			NodeGraphMessage::InsertNodeBetween {
				node_id,
				input_connector,
				insert_node_input_index,
			} => {
				network_interface.insert_node_between(&node_id, &input_connector, insert_node_input_index, selection_network_path);
			}
			NodeGraphMessage::InsertDotOnWire { node_id, input_connector, x, y } => {
				network_interface.insert_dot_on_wire(node_id, &input_connector, IVec2::new(x, y), selection_network_path);
				responses.add(NodeGraphMessage::RunDocumentGraph);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::InsertDotOnOutput { node_id, output_connector, x, y } => {
				network_interface.insert_dot_on_output(node_id, &output_connector, IVec2::new(x, y), selection_network_path);
				responses.add(NodeGraphMessage::RunDocumentGraph);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::MergeSelectedNodes => {
				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(breadcrumb_network_path) else {
					log::error!("Could not get selected nodes in MergeSelectedNodes");
					return;
				};
				// Redirect dots go in only along with the wires they bend between the nodes going in, as when copying
				let selected_nodes = network_interface.selection_with_bridging_dots(selected_nodes.selected_nodes().copied().collect(), breadcrumb_network_path);
				if selected_nodes.is_empty() {
					return;
				}
				let new_ids = selected_nodes.iter().map(|id| (*id, *id)).collect::<HashMap<NodeId, NodeId>>();

				let copied_nodes = network_interface.copy_nodes(&new_ids, breadcrumb_network_path).collect::<Vec<_>>();
				let selected_node_ids = copied_nodes.iter().map(|(node_id, _)| *node_id).collect::<HashSet<_>>();
				let selected_node_ids_vec = copied_nodes.iter().map(|(node_id, _)| *node_id).collect::<Vec<_>>();
				// Mapping of the encapsulating node inputs/outputs to where it needs to be connected
				let mut input_connections = Vec::new();
				let mut output_connections = Vec::new();
				// Mapping of the inner nodes that need to be connected to the imports/exports
				let mut import_connections = Vec::new();
				let mut export_connections = Vec::new();
				// Scan current nodes top to bottom and find all inputs/outputs connected to nodes that are not in the copied nodes. These will represent the new imports and exports.
				let Some(nodes_sorted_top_to_bottom) = network_interface.nodes_sorted_top_to_bottom(selected_nodes.iter(), breadcrumb_network_path) else {
					return;
				};
				// Ensure that nodes can be grouped by checking if there is an unselected node between selected nodes
				for selected_node_id in &selected_node_ids {
					for input_index in 0..network_interface.number_of_inputs(selected_node_id, breadcrumb_network_path) {
						let input_connector = InputConnector::node_at_index(*selected_node_id, input_index);
						if let Some(upstream_deselected_node_id) = network_interface
							.upstream_output_connector(&input_connector, breadcrumb_network_path)
							.and_then(|output_connector| output_connector.node_id())
							.filter(|node_id| !selected_node_ids.contains(node_id))
						{
							for upstream_node_id in
								network_interface.upstream_flow_back_from_nodes(vec![upstream_deselected_node_id], breadcrumb_network_path, network_interface::FlowType::UpstreamFlow)
							{
								if selected_node_ids.contains(&upstream_node_id) {
									responses.add(DialogMessage::DisplayDialogError {
										title: "Error Grouping Nodes".to_string(),
										description: "A discontinuous selection of nodes cannot be grouped.\nEnsure no deselected nodes are between selected nodes".to_string(),
									});
									return;
								}
							}
						}
					}
				}
				for node_id in nodes_sorted_top_to_bottom {
					for input_index in 0..network_interface.number_of_inputs(&node_id, breadcrumb_network_path) {
						let current_input_connector = InputConnector::node_at_index(node_id, input_index);
						let Some(upstream_connector) = network_interface.upstream_output_connector(&current_input_connector, breadcrumb_network_path) else {
							continue;
						};
						if upstream_connector
							.node_id()
							.is_some_and(|upstream_node_id| selected_node_ids.iter().any(|copied_id| *copied_id == upstream_node_id))
						{
							continue;
						}

						// If the upstream connection is not part of the copied nodes, then connect it to the new imports, or add it if it has not already been added.
						let import_index = input_connections.iter().position(|old_connection| old_connection == &upstream_connector).unwrap_or_else(|| {
							input_connections.push(upstream_connector);
							input_connections.len() - 1
						});
						import_connections.push((current_input_connector, import_index));
					}
					for output_index in 0..network_interface.number_of_outputs(&node_id, breadcrumb_network_path) {
						let current_output_connector = OutputConnector::node(node_id, output_index);
						let Some(outward_wires) = network_interface.outward_wires(breadcrumb_network_path) else {
							log::error!("Could not get outward wires in upstream_nodes_below_layer");
							continue;
						};
						let Some(downstream_connections) = outward_wires.get(&current_output_connector).cloned() else {
							log::error!("Could not get downstream connections for {current_output_connector:?}");
							continue;
						};

						// The output gets connected to all the previous inputs the node was connected to
						let mut connect_output_to = Vec::new();
						for downstream_connection in downstream_connections {
							if downstream_connection.node_id().is_some_and(|downstream_node_id| selected_node_ids.contains(&downstream_node_id)) {
								continue;
							}
							connect_output_to.push(downstream_connection);
						}
						if !connect_output_to.is_empty() {
							// Every output connected to some non selected node forms a new export
							export_connections.push(current_output_connector);
							output_connections.push(connect_output_to);
						}
					}
				}

				// Use the network interface to add a default node, then set the imports, exports, paste the nodes inside, and connect them to the imports/exports
				let encapsulating_node_id = NodeId::new();
				let mut default_node_template = resolve_network_node_type("Custom Node").expect("Custom Node should exist").default_node_template();
				let Some(center_of_selected_nodes) = network_interface.selected_nodes_bounding_box(breadcrumb_network_path).map(|[a, b]| (a + b) / 2.) else {
					log::error!("Could not get center of selected_nodes");
					return;
				};
				let center_of_selected_nodes_grid_space = IVec2::new((center_of_selected_nodes.x / 24. + 0.5).floor() as i32, (center_of_selected_nodes.y / 24. + 0.5).floor() as i32);
				default_node_template.node_type_metadata = NodeTypePersistentMetadata::node(center_of_selected_nodes_grid_space - IVec2::new(3, 1));
				responses.add(DocumentMessage::AddTransaction);
				responses.add(NodeGraphMessage::InsertNode {
					node_id: encapsulating_node_id,
					node_template: Box::new(default_node_template),
				});
				responses.add(NodeGraphMessage::SetDisplayNameImpl {
					node_id: encapsulating_node_id,
					network_path: selection_network_path.to_vec(),
					alias: "Untitled Node".to_string(),
				});

				responses.add(DocumentMessage::EnterNestedNetwork { node_id: encapsulating_node_id });
				for _ in 0..input_connections.len() {
					responses.add(NodeGraphMessage::AddImport);
				}
				for _ in 0..output_connections.len() {
					responses.add(NodeGraphMessage::AddExport);
				}
				responses.add(NodeGraphMessage::AddNodes { nodes: copied_nodes, new_ids });
				responses.add(NodeGraphMessage::SelectedNodesSet { nodes: selected_node_ids_vec.clone() });

				// Shift the nodes back to the origin
				responses.add(NodeGraphMessage::ShiftSelectedNodesByAmount {
					graph_delta: -center_of_selected_nodes_grid_space - IVec2::new(2, 2),
					rubber_band: false,
					glide: false,
				});

				for (input_connector, import_index) in import_connections {
					responses.add(NodeGraphMessage::CreateWire {
						output_connector: OutputConnector::Import(import_index),
						input_connector,
					});
				}
				for (export_index, output_connector) in export_connections.into_iter().enumerate() {
					responses.add(NodeGraphMessage::CreateWire {
						output_connector,
						input_connector: InputConnector::Export(export_index),
					});
				}
				responses.add(DocumentMessage::ExitNestedNetwork { steps_back: 1 });
				for (input_index, output_connector) in input_connections.into_iter().enumerate() {
					responses.add(NodeGraphMessage::CreateWire {
						output_connector,
						input_connector: InputConnector::node_at_index(encapsulating_node_id, input_index),
					});
				}
				for (output_index, input_connectors) in output_connections.into_iter().enumerate() {
					for input_connector in input_connectors {
						responses.add(NodeGraphMessage::CreateWire {
							output_connector: OutputConnector::node(encapsulating_node_id, output_index),
							input_connector,
						});
					}
				}
				responses.add(NodeGraphMessage::DeleteNodes {
					node_ids: selected_node_ids_vec,
					delete_children: false,
				});
				responses.add(NodeGraphMessage::SelectedNodesSet { nodes: vec![encapsulating_node_id] });
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::MoveLayerToStack { layer, parent, insert_index } => {
				network_interface.move_layer_to_stack(layer, parent, insert_index, selection_network_path);
			}
			NodeGraphMessage::MoveNodeToChainStart { node_id, parent } => {
				network_interface.move_node_to_chain_start(&node_id, parent, selection_network_path, false);
			}
			NodeGraphMessage::PasteIntoChain { target, copies } => {
				let new_nodes = network_interface.paste_into_chain(target, copies, selection_network_path);
				responses.add(NodeGraphMessage::SelectedNodesAdd { nodes: new_nodes });
			}
			NodeGraphMessage::DuplicateChainNodes { node_ids, destination, select_copies } => {
				let copies = network_interface.duplicate_chain_nodes(&node_ids, destination, selection_network_path);
				if select_copies {
					responses.add(NodeGraphMessage::SelectedNodesAdd { nodes: copies });
				}
			}
			NodeGraphMessage::DuplicateNodesInFlow { node_ids } => {
				let mut copies = Vec::new();
				let mut loose_nodes = Vec::new();
				for node_id in node_ids {
					match network_interface.duplicate_node_in_flow(&node_id, selection_network_path) {
						Some(copy) => copies.push(copy),
						None => loose_nodes.push(node_id),
					}
				}
				// A copy in the flow is spliced into its original's wire, so a dot comes along only on a wire between loose copies
				let loose_nodes = network_interface.selection_with_bridging_dots(loose_nodes, selection_network_path);

				// Nodes in no flow get copies offset from their originals, keeping the wires among them, and a layer brings its content along
				if !loose_nodes.is_empty() {
					let loose_layers = loose_nodes
						.iter()
						.copied()
						.filter(|node_id| network_interface.is_layer(node_id, selection_network_path))
						.collect::<Vec<_>>();
					let layer_content = network_interface.upstream_flow_back_from_nodes(loose_layers, selection_network_path, FlowType::LayerChildrenUpstreamFlow);
					let copy_ids = loose_nodes
						.iter()
						.copied()
						.chain(layer_content)
						.collect::<HashSet<_>>()
						.into_iter()
						.enumerate()
						.map(|(index, node_id)| (node_id, NodeId(index as u64)))
						.collect::<HashMap<_, _>>();

					let nodes = network_interface.copy_nodes(&copy_ids, selection_network_path).collect::<Vec<_>>();
					let new_ids = nodes.iter().map(|(id, _)| (*id, NodeId::new())).collect::<HashMap<_, _>>();
					copies.extend(loose_nodes.iter().filter_map(|node_id| new_ids.get(copy_ids.get(node_id)?)));
					network_interface.insert_node_group(nodes, new_ids, selection_network_path);
				}

				responses.add(NodeGraphMessage::SelectedNodesAdd { nodes: copies });
			}
			NodeGraphMessage::MoveChainNodes { node_ids, layer, insert_index } => {
				network_interface.move_chain_nodes(&node_ids, layer, insert_index, selection_network_path);
			}
			NodeGraphMessage::ReorderPinnedNode { node_id, insert_index } => {
				network_interface.reorder_pinned_node(node_id, insert_index, selection_network_path);
			}
			NodeGraphMessage::SetChainPosition { node_id } => {
				network_interface.set_chain_position(&node_id, selection_network_path);
			}
			NodeGraphMessage::InsertNodes { nodes } => {
				if nodes.is_empty() {
					return;
				}

				responses.add(DocumentMessage::AddTransaction);

				let new_ids: HashMap<_, _> = nodes.iter().map(|(id, _)| (*id, NodeId::new())).collect();

				responses.add(NodeGraphMessage::AddNodes { nodes, new_ids: new_ids.clone() });

				let nodes: Vec<_> = new_ids.values().copied().collect();
				responses.add(NodeGraphMessage::SelectedNodesSet { nodes })
			}
			NodeGraphMessage::PointerDown {
				shift_click,
				control_click,
				alt_click,
				right_click,
			} => {
				if selection_network_path != breadcrumb_network_path {
					log::error!("Selection network path does not match breadcrumb network path in PointerDown");
					return;
				}
				let Some(network_metadata) = network_interface.network_metadata(selection_network_path) else {
					log::error!("Could not get network metadata in PointerDown");
					return;
				};

				let click = ipp.mouse.position;

				let node_graph_point = network_metadata.persistent_metadata.navigation_metadata.node_graph_to_viewport.inverse().transform_point2(click);

				if network_interface
					.layer_click_target_from_click(click, network_interface::LayerClickTargetTypes::Grip, selection_network_path)
					.is_some()
				{
					self.shift_without_push = true;
				}

				let clicked_id = network_interface.node_from_click(click, selection_network_path);
				let clicked_input = network_interface.input_port_from_click(click, selection_network_path);
				let clicked_output = network_interface.output_port_from_click(click, selection_network_path);
				let network_metadata = network_interface.network_metadata(selection_network_path).unwrap();
				// Create the add node menu on right click, then exit
				if right_click {
					// Pressing another button ends a run of clicks
					self.latest_left_press = None;

					// Abort dragging a node
					if self.drag_start.is_some() {
						self.drag_start = None;
						self.select_if_not_dragged = None;
						self.nodes_added_in_drag = false;
						self.clear_wire_insertion_preview(responses);
						self.stop_gliding(network_interface, responses);
						responses.add(DocumentMessage::AbortTransaction);
						responses.add(NodeGraphMessage::SelectedNodesSet {
							nodes: self.selection_before_pointer_down.clone(),
						});
						return;
					}
					// Abort dragging a dot out of a connector, before the dot has appeared
					if self.dot_drag_out.take().is_some() {
						return;
					}
					// Abort a box selection
					if self.box_selection_start.is_some() {
						self.box_selection_start = None;
						responses.add(NodeGraphMessage::SelectedNodesSet {
							nodes: self.selection_before_pointer_down.clone(),
						});
						responses.add(FrontendMessage::UpdateBox { box_selection: None });
						return;
					}
					// Abort dragging a wire
					if self.wire_in_progress_from_connector.is_some() {
						self.end_wire_in_progress(network_interface, selection_network_path, responses);
						responses.add(DocumentMessage::AbortTransaction);
						return;
					}
					// Abort reordering an import or export
					if self.is_reordering_import_export() {
						self.abort_import_export_reorder(responses);
						return;
					}

					// A subgraph's import or export, by its name or its connector
					let clicked_import_export = network_interface
						.import_export_name_from_point(node_graph_point, selection_network_path)
						.or(match (clicked_input, clicked_output) {
							(Some(InputConnector::Export(export_index)), _) if !selection_network_path.is_empty() => Some(ImportOrExport::Export(export_index)),
							(_, Some(OutputConnector::Import(import_index))) => Some(ImportOrExport::Import(import_index)),
							_ => None,
						});

					let context_menu_data = if let Some(import_or_export) = clicked_import_export {
						let (is_import, index, exposed, connected) = match import_or_export {
							ImportOrExport::Import(import_index) => {
								let exposed = selection_network_path.split_last().is_some_and(|(encapsulating_node, encapsulating_path)| {
									let encapsulating_input = InputConnector::node_at_index(*encapsulating_node, import_index);
									network_interface.input_from_connector(&encapsulating_input, encapsulating_path).is_some_and(|input| input.is_exposed())
								});
								let connected = network_interface
									.with_outward_wires(selection_network_path, |outward_wires| {
										outward_wires.get(&OutputConnector::Import(import_index)).is_some_and(|fed_inputs| !fed_inputs.is_empty())
									})
									.unwrap_or_default();
								(true, import_index, exposed, connected)
							}
							ImportOrExport::Export(export_index) => {
								let connected = network_interface.upstream_output_connector(&InputConnector::Export(export_index), selection_network_path).is_some();
								(false, export_index, true, connected)
							}
						};
						ContextMenuData::ModifyImportExport {
							is_import,
							index: index as u32,
							exposed,
							connected,
						}
					} else if let Some(node_id) = clicked_id {
						let currently_is_node = !network_interface.is_layer(&node_id, breadcrumb_network_path);
						let can_be_layer = network_interface.is_eligible_to_be_layer(&node_id, breadcrumb_network_path);

						let selected_nodes = network_interface.selected_nodes_in_nested_network(selection_network_path);
						let is_clicked_selected = selected_nodes.as_ref().is_some_and(|selected| selected.selected_nodes().any(|id| *id == node_id));

						// Right-clicking an unselected node selects just it, so selection-based actions like Merge Selected Nodes target it
						if !is_clicked_selected {
							responses.add(NodeGraphMessage::SelectedNodesSet { nodes: vec![node_id] });
						}

						// Determine which layers the Lock/Unlock action would affect:
						// - If the right-clicked node is in the selection, it affects all selected layers
						// - If the right-clicked node is not in the selection, it affects just the right-clicked node
						let affected_layer_ids = if is_clicked_selected {
							selected_nodes.map(|selected| selected.selected_nodes().copied().filter(|id| network_interface.is_layer(id, selection_network_path)).collect())
						} else {
							network_interface.is_layer(&node_id, selection_network_path).then(|| vec![node_id])
						}
						.unwrap_or_default();
						let has_selected_layers = !affected_layer_ids.is_empty();
						let all_selected_layers_locked = has_selected_layers && affected_layer_ids.iter().all(|id| network_interface.is_locked(id, selection_network_path));

						ContextMenuData::ModifyNode {
							can_be_layer,
							currently_is_node,
							node_id,
							has_selected_layers,
							all_selected_layers_locked,
						}
					} else {
						ContextMenuData::CreateNode { compatible_type: None }
					};

					// TODO: Create function
					let node_graph_shift = if matches!(context_menu_data, ContextMenuData::CreateNode { compatible_type: None }) {
						let appear_right_of_mouse = if click.x > viewport.size().x() - 180. { -180. } else { 0. };
						let appear_above_mouse = if click.y > viewport.size().y() - 200. { -200. } else { 0. };
						DVec2::new(appear_right_of_mouse, appear_above_mouse) / network_metadata.persistent_metadata.navigation_metadata.node_graph_to_viewport.matrix2.x_axis.x
					} else {
						let appear_right_of_mouse = if click.x > viewport.size().x() - 173. { -173. } else { 0. };
						let appear_above_mouse = if click.y > viewport.size().y() - 34. { -34. } else { 0. };
						DVec2::new(appear_right_of_mouse, appear_above_mouse) / network_metadata.persistent_metadata.navigation_metadata.node_graph_to_viewport.matrix2.x_axis.x
					};

					self.context_menu = Some(ContextMenuInformation {
						context_menu_coordinates: (node_graph_point + node_graph_shift).as_ivec2().into(),
						node_creation_coordinates: node_graph_point.as_ivec2().into(),
						context_menu_data,
					});

					responses.add(FrontendMessage::UpdateContextMenuInformation {
						context_menu_information: self.context_menu.clone(),
					});

					return;
				}

				// Every press starts out having moved no node and dragging no dot, wherever it lands
				self.node_has_moved_in_drag = false;
				self.dot_drag_out = None;

				// Whether this is the second press of a double-click, known as it lands rather than once the double-click arrives after its release
				let press_time = ipp.pointer_down_time();
				let is_double_press = self.latest_left_press.is_some_and(|press| press.continued_by(press_time, click));
				self.latest_left_press = Some(LeftPress {
					time: press_time,
					position: click,
					is_double: is_double_press,
					is_click: false,
				});
				self.double_click_used_by_press = false;

				// Since the user is clicking elsewhere in the graph, ensure the context menu is closed
				if self.context_menu.is_some() {
					self.context_menu = None;
					self.end_wire_in_progress(network_interface, selection_network_path, responses);

					responses.add(FrontendMessage::UpdateContextMenuInformation {
						context_menu_information: self.context_menu.clone(),
					});
				}

				if let Some(dragged_name) = network_interface.import_export_name_from_point(node_graph_point, selection_network_path) {
					responses.add(DocumentMessage::StartTransaction);
					match dragged_name {
						ImportOrExport::Import(import_index) => self.reordering_import = Some(import_index),
						ImportOrExport::Export(export_index) => self.reordering_export = Some(export_index),
					}
					// Nothing moves until the pointer does, so a click alone (like the start of a double-click to rename) leaves it in place
					self.end_index = None;
					return;
				}

				// Drag a wire out of a dimmed connector for adding an import, which adds it once the wire connects to something
				if let Some((import_index, connector_position)) = network_interface.empty_import_export_connector_at(node_graph_point, true, selection_network_path) {
					responses.add(DocumentMessage::StartTransaction);
					self.initial_disconnecting = false;
					self.wire_in_progress_from_connector = Some(connector_position);
					self.wire_in_progress_type = FrontendGraphDataType::General;
					self.wire_in_progress_from_new_import = Some(import_index);
					Self::keep_pressed_connector_lit(Some(connector_position), responses);

					self.update_node_graph_hints(responses);
					return;
				}

				// Drag a wire backward out of a dimmed connector for adding an export, which adds it once the wire connects to something
				if let Some((export_index, connector_position)) = network_interface.empty_import_export_connector_at(node_graph_point, false, selection_network_path) {
					responses.add(DocumentMessage::StartTransaction);
					self.initial_disconnecting = false;
					self.wire_in_progress_from_connector = Some(connector_position);
					self.wire_in_progress_to_connector = Some(connector_position);
					self.wire_in_progress_type = FrontendGraphDataType::General;
					self.wire_in_progress_from_new_export = Some(export_index);
					Self::keep_pressed_connector_lit(Some(connector_position), responses);

					self.update_node_graph_hints(responses);
					return;
				}

				self.selection_before_pointer_down = network_interface
					.selected_nodes_in_nested_network(selection_network_path)
					.map(|selected_nodes| selected_nodes.selected_nodes().cloned().collect())
					.unwrap_or_default();

				// Toggle visibility of clicked node and return
				if let Some(clicked_visibility) = network_interface.layer_click_target_from_click(click, network_interface::LayerClickTargetTypes::Visibility, selection_network_path) {
					responses.add(NodeGraphMessage::ToggleVisibility {
						node_id: clicked_visibility,
						network_path: selection_network_path.to_vec(),
					});
					return;
				}

				// Toggle lock of clicked node and return
				if let Some(clicked_lock) = network_interface.layer_click_target_from_click(click, network_interface::LayerClickTargetTypes::Lock, selection_network_path) {
					responses.add(NodeGraphMessage::ToggleLocked {
						node_id: clicked_lock,
						network_path: selection_network_path.to_vec(),
					});
					return;
				}

				// Alt-click sets the clicked node as previewed
				if alt_click && let Some(clicked_node) = clicked_id {
					self.preview_on_mouse_up = Some(clicked_node);
				}

				// The second press of a double-click on a connector with wires drags a redirect dot out of it, once the pointer moves far enough to place the dot
				if is_double_press && let Some(source) = Self::dot_drag_out_source(clicked_input, clicked_output, network_interface, selection_network_path) {
					self.dot_drag_out = Some((source, node_graph_point));
					self.double_click_used_by_press = true;
					return;
				}

				// Begin moving an existing wire, or drag a new one backward out of an empty input toward an output
				if let Some(clicked_input) = &clicked_input {
					responses.add(DocumentMessage::StartTransaction);
					Self::keep_pressed_connector_lit(network_interface.input_position(clicked_input, breadcrumb_network_path), responses);

					let output_connector = if *clicked_input == InputConnector::Export(0) {
						network_interface.root_node(breadcrumb_network_path).map(|root_node| root_node.to_connector())
					} else {
						network_interface.upstream_output_connector(clicked_input, breadcrumb_network_path)
					};
					let Some(output_connector) = output_connector else {
						let input_position = network_interface.input_position(clicked_input, breadcrumb_network_path);
						self.initial_disconnecting = false;
						self.wire_in_progress_from_connector = input_position;
						self.wire_in_progress_to_connector = input_position;
						self.wire_in_progress_type = network_interface.input_type(clicked_input, breadcrumb_network_path).displayed_type();
						self.wire_in_progress_from_input = Some(*clicked_input);

						self.update_node_graph_hints(responses);
						return;
					};

					self.initial_disconnecting = true;
					self.disconnecting = Some(*clicked_input);
					let output_connector = network_interface.output_past_sole_dots(output_connector, breadcrumb_network_path);
					self.wire_in_progress_from_connector = network_interface.output_position(&output_connector, breadcrumb_network_path);

					self.wire_in_progress_type = network_interface.output_type(&output_connector, breadcrumb_network_path).displayed_type();
					return;
				}

				// Begin creating a new wire
				if let Some(clicked_output) = clicked_output {
					responses.add(DocumentMessage::StartTransaction);
					self.initial_disconnecting = false;

					self.wire_in_progress_from_connector = network_interface.output_position(&clicked_output, selection_network_path);
					let output_type = network_interface.output_type(&clicked_output, breadcrumb_network_path);
					self.wire_in_progress_type = output_type.displayed_type();
					Self::keep_pressed_connector_lit(self.wire_in_progress_from_connector, responses);

					self.update_node_graph_hints(responses);
					return;
				}

				if let Some(clicked_id) = clicked_id {
					let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
						log::error!("Could not get selected nodes in PointerDown");
						return;
					};
					let mut updated_selected = selected_nodes.selected_nodes().cloned().collect::<Vec<_>>();
					let mut modified_selected = false;

					// Add to/remove from selection if holding Shift or Ctrl
					if shift_click || control_click {
						modified_selected = true;

						let index = updated_selected.iter().enumerate().find_map(|(i, node_id)| if *node_id == clicked_id { Some(i) } else { None });
						// Remove from selection (on PointerUp) if already selected
						self.deselect_on_pointer_up = index;

						// Add to selection if not already selected. Necessary in order to drag multiple nodes
						if index.is_none() {
							updated_selected.push(clicked_id);
						};
					}
					// Replace selection with a non-selected node
					else if !updated_selected.contains(&clicked_id) {
						modified_selected = true;
						updated_selected = vec![clicked_id];
					}
					// Replace selection (of multiple nodes including this one) with just this one, but only upon pointer up if the user didn't drag the selected nodes
					else {
						self.select_if_not_dragged = Some(clicked_id);
					}

					// If this node is selected (whether from before or just now), prepare it for dragging
					if updated_selected.contains(&clicked_id) {
						let drag_start = DragStart {
							start_x: node_graph_point.x,
							start_y: node_graph_point.y,
							round_x: 0,
							round_y: 0,
						};

						self.drag_start = Some((drag_start, false));
						let selected_chain_nodes = updated_selected
							.iter()
							.filter(|node_id| network_interface.is_chain(node_id, selection_network_path))
							.copied()
							.collect::<Vec<_>>();
						self.drag_start_chain_nodes = selected_chain_nodes
							.iter()
							.flat_map(|selected| {
								network_interface
									.upstream_flow_back_from_nodes(vec![*selected], selection_network_path, FlowType::PrimaryFlow)
									.skip(1)
									.filter(|node_id| network_interface.is_chain(node_id, selection_network_path))
							})
							.collect::<Vec<_>>();
						self.begin_dragging = true;
						self.nodes_added_in_drag = false;
						self.update_node_graph_hints(responses);
					}

					// Update the selection if it was modified
					if modified_selected {
						responses.add(NodeGraphMessage::SelectedNodesSet { nodes: updated_selected })
					}
					// Start the transaction after setting the node, since when the transactions ends it aborts any changes after this
					responses.add(DocumentMessage::StartTransaction);

					return;
				}

				// The second press of a double-click on a wire splits it with a redirect dot, which the press goes on to drag
				if is_double_press && let Some(input_connector) = Self::wire_at_point(node_graph_point, network_interface, preferences.graph_wire_style, selection_network_path) {
					let dot = NodeId::new();
					let center = (node_graph_point / GRID_SIZE as f64).round().as_ivec2();

					responses.add(DocumentMessage::StartTransaction);
					responses.add(NodeGraphMessage::InsertDotOnWire {
						node_id: dot,
						input_connector,
						x: center.x,
						y: center.y,
					});
					self.drag_new_dot(dot, node_graph_point, IVec2::ZERO, responses);
					self.double_click_used_by_press = true;
					return;
				}

				// Clicked on the graph background so we box select
				if !shift_click && !alt_click {
					responses.add(NodeGraphMessage::SelectedNodesSet { nodes: Vec::new() })
				}
				self.box_selection_start = Some((node_graph_point, false));
				self.update_node_graph_hints(responses);
			}
			NodeGraphMessage::PointerMove { shift } => {
				if selection_network_path != breadcrumb_network_path {
					log::error!("Selection network path does not match breadcrumb network path in PointerMove");
					return;
				}
				let Some(network_metadata) = network_interface.network_metadata(selection_network_path) else {
					return;
				};

				// Auto-panning, only while dragging since hovering also moves the pointer here
				if self.drag_start.is_some() || self.box_selection_start.is_some() || self.wire_in_progress_from_connector.is_some() {
					let messages = [NodeGraphMessage::PointerOutsideViewport { shift }.into(), NodeGraphMessage::PointerMove { shift }.into()];
					self.auto_panning.setup_by_mouse_position(ipp, viewport, &messages, responses);
				}

				let viewport_location = ipp.mouse.position;
				let point = network_metadata
					.persistent_metadata
					.navigation_metadata
					.node_graph_to_viewport
					.inverse()
					.transform_point2(viewport_location);

				if let Some((source, press_point)) = self.dot_drag_out {
					// The dot appears once the grid point nearest the pointer differs from where the press began, and is dragged on from there
					let moved = ((point - press_point) / GRID_SIZE as f64).round().as_ivec2();
					if moved != IVec2::ZERO {
						self.dot_drag_out = None;

						let dot = NodeId::new();
						let center = (press_point / GRID_SIZE as f64).round().as_ivec2() + moved;
						let (x, y) = (center.x, center.y);

						responses.add(DocumentMessage::StartTransaction);
						responses.add(match source {
							DotDragOutSource::Output(output_connector) => NodeGraphMessage::InsertDotOnOutput { node_id: dot, output_connector, x, y },
							DotDragOutSource::Export(export_index) => NodeGraphMessage::InsertDotOnWire {
								node_id: dot,
								input_connector: InputConnector::Export(export_index),
								x,
								y,
							},
						});
						self.drag_new_dot(dot, press_point, moved, responses);
					}
				} else if self.wire_in_progress_from_connector.is_some() && self.context_menu.is_none() && self.wire_in_progress_is_backward() {
					// A wire dragged backward keeps its input end in place and snaps its loose end to an output, or to a dimmed connector for adding an import
					let output_position = network_interface
						.output_connector_from_click(ipp.mouse.position, selection_network_path)
						.and_then(|output_connector| network_interface.output_position(&output_connector, selection_network_path));
					let empty_import_position = || network_interface.empty_import_export_connector_at(point, true, selection_network_path).map(|(_, position)| position);
					let snapped_position = output_position.or_else(empty_import_position);
					self.wire_in_progress_from_connector = Some(snapped_position.unwrap_or(point));

					self.send_wire_in_progress(self.wire_in_progress_from_input, snapped_position.is_some(), network_interface, selection_network_path, responses);
				} else if self.wire_in_progress_from_connector.is_some() && self.context_menu.is_none() {
					let to_connector = network_interface.input_connector_from_click(ipp.mouse.position, selection_network_path);
					let empty_export_position = to_connector
						.is_none()
						.then(|| network_interface.empty_import_export_connector_at(point, false, selection_network_path))
						.flatten()
						.map(|(_, position)| position);
					if let Some(to_connector) = &to_connector {
						let Some(input_position) = network_interface.input_position(to_connector, selection_network_path) else {
							log::error!("Could not get input position for connector: {to_connector:?}");
							return;
						};
						self.wire_in_progress_to_connector = Some(input_position);
					}
					// Snap to a dimmed connector for adding an export, which a wire dropped on adds
					else if let Some(empty_export_position) = empty_export_position {
						self.wire_in_progress_to_connector = Some(empty_export_position);
					}
					// Not hovering over a node input or node output, update with the mouse position.
					else {
						self.wire_in_progress_to_connector = Some(point);
						// Disconnect if the wire was previously connected to an input
						if let Some(disconnecting) = &self.disconnecting {
							let mut disconnect_root_node = false;
							if let Previewing::Yes { root_node_to_restore } = network_interface.previewing(selection_network_path)
								&& root_node_to_restore.is_some()
								&& *disconnecting == InputConnector::Export(0)
							{
								disconnect_root_node = true;
							}
							if disconnect_root_node {
								responses.add(NodeGraphMessage::DisconnectRootNode);
							} else {
								responses.add(NodeGraphMessage::DisconnectInput { input_connector: *disconnecting });
							}
							// Picking up a wire from the end of a dot leaves that dot with nothing to redirect
							responses.add(NodeGraphMessage::RemoveOrphanedDots);
							// Update the frontend that the node is disconnected
							responses.add(NodeGraphMessage::RunDocumentGraph);
							responses.add(NodeGraphMessage::SendGraph);
							self.disconnecting = None;
						}
					}

					let loose_end_snapped = to_connector.is_some() || empty_export_position.is_some();
					self.send_wire_in_progress(to_connector, loose_end_snapped, network_interface, selection_network_path, responses);

					// Input connectors stick out past their node's edge, so hovering one counts as hovering its node
					let wire_hovered_node = to_connector
						.and_then(|input_connector| input_connector.node_id())
						.or_else(|| network_interface.node_from_click(viewport_location, selection_network_path))
						// Exposing a parameter of a layer would turn it into a node
						.filter(|node_id| !network_interface.is_layer(node_id, selection_network_path));
					self.set_wire_hovered_node(wire_hovered_node.map(|node_id| (node_id, ipp.time)), network_interface, selection_network_path, responses);
				} else if let Some((drag_start, dragged)) = &mut self.drag_start {
					if drag_start.start_x != point.x || drag_start.start_y != point.y {
						*dragged = true;
					}

					if self.begin_dragging {
						self.begin_dragging = false;
						// Duplicate nodes inline within the existing PointerDown transaction.
						// This means a completed Alt-drag is one undo step, and aborting (right-click / Escape)
						// rolls back both the duplication and the move with a single plain AbortTransaction.
						if ipp.keyboard.get(Key::Alt as usize) && Self::duplicate_selected_nodes(network_interface, selection_network_path, responses) {
							// Duplicating sets a 2x2 offset, so shift the nodes back to the original position
							responses.add(NodeGraphMessage::ShiftSelectedNodesByAmount {
								graph_delta: IVec2::new(-2, -2),
								rubber_band: false,
								glide: false,
							});
							self.preview_on_mouse_up = None;
							self.nodes_added_in_drag = true;
						}
					}

					let mut graph_delta = IVec2::new(((point.x - drag_start.start_x) / 24.).round() as i32, ((point.y - drag_start.start_y) / 24.).round() as i32);
					let previous_round_x = drag_start.round_x;
					let previous_round_y = drag_start.round_y;

					drag_start.round_x = graph_delta.x;
					drag_start.round_y = graph_delta.y;

					graph_delta.x -= previous_round_x;
					graph_delta.y -= previous_round_y;

					responses.add(NodeGraphMessage::ShiftSelectedNodesByAmount {
						graph_delta,
						rubber_band: true,
						glide: true,
					});
					if graph_delta != IVec2::ZERO {
						self.node_has_moved_in_drag = true;

						// Queued after the shift so it reads where the node has come to rest
						responses.add(NodeGraphMessage::UpdateWireInsertionPreview);
					}

					self.update_node_graph_hints(responses);
				} else if let Some((_, box_selection_dragged)) = &mut self.box_selection_start {
					*box_selection_dragged = true;
					responses.add(NodeGraphMessage::UpdateBoxSelection);
					self.update_node_graph_hints(responses);
				} else if self.is_reordering_import_export() {
					let reordering_import = self.reordering_import.is_some();
					self.end_index = network_interface.import_export_drop_position(point.y, reordering_import, selection_network_path);

					if reordering_import {
						responses.add(FrontendMessage::UpdateImportReorderIndex { index: self.end_index });
					} else {
						responses.add(FrontendMessage::UpdateExportReorderIndex { index: self.end_index });
					}
					self.update_node_graph_hints(responses);
				}

				responses.add(NodeGraphMessage::UpdateHoveredConnector);
			}
			NodeGraphMessage::PointerUp => {
				// A press released where it was made is a click, which a second press soon after can make a double-click
				if let Some(press) = &mut self.latest_left_press {
					press.is_click = press.position.distance(ipp.mouse.position) <= DOUBLE_CLICK_ALLOWED_TRAVEL;
				}

				// A double-press released before the pointer moved far enough to drag a dot out of its connector leaves the wires as they were
				self.dot_drag_out = None;

				if selection_network_path != breadcrumb_network_path {
					log::error!("Selection network path does not match breadcrumb network path in PointerUp");
					return;
				}
				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
					log::error!("Could not get selected nodes in PointerUp");
					return;
				};
				let Some(network_metadata) = network_interface.network_metadata(selection_network_path) else {
					warn!("No network_metadata");
					return;
				};

				if let Some(preview_node) = self.preview_on_mouse_up {
					responses.add(NodeGraphMessage::TogglePreview { node_id: preview_node });
					self.preview_on_mouse_up = None;
				}
				if let Some(node_to_deselect) = self.deselect_on_pointer_up.take()
					&& !self.drag_start.as_ref().is_some_and(|t| t.1)
				{
					let mut new_selected_nodes = selected_nodes.selected_nodes_ref().clone();
					new_selected_nodes.remove(node_to_deselect);
					responses.add(NodeGraphMessage::SelectedNodesSet { nodes: new_selected_nodes });
					return;
				}
				let point = network_metadata
					.persistent_metadata
					.navigation_metadata
					.node_graph_to_viewport
					.inverse()
					.transform_point2(ipp.mouse.position);
				// Disconnect if the wire was previously connected to an input
				if let (Some(wire_in_progress_from_connector), Some(wire_in_progress_to_connector)) = (self.wire_in_progress_from_connector, self.wire_in_progress_to_connector) {
					// Check if dragged connector is reconnected to another input
					let node_graph_to_viewport = network_metadata.persistent_metadata.navigation_metadata.node_graph_to_viewport;
					let from_connector_viewport = node_graph_to_viewport.transform_point2(wire_in_progress_from_connector);
					let to_connector_viewport = node_graph_to_viewport.transform_point2(wire_in_progress_to_connector);
					let backward = self.wire_in_progress_is_backward();

					// The wire's output end, or else the import to add for it at a dimmed connector for adding one
					let output_connector = network_interface.output_connector_from_click(from_connector_viewport, selection_network_path);
					let new_import_index = match backward {
						true => output_connector
							.is_none()
							.then(|| network_interface.empty_import_export_connector_at(wire_in_progress_from_connector, true, selection_network_path))
							.flatten()
							.map(|(import_index, _)| import_index),
						false => self.wire_in_progress_from_new_import,
					};

					// The wire's input end, or else the export to add for it at a dimmed connector for adding one
					let (input_connector, new_export_index) = match backward {
						true => (self.wire_in_progress_from_input, self.wire_in_progress_from_new_export),
						false => {
							let input_connector = network_interface.input_connector_from_click(to_connector_viewport, selection_network_path);
							let new_export_index = input_connector
								.is_none()
								.then(|| network_interface.empty_import_export_connector_at(wire_in_progress_to_connector, false, selection_network_path))
								.flatten()
								.map(|(export_index, _)| export_index);
							(input_connector, new_export_index)
						}
					};

					// Collapse now rather than when the wire ends, since the node creation menu can keep the wire alive
					let connected_input = output_connector.and(input_connector);
					self.collapse_wire_expanded_node(connected_input, network_interface, selection_network_path, responses);
					self.set_wire_hovered_node(None, network_interface, selection_network_path, responses);

					// With both ends at connectors, they're wired together, adding a new import or export first if one stands in for it
					let input_end = input_connector.or(new_export_index.map(InputConnector::Export));
					if let Some(input_connector) = input_end
						&& (output_connector.is_some() || new_import_index.is_some())
					{
						if let Some(export_index) = new_export_index {
							responses.add(add_export_at(export_index));
						}

						if let Some(import_index) = new_import_index {
							responses.add(NodeGraphMessage::AddImportAndConnect { import_index, input_connector });
						}
						// Dropped back on the input it was picked up from without ever leaving, the wire stays as it was, along with any dots it runs through
						else if let Some(output_connector) = output_connector
							&& self.disconnecting != Some(input_connector)
						{
							responses.add(NodeGraphMessage::CreateWire { output_connector, input_connector });
							responses.add(NodeGraphMessage::RunDocumentGraph);
							responses.add(NodeGraphMessage::SendGraph);
						}

						// Moving a wire off a dot can leave that dot with nothing to redirect
						responses.add(NodeGraphMessage::RemoveOrphanedDots);
					}
					// With its loose end dropped elsewhere, the node creation menu opens for a node to wire it to, unless a backward wire was only clicked
					else if !self.initial_disconnecting
						&& (output_connector.is_some() || new_import_index.is_some() || (backward && wire_in_progress_from_connector != wire_in_progress_to_connector))
					{
						// If the add node menu is already open, we don't want to open it again
						if self.context_menu.is_some() {
							return;
						}

						let Some(network_metadata) = network_interface.network_metadata(selection_network_path) else {
							warn!("No network_metadata");
							return;
						};

						let appear_right_of_mouse = if ipp.mouse.position.x > viewport.size().x() - 173. { -173. } else { 0. };
						let appear_above_mouse = if ipp.mouse.position.y > viewport.size().y() - 34. { -34. } else { 0. };
						let node_graph_shift = DVec2::new(appear_right_of_mouse, appear_above_mouse) / network_metadata.persistent_metadata.navigation_metadata.node_graph_to_viewport.matrix2.x_axis.x;

						// A forward wire offers the nodes taking its type, with the new node's input where it was dropped.
						// A backward wire offers every node, with the new node's output (on its right, five grid cells across) where it was dropped.
						// TODO: Filter both directions to the nodes that fit, decided in the backend with the conversion-aware type checks from https://github.com/GraphiteEditor/Graphite/pull/4688
						let (compatible_type, node_creation_point) = match (backward, output_connector) {
							(false, Some(output_connector)) => (network_interface.output_type(&output_connector, selection_network_path).add_node_string(), point),
							(false, None) => (None, point),
							(true, _) => (None, point - DVec2::new((5 * GRID_SIZE) as f64, 0.)),
						};

						self.context_menu = Some(ContextMenuInformation {
							context_menu_coordinates: (point + node_graph_shift).as_ivec2().into(),
							node_creation_coordinates: node_creation_point.as_ivec2().into(),
							context_menu_data: ContextMenuData::CreateNode { compatible_type },
						});

						responses.add(FrontendMessage::UpdateContextMenuInformation {
							context_menu_information: self.context_menu.clone(),
						});
						return;
					}
				}
				// End of dragging a node
				else if let Some((drag_start, _)) = &self.drag_start {
					self.shift_without_push = false;

					// Reset all offsets to end the rubber banding while dragging
					network_interface.clear_drag_offsets(selection_network_path);
					let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
						log::error!("Could not get selected nodes in PointerUp");
						return;
					};

					// Only select clicked node if multiple are selected and they were not dragged
					if let Some(select_if_not_dragged) = self.select_if_not_dragged {
						let not_dragged = drag_start.start_x == point.x && drag_start.start_y == point.y;
						if not_dragged
							&& (selected_nodes.selected_nodes_ref().len() != 1
								|| selected_nodes
									.selected_nodes_ref()
									.first()
									.is_some_and(|first_selected_node| *first_selected_node != select_if_not_dragged))
						{
							responses.add(NodeGraphMessage::SelectedNodesSet { nodes: vec![select_if_not_dragged] })
						}
					}

					// Try expand the upstream chain for all layers if there is an eligible node
					let Some(network) = network_interface.nested_network(selection_network_path) else { return };
					for layer in network
						.nodes
						.keys()
						.filter(|node_id| network_interface.is_layer(node_id, selection_network_path))
						.cloned()
						.collect::<Vec<_>>()
					{
						network_interface.try_set_upstream_to_chain(&InputConnector::layer_secondary_input(layer), selection_network_path);
					}
					responses.add(NodeGraphMessage::SendGraph);

					// Check if a single node was dragged onto a wire and that the node was dragged onto the wire
					if !self.begin_dragging
						&& let Some((selected_node_id, insert_node_input_index, overlapping_wire)) = Self::wire_to_insert_on(network_interface, preferences.graph_wire_style, selection_network_path)
					{
						responses.add(NodeGraphMessage::InsertNodeBetween {
							node_id: selected_node_id,
							input_connector: overlapping_wire,
							insert_node_input_index,
						});
						responses.add(NodeGraphMessage::RunDocumentGraph);
						responses.add(NodeGraphMessage::SendGraph);
					}
					self.select_if_not_dragged = None;
				}
				// End of reordering an import
				else if let (Some(moving_import), Some(end_index)) = (self.reordering_import, self.end_index) {
					responses.add(NodeGraphMessage::ReorderImport {
						start_index: moving_import,
						end_index,
					});
					responses.add(DocumentMessage::EndTransaction);
				}
				// End of reordering an export
				else if let (Some(moving_export), Some(end_index)) = (self.reordering_export, self.end_index) {
					responses.add(NodeGraphMessage::ReorderExport {
						start_index: moving_export,
						end_index,
					});
					responses.add(DocumentMessage::EndTransaction);
				}

				self.drag_start = None;
				self.begin_dragging = false;
				self.nodes_added_in_drag = false;
				self.clear_wire_insertion_preview(responses);
				self.box_selection_start = None;

				self.end_wire_in_progress(network_interface, selection_network_path, responses);

				self.reordering_export = None;
				self.reordering_import = None;
				self.end_index = None;

				responses.add(DocumentMessage::EndTransaction);
				responses.add(FrontendMessage::UpdateBox { box_selection: None });
				responses.add(FrontendMessage::UpdateImportReorderIndex { index: None });
				responses.add(FrontendMessage::UpdateExportReorderIndex { index: None });
				self.update_node_graph_hints(responses);
			}
			NodeGraphMessage::PointerOutsideViewport { shift } => {
				if self.drag_start.is_some() || self.box_selection_start.is_some() || (self.wire_in_progress_from_connector.is_some() && self.context_menu.is_none()) {
					let _ = self.auto_panning.shift_viewport(ipp, viewport, responses);
				} else {
					// Auto-panning
					let messages = [NodeGraphMessage::PointerOutsideViewport { shift }.into(), NodeGraphMessage::PointerMove { shift }.into()];
					self.auto_panning.stop(&messages, responses);
				}
			}
			NodeGraphMessage::WireHoverTick => {
				self.expand_wire_hovered_node_after_delay(ipp.time, network_interface, selection_network_path, responses);
			}
			NodeGraphMessage::SendGlide => {
				let glide_offsets = network_interface.glide_offsets(&self.glide_network_path);
				Self::send_glide(&glide_offsets, &glide_offsets, network_interface, preferences.graph_wire_style, &self.glide_network_path, responses);
			}
			NodeGraphMessage::GlideTick => {
				// A document switched to from one that was gliding inherits its frame subscription, which it ends
				if !self.glide_tick_subscribed {
					responses.add(BroadcastMessage::UnsubscribeEvent {
						on: EventMessage::AnimationFrame,
						send: Box::new(NodeGraphMessage::GlideTick.into()),
					});
					return;
				}

				if !graph_view_overlay_open || self.glide_network_path != breadcrumb_network_path {
					self.stop_gliding(network_interface, responses);
					return;
				}

				// Whatever settles this frame still needs its wires sent once more, to meet it where it sits
				let was_gliding = network_interface.glide_offsets(&self.glide_network_path);
				let mut glide_offsets = was_gliding.clone();

				// Each offset shrinks exponentially, which eases the node in and keeps up with a drag that moves it again before it settles
				if let Some(last_tick_time) = self.glide_last_tick_time {
					let elapsed = ipp.time.saturating_sub(last_tick_time) as f64;
					glide_offsets.shrink((-elapsed / NODE_GLIDE_TIME_CONSTANT_MILLISECONDS).exp());
				}
				self.glide_last_tick_time = Some(ipp.time);
				network_interface.set_glide_offsets(glide_offsets.clone(), &self.glide_network_path);

				Self::send_glide(&glide_offsets, &was_gliding, network_interface, preferences.graph_wire_style, &self.glide_network_path, responses);
				if glide_offsets.is_empty() {
					self.set_glide_tick_subscribed(false, responses);
				}
			}
			NodeGraphMessage::ShakeNode => {
				let Some((drag_start, _)) = &mut self.drag_start else {
					log::error!("Drag start should be initialized when shaking a node");
					return;
				};

				let Some(network_metadata) = network_interface.network_metadata(selection_network_path) else {
					return;
				};

				let viewport_location = ipp.mouse.position;
				let point = network_metadata
					.persistent_metadata
					.navigation_metadata
					.node_graph_to_viewport
					.inverse()
					.transform_point2(viewport_location);

				// Collect the distance to move the shaken nodes after the undo
				let graph_delta = IVec2::new(((point.x - drag_start.start_x) / 24.).round() as i32, ((point.y - drag_start.start_y) / 24.).round() as i32);

				if !self.nodes_added_in_drag {
					// Keep the incremental rounding baseline in sync with the total shift reapplied below
					drag_start.round_x = graph_delta.x;
					drag_start.round_y = graph_delta.y;

					// Undo to the state of the graph before shaking (skipped when the drag added its nodes, which the undo would remove)
					responses.add(DocumentMessage::AbortTransaction);

					// Add a history step to abort to the state before shaking if right clicked
					responses.add(DocumentMessage::StartTransaction);
				}

				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
					log::error!("Could not get selected nodes in ShakeNode");
					return;
				};

				let mut all_selected_nodes = selected_nodes.0.iter().copied().collect::<HashSet<_>>();
				for selected_layer in selected_nodes
					.0
					.iter()
					.filter(|selected_node| network_interface.is_layer(selected_node, selection_network_path))
					.copied()
					.collect::<Vec<_>>()
				{
					for sole_dependent in network_interface.upstream_nodes_below_layer(&selected_layer, selection_network_path) {
						all_selected_nodes.insert(sole_dependent);
					}
				}

				// A redirect dot is part of the wire it bends, so it's shaken out only along with a wire running between two shaken nodes, and otherwise stays in its wire
				let all_selected_nodes = network_interface
					.selection_with_bridging_dots(all_selected_nodes.into_iter().collect(), selection_network_path)
					.into_iter()
					.collect::<HashSet<_>>();

				let previewing = network_interface.previewing(selection_network_path);
				for selected_node in &all_selected_nodes {
					// Handle inputs of selected node
					for input_index in 0..network_interface.number_of_inputs(selected_node, selection_network_path) {
						let input_connector = InputConnector::node_at_index(*selected_node, input_index);
						// Only disconnect inputs to non selected nodes
						if network_interface
							.upstream_output_connector(&input_connector, selection_network_path)
							.is_some_and(|connector| connector.node_id().is_none_or(|node_id| !all_selected_nodes.contains(&node_id)))
						{
							responses.add(NodeGraphMessage::DisconnectInput { input_connector });
						}
					}

					// Walk upstream through the shaken nodes' first exposed inputs to the first output outside them, as deleting them would reconnect
					let upstream_of = |node_id: &NodeId| {
						network_interface
							.first_exposed_input(node_id, selection_network_path)
							.and_then(|input| network_interface.upstream_output_connector(&input, selection_network_path))
					};
					let mut first_deselected_upstream_output = upstream_of(selected_node);
					while let Some(OutputConnector::Node { node_id, .. }) = first_deselected_upstream_output
						&& all_selected_nodes.contains(&node_id)
					{
						first_deselected_upstream_output = upstream_of(&node_id);
					}

					// While previewing, the export's eventual return to this node is a connection too, so it moves upstream as well
					if let Some(OutputConnector::Node { node_id, output_index }) = first_deselected_upstream_output
						&& let Previewing::Yes {
							root_node_to_restore: Some(root_node_to_restore),
						} = previewing && root_node_to_restore.to_connector() == OutputConnector::primary_output(*selected_node)
					{
						responses.add(NodeGraphMessage::SetRootNodeToRestore {
							root_node_to_restore: RootNode { node_id, output_index },
						});
					}

					let number_of_outputs = network_interface.number_of_outputs(selected_node, selection_network_path);
					let Some(outward_wires) = network_interface.outward_wires(selection_network_path) else {
						log::error!("Could not get output wires in shake input");
						continue;
					};

					// What fed the shaken nodes takes over each wire their primary output fed outside them, and their other wires out to nodes are disconnected
					let mut taken_over_inputs = Vec::new();
					for output_index in 0..number_of_outputs {
						let Some(downstream_connections) = outward_wires.get(&OutputConnector::node(*selected_node, output_index)) else {
							continue;
						};
						for &input_connector in downstream_connections {
							if input_connector.node_id().is_some_and(|downstream_node| all_selected_nodes.contains(&downstream_node)) {
								continue;
							}

							match first_deselected_upstream_output.filter(|_| output_index == 0) {
								Some(_) => taken_over_inputs.push(input_connector),
								None if input_connector.node_id().is_some() => responses.add(NodeGraphMessage::DisconnectInput { input_connector }),
								// An export with nothing to take over its wire is left fed by the shaken node
								None => {}
							}
						}
					}
					// Wired together, so an import taking over several exports feeds them all through one dot
					if let Some(output_connector) = first_deselected_upstream_output
						&& !taken_over_inputs.is_empty()
					{
						responses.add(NodeGraphMessage::CreateWires {
							output_connector,
							input_connectors: taken_over_inputs,
						});
					}

					// Set all chain nodes back to chain position
					// TODO: Fix
					// for chain_node_to_reset in std::mem::take(&mut self.drag_start_chain_nodes) {
					// 	responses.add(NodeGraphMessage::SetChainPosition { node_id: chain_node_to_reset });
					// }
				}
				if !self.nodes_added_in_drag {
					responses.add(NodeGraphMessage::ShiftSelectedNodesByAmount {
						graph_delta,
						rubber_band: false,
						glide: false,
					});
				}
				// A dot left with nothing to carry, like one fed by a shaken generator, goes along with its wire
				responses.add(NodeGraphMessage::RemoveOrphanedDots);
				// Freed of its output wire, the node may now fit onto the wire beneath it
				responses.add(NodeGraphMessage::UpdateWireInsertionPreview);
				responses.add(NodeGraphMessage::RunDocumentGraph);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::UpdateNodeGraphWidth => {
				network_interface.set_node_graph_width(viewport.size().x(), breadcrumb_network_path);
				responses.add(NodeGraphMessage::UpdateImportsExports);
			}
			NodeGraphMessage::RemoveImport { import_index: usize } => {
				network_interface.remove_import(usize, selection_network_path);
				responses.add(NodeGraphMessage::UpdateImportsExports);
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::RemoveExport { export_index: usize } => {
				network_interface.remove_export(usize, selection_network_path);
				responses.add(NodeGraphMessage::UpdateImportsExports);
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::RemoveImportExport { index } => responses.add(match index {
				ImportOrExport::Import(0) => NodeGraphMessage::ExposeEncapsulatingInput { input_index: 0, exposed: false },
				ImportOrExport::Export(0) => NodeGraphMessage::ExposePrimaryExport { exposed: false },
				ImportOrExport::Import(import_index) => NodeGraphMessage::RemoveImport { import_index },
				ImportOrExport::Export(export_index) => NodeGraphMessage::RemoveExport { export_index },
			}),
			NodeGraphMessage::ReorderImport { start_index, end_index } => {
				let primary_was_empty = network_interface.hidden_primary_import(breadcrumb_network_path);
				network_interface.reorder_import(start_index, end_index, breadcrumb_network_path);

				if end_index == 0 {
					// An empty primary is filled, rather than being pushed down to become a secondary import
					if primary_was_empty && start_index != 0 {
						network_interface.remove_import(1, breadcrumb_network_path);
					}

					// The primary input is always exposed, so a parameter moved there becomes a connector
					responses.add(NodeGraphMessage::ExposeEncapsulatingInput { input_index: 0, exposed: true });
				}
				// The primary moved among the secondary imports leaves an empty primary in its place, rather than promoting the next one
				else if start_index == 0 {
					network_interface.add_import(TaggedValue::None, false, -1, "", "", breadcrumb_network_path);
					let added_index = network_interface.number_of_imports(breadcrumb_network_path) - 1;
					network_interface.reorder_import(added_index, 0, breadcrumb_network_path);
				}

				responses.add(NodeGraphMessage::UpdateImportsExports);
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::ReorderExport { start_index, end_index } => {
				let primary_was_empty = network_interface.hidden_primary_export(breadcrumb_network_path);
				network_interface.reorder_export(start_index, end_index, breadcrumb_network_path);

				// An empty primary is filled, rather than being pushed down to become a secondary export
				if end_index == 0 && primary_was_empty && start_index != 0 {
					network_interface.remove_export(1, breadcrumb_network_path);
				}
				// The primary moved among the secondary exports leaves an empty primary in its place, rather than promoting the next one
				else if end_index != 0 && start_index == 0 {
					network_interface.add_export(TaggedValue::None, -1, "", breadcrumb_network_path);
					let added_index = network_interface.number_of_exports(breadcrumb_network_path) - 1;
					network_interface.reorder_export(added_index, 0, breadcrumb_network_path);
					network_interface.set_input(&InputConnector::Export(0), NodeInput::value(TaggedValue::None, false), breadcrumb_network_path);
				}

				responses.add(NodeGraphMessage::UpdateImportsExports);
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::RunDocumentGraph => {
				responses.add(PortfolioMessage::SubmitGraphRender { document_id, ignore_hash: false });
			}
			NodeGraphMessage::ForceRunDocumentGraph => {
				responses.add(PortfolioMessage::SubmitGraphRender { document_id, ignore_hash: true });
			}
			NodeGraphMessage::SelectedNodesAdd { nodes } => {
				let Some(selected_nodes) = network_interface.selected_nodes_mut(selection_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::SelectedNodesAdd");
					return;
				};
				selected_nodes.add_selected_nodes(nodes);
				responses.add(EventMessage::SelectionChanged);
			}
			NodeGraphMessage::SelectedNodesRemove { nodes } => {
				let Some(selected_nodes) = network_interface.selected_nodes_mut(selection_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::SelectedNodesRemove");
					return;
				};
				selected_nodes.retain_selected_nodes(|node| !nodes.contains(node));
				responses.add(EventMessage::SelectionChanged);
			}
			NodeGraphMessage::SelectedNodesSet { nodes } => {
				let Some(selected_nodes) = network_interface.selected_nodes_mut(selection_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::SelectedNodesSet");
					return;
				};
				selected_nodes.set_selected_nodes(nodes);
				responses.add(EventMessage::SelectionChanged);
			}
			NodeGraphMessage::SendClickTargets => responses.add(FrontendMessage::UpdateClickTargets {
				click_targets: Some(network_interface.collect_frontend_click_targets(breadcrumb_network_path)),
			}),
			NodeGraphMessage::EndSendClickTargets => responses.add(FrontendMessage::UpdateClickTargets { click_targets: None }),
			NodeGraphMessage::UnloadWires => {
				for input in network_interface.node_graph_input_connectors(breadcrumb_network_path) {
					network_interface.unload_wire(&input, breadcrumb_network_path);
				}

				responses.add(FrontendMessage::ClearAllNodeGraphWires);
			}
			NodeGraphMessage::SendWires => {
				let mut wires = self.collect_wires(network_interface, preferences.graph_wire_style, breadcrumb_network_path);

				// The dispatcher defers this past any glide update in the same batch, so the wires following whatever glides must come last here too
				let glide_offsets = network_interface.glide_offsets(breadcrumb_network_path);
				if !glide_offsets.is_empty() {
					wires.extend(Self::gliding_wires(
						&glide_offsets,
						&glide_offsets,
						network_interface,
						preferences.graph_wire_style,
						breadcrumb_network_path,
					));
				}

				responses.add(FrontendMessage::UpdateNodeGraphWires { wires });
			}
			NodeGraphMessage::UpdateVisibleNodes => {
				let Some(network_metadata) = network_interface.network_metadata(breadcrumb_network_path) else {
					return;
				};

				let viewport_bbox = [DVec2::ZERO, viewport.size().into_dvec2()];
				let document_bbox: [DVec2; 2] = viewport_bbox.map(|p| network_metadata.persistent_metadata.navigation_metadata.node_graph_to_viewport.inverse().transform_point2(p));

				let mut nodes = Vec::new();
				for node_id in &self.frontend_nodes {
					let Some(node_bbox) = network_interface.node_bounding_box(node_id, breadcrumb_network_path) else {
						log::error!("Could not get bbox for node: {node_id:?}");
						continue;
					};

					// Expand the cull box by a grid cell so a node stays rendered until its connectors, which reach beyond its bounding box, also leave the viewport
					let cull_margin = 24.;
					if node_bbox[1].x + cull_margin >= document_bbox[0].x
						&& node_bbox[0].x - cull_margin <= document_bbox[1].x
						&& node_bbox[1].y + cull_margin >= document_bbox[0].y
						&& node_bbox[0].y - cull_margin <= document_bbox[1].y
					{
						nodes.push(*node_id);
					}
					for error in &network_interface.resolved_types.node_graph_errors {
						if error.node_path.contains(node_id) {
							nodes.push(*node_id);
						}
					}
					if self.evaluation_errors.iter().any(|error| error.node_path.contains(node_id)) {
						nodes.push(*node_id);
					}
				}

				layers_in_view.set_node_graph(nodes.iter().copied().collect(), responses);
				responses.add(FrontendMessage::UpdateVisibleNodes { nodes });
			}
			NodeGraphMessage::SendGraph => {
				responses.add(NodeGraphMessage::UpdateLayerPanel);
				responses.add(DocumentMessage::DocumentStructureChanged);
				responses.add(InspectorMessage::Refresh);
				responses.add(EventMessage::GraphChanged);
				if breadcrumb_network_path == selection_network_path && graph_view_overlay_open {
					let nodes = self.collect_nodes(network_interface, breadcrumb_network_path);
					self.frontend_nodes = nodes.iter().map(|node| node.id).collect();
					responses.add(FrontendMessage::UpdateNodeGraphNodes { nodes });

					let errors = self.node_graph_errors(network_interface, breadcrumb_network_path);
					responses.add(FrontendMessage::UpdateNodeGraphErrorDiagnostics { errors });
					let (layer_widths, chain_widths, has_left_input_wire) = network_interface.collect_layer_widths(breadcrumb_network_path);

					responses.add(NodeGraphMessage::UpdateImportsExports);
					responses.add(FrontendMessage::UpdateLayerWidths {
						layer_widths,
						chain_widths,
						has_left_input_wire,
					});
					responses.add(NodeGraphMessage::SendSelectedNodes);
					responses.add(NodeGraphMessage::UpdateHoveredConnector);
					self.update_node_graph_hints(responses);
				}
			}
			NodeGraphMessage::SetInputValue { node_id, input_index, value } => {
				use graphene_std::vector::generator_nodes::*;

				let reference = network_interface.reference(&node_id, selection_network_path);
				let is_text_node = reference.as_ref().is_some_and(|r| *r == DefinitionIdentifier::ProtoNode(graphene_std::text::text::IDENTIFIER));
				let is_stroke_node = reference.as_ref().is_some_and(|r| *r == DefinitionIdentifier::ProtoNode(graphene_std::vector::stroke::IDENTIFIER));
				let is_fill_node = reference.as_ref().is_some_and(|r| *r == DefinitionIdentifier::ProtoNode(graphene_std::vector::fill::IDENTIFIER));
				let is_fill_input = is_fill_node && input_index == graphene_std::vector::fill::PaintInput::INDEX;
				let is_shape_generator_node = reference.as_ref().is_some_and(|r| {
					[regular_polygon::IDENTIFIER, star::IDENTIFIER, arc::IDENTIFIER, spiral::IDENTIFIER, grid::IDENTIFIER, arrow::IDENTIFIER]
						.into_iter()
						.any(|id| *r == DefinitionIdentifier::ProtoNode(id))
				});

				let input = NodeInput::value(*value, false);
				responses.add(NodeGraphMessage::SetInput {
					input_connector: InputConnector::node_at_index(node_id, input_index),
					input,
				});
				responses.add(InspectorMessage::Refresh);
				if is_fill_input {
					responses.add(OverlaysMessage::Draw);
				}
				if is_stroke_node || is_fill_node || is_shape_generator_node || is_text_node {
					responses.add(SelectToolMessage::SelectionChanged);
					responses.add(PenToolMessage::SelectionChanged);
					responses.add(FreehandToolMessage::SelectionChanged);
					responses.add(SplineToolMessage::SelectionChanged);
					responses.add(ShapeToolMessage::SelectionChanged);
					responses.add(TextToolMessage::SelectionChanged);
				}
				if network_interface.connected_to_output(&node_id, selection_network_path) {
					responses.add(NodeGraphMessage::RunDocumentGraph);
				}
			}
			NodeGraphMessage::SetInput { input_connector, input } => {
				network_interface.set_input(&input_connector, input, selection_network_path);
			}
			NodeGraphMessage::NudgeSelectedNodes { direction } => {
				responses.add(DocumentMessage::StartTransaction);
				responses.add(NodeGraphMessage::ShiftSelectedNodes {
					direction,
					rubber_band: false,
					glide: true,
				});
				responses.add(DocumentMessage::EndTransaction);
			}
			NodeGraphMessage::ShiftSelectedNodes { direction, rubber_band, glide } => {
				// The shift can also push other nodes and the imports and exports, so everything it moves glides to where it lands
				let positions_before = (glide && graph_view_overlay_open).then(|| Self::glide_positions(network_interface, selection_network_path));

				network_interface.shift_selected_nodes(direction, self.shift_without_push, selection_network_path);

				if !rubber_band {
					network_interface.clear_drag_offsets(selection_network_path);
				}

				if let Some(positions_before) = positions_before {
					self.begin_glide(positions_before, network_interface, selection_network_path, responses);
					responses.add(NodeGraphMessage::SendGlide);
				}

				if graph_view_overlay_open {
					responses.add(NodeGraphMessage::SendGraph);
					responses.add(DocumentMessage::RenderRulers);
					responses.add(DocumentMessage::RenderScrollbars);
				}
			}
			NodeGraphMessage::ShiftSelectedNodesByAmount { mut graph_delta, rubber_band, glide } => {
				while graph_delta != IVec2::ZERO {
					match graph_delta.x.cmp(&0) {
						Ordering::Greater => {
							responses.add(NodeGraphMessage::ShiftSelectedNodes {
								direction: Direction::Right,
								rubber_band,
								glide,
							});
							graph_delta.x -= 1;
						}
						Ordering::Less => {
							responses.add(NodeGraphMessage::ShiftSelectedNodes {
								direction: Direction::Left,
								rubber_band,
								glide,
							});
							graph_delta.x += 1;
						}
						Ordering::Equal => {}
					}

					match graph_delta.y.cmp(&0) {
						Ordering::Greater => {
							responses.add(NodeGraphMessage::ShiftSelectedNodes {
								direction: Direction::Down,
								rubber_band,
								glide,
							});
							graph_delta.y -= 1;
						}
						Ordering::Less => {
							responses.add(NodeGraphMessage::ShiftSelectedNodes {
								direction: Direction::Up,
								rubber_band,
								glide,
							});
							graph_delta.y += 1;
						}
						Ordering::Equal => {}
					}
				}

				responses.add(NodeGraphMessage::SendWires);
			}
			NodeGraphMessage::ToggleSelectedAsLayersOrNodes => {
				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::ToggleSelectedAsLayersOrNodes");
					return;
				};
				responses.add(DocumentMessage::AddTransaction);
				for node_id in selected_nodes.selected_nodes() {
					responses.add(NodeGraphMessage::SetToNodeOrLayer {
						node_id: *node_id,
						is_layer: !network_interface.is_layer(node_id, selection_network_path),
					});
				}
				if selected_nodes.selected_nodes().any(|node_id| network_interface.connected_to_output(node_id, selection_network_path)) {
					responses.add(NodeGraphMessage::RunDocumentGraph);
				}
			}
			NodeGraphMessage::ShiftNodePosition { node_id, x, y } => {
				network_interface.shift_absolute_node_position(&node_id, IVec2::new(x, y), selection_network_path);

				responses.add(NodeGraphMessage::SendWires);
			}
			NodeGraphMessage::SetToNodeOrLayer { node_id, is_layer } => {
				if is_layer && !network_interface.is_eligible_to_be_layer(&node_id, selection_network_path) {
					return;
				}
				network_interface.set_to_node_or_layer(&node_id, selection_network_path, is_layer);

				self.context_menu = None;
				responses.add(FrontendMessage::UpdateContextMenuInformation {
					context_menu_information: self.context_menu.clone(),
				});
				responses.add(NodeGraphMessage::RunDocumentGraph);
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(NodeGraphMessage::SendWires);
			}
			NodeGraphMessage::SetDisplayName {
				node_id,
				network_path,
				alias,
				skip_adding_history_step,
			} => {
				if !skip_adding_history_step {
					responses.add(DocumentMessage::StartTransaction);
				}
				responses.add(NodeGraphMessage::SetDisplayNameImpl { node_id, network_path, alias });
				if !skip_adding_history_step {
					// Does not add a history step if the name was not changed
					responses.add(DocumentMessage::EndTransaction);
				}
				responses.add(DocumentMessage::RenderRulers);
				responses.add(DocumentMessage::RenderScrollbars);
				responses.add(NodeGraphMessage::SendGraph);
				responses.add(OverlaysMessage::Draw); // Redraw overlays to update artboard names
				responses.add(DataPanelMessage::Refresh);
			}
			NodeGraphMessage::SetDisplayNameImpl { node_id, network_path, alias } => {
				network_interface.set_display_name(&node_id, alias, &network_path);
			}
			NodeGraphMessage::SetImportExportName { name, index } => {
				// A name of only whitespace is left empty, so its type is shown instead
				let name = name.trim().to_string();

				responses.add(DocumentMessage::StartTransaction);
				responses.add(NodeGraphMessage::SetImportExportNameImpl { name, index });
				responses.add(DocumentMessage::EndTransaction);
				responses.add(NodeGraphMessage::UpdateImportsExports);
			}
			NodeGraphMessage::SetImportExportNameImpl { name, index } => network_interface.set_import_export_name(name, index, breadcrumb_network_path),
			NodeGraphMessage::SetImportExportDescription { description, index } => {
				let description = description.trim().to_string();

				responses.add(DocumentMessage::StartTransaction);
				responses.add(NodeGraphMessage::SetImportExportDescriptionImpl { description, index });
				responses.add(DocumentMessage::EndTransaction);
				responses.add(NodeGraphMessage::UpdateImportsExports);
				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::SetImportExportDescriptionImpl { description, index } => network_interface.set_import_export_description(description, index, breadcrumb_network_path),
			NodeGraphMessage::TogglePreview { node_id } => {
				responses.add(DocumentMessage::AddTransaction);
				responses.add(NodeGraphMessage::TogglePreviewImpl { node_id });
				responses.add(NodeGraphMessage::UpdateActionButtons);
				responses.add(NodeGraphMessage::RunDocumentGraph);
			}
			NodeGraphMessage::TogglePreviewImpl { node_id } => {
				network_interface.toggle_preview(node_id, selection_network_path);
			}
			NodeGraphMessage::ToggleSelectedLocked => {
				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::ToggleSelectedLocked");
					return;
				};
				let node_ids = selected_nodes
					.selected_nodes()
					.filter(|node_id| network_interface.is_layer(node_id, selection_network_path))
					.cloned()
					.collect::<Vec<_>>();

				if node_ids.is_empty() {
					return;
				}

				// If any of the selected layers are unlocked, lock them all. Otherwise, unlock them all.
				let locked = !node_ids.iter().all(|node_id| network_interface.is_locked(node_id, selection_network_path));

				responses.add(DocumentMessage::AddTransaction);

				for node_id in &node_ids {
					responses.add(NodeGraphMessage::SetLocked {
						node_id: *node_id,
						network_path: selection_network_path.to_vec(),
						locked,
					});
				}

				responses.add(NodeGraphMessage::SetLockedOrVisibilitySideEffects {
					node_ids,
					network_path: selection_network_path.to_vec(),
				})
			}
			NodeGraphMessage::ToggleLocked { node_id, network_path } => {
				let locked = !network_interface.is_locked(&node_id, &network_path);

				responses.add(DocumentMessage::AddTransaction);
				responses.add(NodeGraphMessage::SetLocked {
					node_id,
					network_path: network_path.clone(),
					locked,
				});
				responses.add(NodeGraphMessage::SetLockedOrVisibilitySideEffects {
					node_ids: vec![node_id],
					network_path,
				});
			}
			NodeGraphMessage::SetLocked { node_id, network_path, locked } => {
				network_interface.set_locked(&node_id, &network_path, locked);
			}
			NodeGraphMessage::ToggleSelectedIsPinned => {
				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::ToggleSelectedIsPinned");
					return;
				};
				let node_ids = selected_nodes.selected_nodes().cloned().collect::<Vec<_>>();

				// If any of the selected nodes are pinned, unpin them all. Otherwise, pin them all.
				let pinned = !node_ids.iter().all(|node_id| network_interface.is_pinned(node_id, breadcrumb_network_path));

				responses.add(DocumentMessage::AddTransaction);
				for node_id in &node_ids {
					responses.add(NodeGraphMessage::SetPinned { node_id: *node_id, pinned });
				}
				responses.add(NodeGraphMessage::SetLockedOrVisibilitySideEffects {
					node_ids,
					network_path: selection_network_path.to_vec(),
				});
			}
			NodeGraphMessage::ToggleSelectedVisibility => {
				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::ToggleSelectedLocked");
					return;
				};
				let node_ids = selected_nodes.selected_nodes().cloned().collect::<Vec<_>>();

				// If any of the selected nodes are hidden, show them all. Otherwise, hide them all.
				let visible = !node_ids.iter().all(|node_id| network_interface.is_visible(node_id, selection_network_path));

				responses.add(DocumentMessage::AddTransaction);
				for node_id in &node_ids {
					responses.add(NodeGraphMessage::SetVisibility {
						node_id: *node_id,
						network_path: selection_network_path.to_vec(),
						visible,
					});
				}
				responses.add(NodeGraphMessage::SetLockedOrVisibilitySideEffects {
					node_ids,
					network_path: selection_network_path.to_vec(),
				});
			}
			NodeGraphMessage::ToggleVisibility { node_id, network_path } => {
				let visible = !network_interface.is_visible(&node_id, &network_path);

				responses.add(DocumentMessage::AddTransaction);
				responses.add(NodeGraphMessage::SetVisibility {
					node_id,
					network_path: network_path.clone(),
					visible,
				});
				responses.add(NodeGraphMessage::SetLockedOrVisibilitySideEffects {
					node_ids: vec![node_id],
					network_path,
				});
			}
			NodeGraphMessage::SetPinned { node_id, pinned } => {
				network_interface.set_pinned(&node_id, selection_network_path, pinned);
			}
			NodeGraphMessage::SetVisibility { node_id, network_path, visible } => {
				network_interface.set_visibility(&node_id, &network_path, visible);
			}
			NodeGraphMessage::SetLockedOrVisibilitySideEffects { node_ids, network_path } => {
				if node_ids.iter().any(|node_id| network_interface.connected_to_output(node_id, &network_path)) {
					responses.add(NodeGraphMessage::RunDocumentGraph);
				}
				responses.add(NodeGraphMessage::UpdateActionButtons);
				responses.add(NodeGraphMessage::SendGraph);

				responses.add(InspectorMessage::Refresh);
				responses.add(DataPanelMessage::Refresh);
			}
			NodeGraphMessage::UpdateHoveredConnector => {
				let Some(network_metadata) = network_interface.network_metadata(breadcrumb_network_path) else {
					return;
				};
				let viewport_location = ipp.mouse.position;
				let point = network_metadata
					.persistent_metadata
					.navigation_metadata
					.node_graph_to_viewport
					.inverse()
					.transform_point2(viewport_location);

				// Moving nodes or drawing a selection box can't grab a connector, so none is shown hovered meanwhile
				let can_grab_connector = graph_view_overlay_open && self.drag_start.is_none() && self.box_selection_start.is_none();
				let in_viewport = viewport.is_in_bounds(viewport.logical(viewport_location) + viewport.offset());
				let hovered_connector = (can_grab_connector && in_viewport)
					.then(|| Self::connector_under_pointer(viewport_location, point, network_interface, breadcrumb_network_path))
					.flatten();
				self.set_hovered_connector(hovered_connector, responses);
			}
			NodeGraphMessage::UpdateWireInsertionPreview => {
				// Only a drag in progress inserts anything on drop, and one that hasn't started moving yet inserts nothing
				let target = if self.drag_start.is_some() && !self.begin_dragging {
					Self::wire_to_insert_on(network_interface, preferences.graph_wire_style, selection_network_path).map(|(_, _, input_connector)| input_connector)
				} else {
					None
				};
				if target == self.wire_insertion_preview {
					return;
				}

				self.wire_insertion_preview = target;
				let wire = target.map(|input_connector| match input_connector {
					InputConnector::Node { node_id, input_index } => (node_id, input_index),
					// Wires into exports are keyed under the max node ID, as in the wires sent to the frontend
					InputConnector::Export(export_index) => (NodeId(u64::MAX), export_index),
				});
				responses.add(FrontendMessage::UpdateWireInsertionPreview { wire });
			}
			NodeGraphMessage::UpdateBoxSelection => {
				if let Some((box_selection_start, _)) = self.box_selection_start {
					let Some(network_metadata) = network_interface.network_metadata(selection_network_path) else {
						log::error!("Could not get network metadata in UpdateBoxSelection");
						return;
					};

					let box_selection_start_viewport = network_metadata.persistent_metadata.navigation_metadata.node_graph_to_viewport.transform_point2(box_selection_start);

					let box_selection = Some(BoxSelection {
						start_x: box_selection_start_viewport.x.max(0.) as u32,
						start_y: box_selection_start_viewport.y.max(0.) as u32,
						end_x: ipp.mouse.position.x.max(0.) as u32,
						end_y: ipp.mouse.position.y.max(0.) as u32,
					});
					let box_selection_end_graph = network_metadata
						.persistent_metadata
						.navigation_metadata
						.node_graph_to_viewport
						.inverse()
						.transform_point2(ipp.mouse.position);

					let shift = ipp.keyboard.get(Key::Shift as usize);
					let alt = ipp.keyboard.get(Key::Alt as usize);
					let control = ipp.keyboard.get(Key::Control as usize);
					let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
						log::error!("Could not get selected nodes in UpdateBoxSelection");
						return;
					};
					let previous_selection = selected_nodes.selected_nodes_ref().iter().cloned().collect::<HashSet<_>>();
					let mut nodes = if shift || alt {
						selected_nodes.selected_nodes_ref().iter().cloned().collect::<HashSet<_>>()
					} else {
						HashSet::new()
					};
					let all_nodes = network_metadata.persistent_metadata.node_metadata.keys().cloned().collect::<Vec<_>>();
					for node_id in all_nodes {
						let Some(click_targets) = network_interface.node_click_targets(&node_id, selection_network_path) else {
							log::error!("Could not get transient metadata for node {node_id}");
							continue;
						};
						let quad = Quad::from_box([box_selection_start, box_selection_end_graph]);
						if click_targets.node_click_target.intersect_path(|| quad.to_lines(), DAffine2::IDENTITY) {
							if alt {
								nodes.remove(&node_id);
							} else {
								nodes.insert(node_id);
							}
						}
					}

					if control {
						let layer_nodes: HashSet<_> = nodes.iter().filter(|node_id| network_interface.is_layer(node_id, selection_network_path)).cloned().collect();
						let non_layer_nodes: HashSet<_> = nodes.difference(&layer_nodes).cloned().collect();

						// Remove non-layer nodes from selection
						if alt {
							nodes = previous_selection.difference(&non_layer_nodes).cloned().collect();
						}
						// Add non-layer nodes to selection
						else if shift {
							nodes = previous_selection.union(&non_layer_nodes).cloned().collect();
						}
						// Replace selection with non-layer nodes
						else {
							nodes = non_layer_nodes;
						}
					}

					if nodes != previous_selection {
						responses.add(NodeGraphMessage::SelectedNodesSet {
							nodes: nodes.into_iter().collect::<Vec<_>>(),
						});
					}
					responses.add(FrontendMessage::UpdateBox { box_selection })
				}
			}
			NodeGraphMessage::UpdateImportsExports => {
				let imports = network_interface.frontend_imports(breadcrumb_network_path);
				let exports = network_interface.frontend_exports(breadcrumb_network_path);

				let Some((import_position, export_position)) = network_interface.import_export_position(breadcrumb_network_path) else {
					log::error!("Could not get import export positions");
					return;
				};

				// Do not show the add import or add export button in the document network;
				let add_import_export = !breadcrumb_network_path.is_empty();

				responses.add(NodeGraphMessage::UpdateVisibleNodes);
				responses.add(NodeGraphMessage::SendWires);
				responses.add(FrontendMessage::UpdateImportsExports {
					imports,
					exports,
					import_position: import_position.into(),
					export_position: export_position.into(),
					add_import_export,
				});
			}

			NodeGraphMessage::UpdateLayerPanel => {
				let layers = layers_in_view.layers_panel().iter().copied();
				Self::update_layer_panel(
					layers,
					network_interface,
					selection_network_path,
					layers_panel_open,
					tool_edit_target,
					layers_panel_expanded_chains,
					responses,
				);
			}
			NodeGraphMessage::SendLayerPanelDetails { layers } => {
				Self::update_layer_panel(
					layers,
					network_interface,
					selection_network_path,
					layers_panel_open,
					tool_edit_target,
					layers_panel_expanded_chains,
					responses,
				);
			}
			NodeGraphMessage::UpdateNewNodeGraph => {
				let Some(selected_nodes) = network_interface.selected_nodes_mut(selection_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::UpdateNewNodeGraph");
					return;
				};
				selected_nodes.clear_selected_nodes();
				responses.add(EventMessage::SelectionChanged);

				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::UpdateTypes { resolved_types, node_graph_errors } => {
				// Hidden passthrough nodes let a wire borrow its color and rank from an upstream node, so any type change can restyle wires whose own node is unchanged.
				// Compare each displayed wire's style (color, rank) across the update and unload only those that changed, so value-only recompiles keep their built wire paths.
				let types_changed = !resolved_types.add.is_empty() || !resolved_types.remove.is_empty();
				let wire_style = |network_interface: &mut NodeNetworkInterface, input: &InputConnector| {
					network_interface.upstream_output_connector(input, breadcrumb_network_path).map(|output| {
						let output_type = network_interface.output_type(&output, breadcrumb_network_path);
						(output_type.displayed_type(), output_type.is_list())
					})
				};
				let styles_before = types_changed.then(|| {
					network_interface
						.node_graph_input_connectors(breadcrumb_network_path)
						.into_iter()
						.map(|input| {
							let style = wire_style(network_interface, &input);
							(input, style)
						})
						.collect::<Vec<_>>()
				});

				network_interface.resolved_types.update(resolved_types, node_graph_errors);

				if let Some(styles_before) = styles_before {
					for (input, style_before) in styles_before {
						if wire_style(network_interface, &input) != style_before {
							network_interface.unload_wire(&input, breadcrumb_network_path);
						}
					}
				}

				responses.add(NodeGraphMessage::SendGraph);
			}
			NodeGraphMessage::UpdateEvaluationErrors { errors } => {
				if self.evaluation_errors != errors {
					self.evaluation_errors = errors;
					if breadcrumb_network_path == selection_network_path && graph_view_overlay_open {
						let errors = self.node_graph_errors(network_interface, breadcrumb_network_path);
						responses.add(FrontendMessage::UpdateNodeGraphErrorDiagnostics { errors });
						responses.add(NodeGraphMessage::UpdateVisibleNodes);
					}
				}
			}
			NodeGraphMessage::UpdateActionButtons => {
				if selection_network_path == breadcrumb_network_path {
					self.update_graph_bar_left(network_interface, breadcrumb_network_path, responses);
					self.send_node_bar_layout(responses);
				}
			}
			NodeGraphMessage::UpdateGraphBarRight => {
				self.update_graph_bar_right(graph_fade_artwork_percentage, network_interface, breadcrumb_network_path, navigation_handler);
				self.send_node_bar_layout(responses);
			}
			NodeGraphMessage::UpdateInSelectedNetwork => responses.add(FrontendMessage::UpdateInSelectedNetwork {
				in_selected_network: selection_network_path == breadcrumb_network_path,
			}),
			NodeGraphMessage::UpdateHints => {
				self.update_node_graph_hints(responses);
			}
			NodeGraphMessage::SendSelectedNodes => {
				let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(breadcrumb_network_path) else {
					log::error!("Could not get selected nodes in NodeGraphMessage::SendSelectedNodes");
					return;
				};
				responses.add(NodeGraphMessage::UpdateActionButtons);
				responses.add(FrontendMessage::UpdateNodeGraphSelection {
					selected: selected_nodes.selected_nodes().cloned().collect::<Vec<_>>(),
				});
			}
		}
		let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(selection_network_path) else {
			log::error!("Could not get selected nodes in NodeGraphMessageHandler");
			return;
		};
		self.has_selection = selected_nodes.has_selected_nodes();
	}

	fn actions(&self) -> ActionList {
		let common = vec![];
		common
	}
}

impl NodeGraphMessageHandler {
	/// Removes the wire in progress and collapses any node expanded for it.
	pub fn end_wire_in_progress(&mut self, network_interface: &mut NodeNetworkInterface, network_path: &[NodeId], responses: &mut VecDeque<Message>) {
		self.set_wire_hovered_node(None, network_interface, network_path, responses);

		self.wire_in_progress_from_connector = None;
		self.wire_in_progress_to_connector = None;
		self.wire_in_progress_type = FrontendGraphDataType::General;
		self.wire_in_progress_from_new_import = None;
		self.wire_in_progress_from_input = None;
		self.wire_in_progress_from_new_export = None;
		self.disconnecting = None;

		responses.add(FrontendMessage::UpdateWirePathInProgress {
			wire_path: None,
			dragged_from: None,
			snapped_to: None,
		});
	}

	pub fn is_reordering_import_export(&self) -> bool {
		self.reordering_import.is_some() || self.reordering_export.is_some()
	}

	/// The connector under a press that a redirect dot can be dragged out of, which is an output or export with wires a dot can bend.
	fn dot_drag_out_source(
		clicked_input: Option<InputConnector>,
		clicked_output: Option<OutputConnector>,
		network_interface: &NodeNetworkInterface,
		network_path: &[NodeId],
	) -> Option<DotDragOutSource> {
		match (clicked_input, clicked_output) {
			(Some(export @ InputConnector::Export(export_index)), _) => network_interface.can_bend_wire_into(&export, network_path).then_some(DotDragOutSource::Export(export_index)),
			(None, Some(output)) => (!network_interface.inputs_fed_through_bendable_wires(&output, network_path).is_empty()).then_some(DotDragOutSource::Output(output)),
			_ => None,
		}
	}

	/// The wire a press at the point (in node graph space) lands on, within a few pixels at the graph's zoom.
	fn wire_at_point(point: DVec2, network_interface: &NodeNetworkInterface, wire_style: GraphWireStyle, network_path: &[NodeId]) -> Option<InputConnector> {
		let zoom = network_interface
			.network_metadata(network_path)?
			.persistent_metadata
			.navigation_metadata
			.node_graph_to_viewport
			.matrix2
			.x_axis
			.x;
		network_interface.wire_input_from_point(point, 6. / zoom.max(f64::EPSILON), wire_style, network_path)
	}

	/// Selects the redirect dot being inserted under the pointer and drags it along, as a drag begun at `start` (in node graph space) that has already come `moved` grid cells.
	fn drag_new_dot(&mut self, dot: NodeId, start: DVec2, moved: IVec2, responses: &mut VecDeque<Message>) {
		responses.add(NodeGraphMessage::SelectedNodesSet { nodes: vec![dot] });

		let drag_start = DragStart {
			start_x: start.x,
			start_y: start.y,
			round_x: moved.x,
			round_y: moved.y,
		};
		self.drag_start = Some((drag_start, moved != IVec2::ZERO));
		self.drag_start_chain_nodes = Vec::new();
		// Already underway, so holding Alt doesn't duplicate the dot
		self.begin_dragging = false;
		self.nodes_added_in_drag = true;
		self.node_has_moved_in_drag = moved != IVec2::ZERO;

		self.update_node_graph_hints(responses);
	}

	/// The center of the connector a press at the pointer would grab, in node graph space, as `PointerDown` decides what lies under it.
	fn connector_under_pointer(viewport_location: DVec2, point: DVec2, network_interface: &NodeNetworkInterface, network_path: &[NodeId]) -> Option<DVec2> {
		// Names and layer buttons take presses before the connectors beneath them
		let layer_button_under_pointer = |target_type| network_interface.layer_click_target_from_click(viewport_location, target_type, network_path).is_some();
		if network_interface.import_export_name_from_point(point, network_path).is_some()
			|| layer_button_under_pointer(network_interface::LayerClickTargetTypes::Visibility)
			|| layer_button_under_pointer(network_interface::LayerClickTargetTypes::Lock)
		{
			return None;
		}

		// Centered where it's drawn, even while gliding into place
		let glide_offsets = network_interface.glide_offsets(network_path);
		let empty_connector = |is_import| {
			let (_, center) = network_interface.empty_import_export_connector_at(point, is_import, network_path)?;
			Some(center + if is_import { glide_offsets.imports } else { glide_offsets.exports })
		};
		let input = || {
			let input = network_interface.input_port_from_click(viewport_location, network_path)?;
			Some(network_interface.input_position(&input, network_path)? + glide_offsets.input(&input))
		};
		let output = || {
			let output = network_interface.output_port_from_click(viewport_location, network_path)?;
			Some(network_interface.output_position(&output, network_path)? + glide_offsets.output(&output))
		};
		empty_connector(true).or_else(|| empty_connector(false)).or_else(input).or_else(output)
	}

	/// Tells the frontend which connector to show hovered, given by its center in node graph space.
	fn set_hovered_connector(&mut self, hovered_connector: Option<DVec2>, responses: &mut VecDeque<Message>) {
		if self.hovered_connector != hovered_connector {
			self.hovered_connector = hovered_connector;
			responses.add(FrontendMessage::UpdateHoveredConnector {
				center: hovered_connector.map(|center| (center.x, center.y)),
			});
		}
	}

	/// Stops highlighting the wire a dragged node would be inserted onto.
	fn clear_wire_insertion_preview(&mut self, responses: &mut VecDeque<Message>) {
		if self.wire_insertion_preview.take().is_some() {
			responses.add(FrontendMessage::UpdateWireInsertionPreview { wire: None });
		}
	}

	/// Cancels dragging an import or export to reorder it, leaving it where it was.
	pub fn abort_import_export_reorder(&mut self, responses: &mut VecDeque<Message>) {
		self.reordering_import = None;
		self.reordering_export = None;
		self.end_index = None;

		responses.add(DocumentMessage::AbortTransaction);
		responses.add(FrontendMessage::UpdateImportReorderIndex { index: None });
		responses.add(FrontendMessage::UpdateExportReorderIndex { index: None });
		self.update_node_graph_hints(responses);
	}

	/// Ends the wire in progress and closes the context menu, both of which belong to the network being left.
	pub fn leave_network(&mut self, network_interface: &mut NodeNetworkInterface, network_path: &[NodeId], responses: &mut VecDeque<Message>) {
		if self.wire_in_progress_from_connector.is_some() {
			self.end_wire_in_progress(network_interface, network_path, responses);
			responses.add(DocumentMessage::AbortTransaction);
			self.update_node_graph_hints(responses);
		}
		self.clear_wire_insertion_preview(responses);
		self.stop_gliding(network_interface, responses);
		if self.context_menu.take().is_some() {
			responses.add(FrontendMessage::UpdateContextMenuInformation { context_menu_information: None });
		}
	}

	/// Whether the wire in progress is dragged backward from an input or export end, leaving its output end loose.
	fn wire_in_progress_is_backward(&self) -> bool {
		self.wire_in_progress_from_input.is_some() || self.wire_in_progress_from_new_export.is_some()
	}

	/// Keeps a pressed connector lit as the source of the wire about to be dragged out of it, since the press ends its hover before the pointer moves far enough to draw the wire.
	fn keep_pressed_connector_lit(center: Option<DVec2>, responses: &mut VecDeque<Message>) {
		responses.add(FrontendMessage::UpdateWirePathInProgress {
			wire_path: None,
			dragged_from: center.map(|center| (center.x, center.y)),
			snapped_to: None,
		});
	}

	/// Draws the wire in progress between its two ends, where `input_end` is the input it meets at its input end, if any,
	/// and `loose_end_snapped` is whether the end following the pointer has snapped to a connector.
	fn send_wire_in_progress(&self, input_end: Option<InputConnector>, loose_end_snapped: bool, network_interface: &NodeNetworkInterface, network_path: &[NodeId], responses: &mut VecDeque<Message>) {
		let (Some(from_connector), Some(to_connector)) = (self.wire_in_progress_from_connector, self.wire_in_progress_to_connector) else {
			return;
		};
		let Some(network_metadata) = network_interface.network_metadata(network_path) else { return };

		// Layer outputs and the stack inputs of layers leave and enter vertically
		let from_connector_viewport = network_metadata.persistent_metadata.navigation_metadata.node_graph_to_viewport.transform_point2(from_connector);
		let from_connector_is_layer = network_interface
			.output_connector_from_click(from_connector_viewport, network_path)
			.is_some_and(|output_connector| matches!(output_connector, OutputConnector::Node { node_id, .. } if network_interface.is_layer(&node_id, network_path)));
		let to_connector_is_layer =
			input_end.is_some_and(|input_connector| matches!(input_connector, InputConnector::Node { node_id, input_index: 0 } if network_interface.is_layer(&node_id, network_path)));

		let vector_wire = build_vector_wire(from_connector, to_connector, from_connector_is_layer, to_connector_is_layer, GraphWireStyle::Direct);
		let wire_path = WirePath {
			path_string: vector_wire.to_svg(),
			data_type: self.wire_in_progress_type,
			thick: false,
			dashed: false,
			is_list: false,
			center_path_string: String::new(),
		};

		// The end it's dragged from always meets a connector, while the loose end does once it snaps to one
		let (dragged_from, loose_end) = if self.wire_in_progress_is_backward() {
			(to_connector, from_connector)
		} else {
			(from_connector, to_connector)
		};

		responses.add(FrontendMessage::UpdateWirePathInProgress {
			wire_path: Some(wire_path),
			dragged_from: Some((dragged_from.x, dragged_from.y)),
			snapped_to: loose_end_snapped.then_some((loose_end.x, loose_end.y)),
		});
	}

	/// The output the wire in progress is dragged from.
	fn wire_in_progress_output_connector(&self, network_interface: &NodeNetworkInterface, network_path: &[NodeId]) -> Option<OutputConnector> {
		let from_connector = self.wire_in_progress_from_connector?;
		let node_graph_to_viewport = network_interface.network_metadata(network_path)?.persistent_metadata.navigation_metadata.node_graph_to_viewport;

		network_interface.output_connector_from_click(node_graph_to_viewport.transform_point2(from_connector), network_path)
	}

	/// Tracks the node under the wire in progress and when the hover began, collapsing the expanded node once the wire leaves it.
	fn set_wire_hovered_node(&mut self, hover: Option<(NodeId, u64)>, network_interface: &mut NodeNetworkInterface, network_path: &[NodeId], responses: &mut VecDeque<Message>) {
		let hovered_node = hover.map(|(node_id, _)| node_id);
		if self.wire_hovered_node.map(|(node_id, _)| node_id) == hovered_node {
			return;
		}

		if self.wire_expanded_node.as_ref().is_some_and(|(node_id, _, _)| Some(*node_id) != hovered_node) {
			self.collapse_wire_expanded_node(None, network_interface, network_path, responses);
		}

		self.wire_hovered_node = hover;
		self.set_wire_hover_tick_subscribed(hover.is_some(), responses);
	}

	/// Expands the hovered node once the wire has rested over it for the hover delay.
	fn expand_wire_hovered_node_after_delay(&mut self, time: u64, network_interface: &mut NodeNetworkInterface, network_path: &[NodeId], responses: &mut VecDeque<Message>) {
		let Some((node_id, hover_start_time)) = self.wire_hovered_node else { return };
		if time.saturating_sub(hover_start_time) < WIRE_DRAG_NODE_EXPAND_DELAY_MILLISECONDS {
			return;
		}
		self.set_wire_hover_tick_subscribed(false, responses);

		let Some(output_connector) = self.wire_in_progress_output_connector(network_interface, network_path) else {
			return;
		};

		// Connecting the wire to its source node, or to any node upstream of it, would form a cycle
		if let OutputConnector::Node { node_id: source_node_id, .. } = output_connector
			&& network_interface
				.upstream_flow_back_from_nodes(vec![source_node_id], network_path, FlowType::UpstreamFlow)
				.any(|upstream_node_id| upstream_node_id == node_id)
		{
			return;
		}

		let output_types = network_interface.potential_output_types(&output_connector, network_path);

		let revealed_input_indices = (0..network_interface.number_of_inputs(&node_id, network_path))
			.filter(|&input_index| {
				let input_connector = InputConnector::node_at_index(node_id, input_index);
				let hidden_value = matches!(network_interface.input_from_connector(&input_connector, network_path), Some(NodeInput::Value { exposed: false, .. }));

				hidden_value
					&& !network_interface.is_internal_input(&node_id, input_index, network_path)
					&& output_types.iter().any(|output_type| network_interface.input_accepts_type(&input_connector, output_type, network_path))
			})
			.collect::<Vec<_>>();
		if revealed_input_indices.is_empty() {
			return;
		}

		let transaction_checkpoint = network_interface.transaction_checkpoint();
		for &input_index in &revealed_input_indices {
			Self::set_value_input_exposed(InputConnector::node_at_index(node_id, input_index), true, network_interface, network_path);
		}
		responses.add(NodeGraphMessage::SendGraph);

		self.wire_expanded_node = Some((node_id, revealed_input_indices, transaction_checkpoint));
	}

	/// Hides the inputs revealed by the expanded node again, except `connected_input`.
	fn collapse_wire_expanded_node(&mut self, connected_input: Option<InputConnector>, network_interface: &mut NodeNetworkInterface, network_path: &[NodeId], responses: &mut VecDeque<Message>) {
		let Some((node_id, revealed_input_indices, transaction_checkpoint)) = self.wire_expanded_node.take() else {
			return;
		};

		let mut connecting_revealed_input = false;
		for &input_index in &revealed_input_indices {
			let input_connector = InputConnector::node_at_index(node_id, input_index);
			if Some(input_connector) == connected_input {
				connecting_revealed_input = true;
			} else {
				Self::set_value_input_exposed(input_connector, false, network_interface, network_path);
			}
		}
		responses.add(NodeGraphMessage::SendGraph);

		// Unless the wire connects to one of them, the reveal was only a preview and isn't an edit
		if !connecting_revealed_input {
			network_interface.restore_transaction_checkpoint(transaction_checkpoint);
		}
	}

	fn set_value_input_exposed(input_connector: InputConnector, exposed: bool, network_interface: &mut NodeNetworkInterface, network_path: &[NodeId]) {
		let Some(mut input) = network_interface.input_from_connector(&input_connector, network_path).cloned() else {
			return;
		};
		let NodeInput::Value { exposed: input_exposed, .. } = &mut input else { return };

		*input_exposed = exposed;
		network_interface.set_input(&input_connector, input, network_path);
	}

	/// Where each node and the imports and exports sit, to find what a shift moves.
	fn glide_positions(network_interface: &NodeNetworkInterface, network_path: &[NodeId]) -> (HashMap<NodeId, IVec2>, Option<(IVec2, IVec2)>) {
		let node_ids = network_interface
			.nested_network(network_path)
			.map(|network| network.nodes.keys().copied().collect::<Vec<_>>())
			.unwrap_or_default();
		let node_positions = network_interface.positions(node_ids, network_path).into_iter().collect();

		(node_positions, network_interface.import_export_position(network_path))
	}

	/// Lets everything that moved away from `positions_before` glide to where it now sits from where it was drawn, so it doesn't jump.
	fn begin_glide(
		&mut self,
		positions_before: (HashMap<NodeId, IVec2>, Option<(IVec2, IVec2)>),
		network_interface: &NodeNetworkInterface,
		network_path: &[NodeId],
		responses: &mut VecDeque<Message>,
	) {
		if self.glide_network_path != network_path {
			self.stop_gliding(network_interface, responses);
			self.glide_network_path = network_path.to_vec();
		}

		let (node_positions_before, import_export_position_before) = positions_before;
		let (node_positions, import_export_position) = Self::glide_positions(network_interface, network_path);
		let mut glide_offsets = network_interface.glide_offsets(network_path);

		for (node_id, position) in node_positions {
			if let Some(position_before) = node_positions_before.get(&node_id)
				&& *position_before != position
			{
				*glide_offsets.nodes.entry(node_id).or_default() += (*position_before - position).as_dvec2() * GRID_SIZE as f64;
			}
		}

		if let (Some((imports_before, exports_before)), Some((imports, exports))) = (import_export_position_before, import_export_position) {
			glide_offsets.imports += (imports_before - imports).as_dvec2();
			glide_offsets.exports += (exports_before - exports).as_dvec2();
		}

		self.set_glide_tick_subscribed(!glide_offsets.is_empty(), responses);
		network_interface.set_glide_offsets(glide_offsets, network_path);
	}

	/// Sends where everything gliding into place is drawn, along with the wires meeting whatever was gliding, which follow it rather than where it sits.
	fn send_glide(
		glide_offsets: &GlideOffsets,
		was_gliding: &GlideOffsets,
		network_interface: &NodeNetworkInterface,
		wire_style: GraphWireStyle,
		network_path: &[NodeId],
		responses: &mut VecDeque<Message>,
	) {
		responses.add(FrontendMessage::UpdateGlideOffsets {
			nodes: glide_offsets.nodes.iter().map(|(node_id, offset)| (*node_id, (offset.x, offset.y))).collect(),
			imports: (glide_offsets.imports.x, glide_offsets.imports.y),
			exports: (glide_offsets.exports.x, glide_offsets.exports.y),
		});

		let wires = Self::gliding_wires(glide_offsets, was_gliding, network_interface, wire_style, network_path);
		responses.add(FrontendMessage::UpdateNodeGraphWires { wires });
	}

	/// The wires meeting whatever was gliding, drawn to follow it rather than where it sits.
	fn gliding_wires(glide_offsets: &GlideOffsets, was_gliding: &GlideOffsets, network_interface: &NodeNetworkInterface, wire_style: GraphWireStyle, network_path: &[NodeId]) -> Vec<WirePathUpdate> {
		// The inputs of the nodes and exports that were gliding, and those fed by the nodes and imports that were gliding (leaving out any node deleted meanwhile)
		let mut inputs = HashSet::new();
		let mut outputs = Vec::new();
		let network = network_interface.nested_network(network_path);
		for node_id in was_gliding.nodes.keys().filter(|node_id| network.is_some_and(|network| network.nodes.contains_key(node_id))) {
			inputs.extend((0..network_interface.number_of_inputs(node_id, network_path)).map(|input_index| InputConnector::node_at_index(*node_id, input_index)));
			outputs.extend((0..network_interface.number_of_outputs(node_id, network_path)).map(|output_index| OutputConnector::node(*node_id, output_index)));
		}

		if was_gliding.exports != DVec2::ZERO {
			inputs.extend((0..network_interface.number_of_exports(network_path)).map(InputConnector::Export));
		}
		if was_gliding.imports != DVec2::ZERO {
			outputs.extend((0..network_interface.number_of_imports(network_path)).map(OutputConnector::Import));
		}

		network_interface.with_outward_wires(network_path, |outward_wires| {
			for output in &outputs {
				inputs.extend(outward_wires.get(output).into_iter().flatten().copied());
			}
		});

		let mut wires = inputs
			.iter()
			.filter(|input| network_interface.input_from_connector(input, network_path).is_some_and(|input| input.is_exposed()))
			.filter_map(|input| network_interface.wire_update_from_input(input, wire_style, glide_offsets, network_path))
			.collect::<Vec<_>>();
		wires.extend(network_interface.wire_to_root(wire_style, glide_offsets, network_path));
		wires
	}

	/// Settles whatever is gliding into place at once, such as when the drag moving it is aborted.
	pub fn stop_gliding(&mut self, network_interface: &NodeNetworkInterface, responses: &mut VecDeque<Message>) {
		if !self.glide_tick_subscribed {
			return;
		}

		network_interface.set_glide_offsets(GlideOffsets::default(), &self.glide_network_path);
		responses.add(FrontendMessage::UpdateGlideOffsets {
			nodes: Vec::new(),
			imports: (0., 0.),
			exports: (0., 0.),
		});
		self.set_glide_tick_subscribed(false, responses);
	}

	fn set_glide_tick_subscribed(&mut self, subscribed: bool, responses: &mut VecDeque<Message>) {
		if self.glide_tick_subscribed == subscribed {
			return;
		}
		self.glide_tick_subscribed = subscribed;
		self.glide_last_tick_time = None;

		let send = Box::new(NodeGraphMessage::GlideTick.into());
		responses.add(match subscribed {
			true => BroadcastMessage::SubscribeEvent {
				on: EventMessage::AnimationFrame,
				send,
			},
			false => BroadcastMessage::UnsubscribeEvent {
				on: EventMessage::AnimationFrame,
				send,
			},
		});
	}

	fn set_wire_hover_tick_subscribed(&mut self, subscribed: bool, responses: &mut VecDeque<Message>) {
		if self.wire_hover_tick_subscribed == subscribed {
			return;
		}
		self.wire_hover_tick_subscribed = subscribed;

		let send = Box::new(NodeGraphMessage::WireHoverTick.into());
		responses.add(match subscribed {
			true => BroadcastMessage::SubscribeEvent {
				on: EventMessage::AnimationFrame,
				send,
			},
			false => BroadcastMessage::UnsubscribeEvent {
				on: EventMessage::AnimationFrame,
				send,
			},
		});
	}

	/// Similar to [`NodeGraphMessageHandler::actions`], but this provides additional actions if the node graph is open and should only be called in that circumstance.
	pub fn actions_additional_if_node_graph_is_open(&self) -> ActionList {
		let mut common = actions!(NodeGraphMessageDiscriminant; EnterNestedNetwork, PointerDown, PointerMove, PointerUp);

		// Only development builds draw the click targets, so users don't come across the overlay by accident
		if cfg!(debug_assertions) {
			common.extend(actions!(NodeGraphMessageDiscriminant; SendClickTargets, EndSendClickTargets));
		}

		if self.has_selection {
			common.extend(actions!(NodeGraphMessageDiscriminant;
				Copy,
				Cut,
				DeleteSelectedNodes,
				DuplicateSelectedNodes,
				MergeSelectedNodes,
				ToggleSelectedAsLayersOrNodes,
				ToggleSelectedLocked,
				ToggleSelectedVisibility,
				NudgeSelectedNodes,
			));
		}

		if self.drag_start.is_some() {
			common.extend(actions!(NodeGraphMessageDiscriminant;
				ShakeNode,
			));
		}

		common
	}

	/// The wire a single dragged node would be inserted onto if dropped where it is, with the node and the index of its input the wire would feed.
	/// A node is only inserted when it's alone in the selection, has nothing wired out of its primary output, has a free first exposed input, and overlaps exactly one fitting wire.
	// O(wires), since each wire's path is intersected with the node's bounds
	pub(crate) fn wire_to_insert_on(network_interface: &mut NodeNetworkInterface, graph_wire_style: GraphWireStyle, selection_network_path: &[NodeId]) -> Option<(NodeId, usize, InputConnector)> {
		let selected_nodes = network_interface.selected_nodes_in_nested_network(selection_network_path)?;
		let [selected_node_id] = *selected_nodes.selected_nodes_ref().as_slice() else { return None };

		let has_primary_output_connection = network_interface.outward_wires(selection_network_path).is_some_and(|outward_wires| {
			outward_wires
				.get(&OutputConnector::primary_output(selected_node_id))
				.is_some_and(|outward_wires| !outward_wires.is_empty())
		});
		if has_primary_output_connection {
			return None;
		}

		// The input it's spliced in by has to be disconnected
		let insert_node_input_index = network_interface
			.first_exposed_input(&selected_node_id, selection_network_path)
			.filter(|input| network_interface.input_from_connector(input, selection_network_path).is_some_and(|input| input.as_value().is_some()))?
			.input_index();

		let Some(node_bbox) = network_interface.node_bounding_box(&selected_node_id, selection_network_path) else {
			log::error!("Could not get bounding box for node: {selected_node_id}");
			return None;
		};
		let node_bbox = kurbo::Rect::new(node_bbox[0].x, node_bbox[0].y, node_bbox[1].x, node_bbox[1].y).to_path(DEFAULT_ACCURACY);

		let mut wires_to_check = network_interface.node_graph_input_connectors(selection_network_path).into_iter().collect::<HashSet<_>>();
		// Prevent inserting on a link that is connected upstream to the selected node
		for upstream_node in network_interface.upstream_flow_back_from_nodes(vec![selected_node_id], selection_network_path, network_interface::FlowType::UpstreamFlow) {
			for input_index in 0..network_interface.number_of_inputs(&upstream_node, selection_network_path) {
				wires_to_check.remove(&InputConnector::node_at_index(upstream_node, input_index));
			}
		}

		let overlapping_wires = wires_to_check
			.into_iter()
			.filter_map(|input| {
				// Prevent inserting a layer into a chain
				if network_interface.is_layer(&selected_node_id, selection_network_path)
					&& input.node_id().is_some_and(|input_node_id| network_interface.is_chain(&input_node_id, selection_network_path))
				{
					return None;
				}

				let (wire, _center_line, is_stack) = network_interface.vector_wire_from_input(&input, graph_wire_style, selection_network_path)?;

				let inside = bezpath_is_inside_bezpath(&wire, &node_bbox, None, None);
				let intersect = wire
					.segments()
					.any(|segment| node_bbox.segments().filter_map(|segment| segment.as_line()).any(|line| !segment.intersect_line(line).is_empty()));

				(intersect || inside).then_some((input, is_stack))
			})
			.collect::<Vec<_>>();

		// Prioritize vertical thick lines and cancel if there are multiple potential wires
		let (stack_wires, node_wires): (Vec<_>, Vec<_>) = overlapping_wires.into_iter().partition(|(_, is_stack)| *is_stack);
		let stack_wires = stack_wires.into_iter().map(|(input, _)| input).collect::<Vec<_>>();
		let node_wires = node_wires.into_iter().map(|(input, _)| input).collect::<Vec<_>>();

		let overlapping_wire = if network_interface.is_layer(&selected_node_id, selection_network_path) {
			if stack_wires.len() == 1 {
				stack_wires.first()
			} else if stack_wires.is_empty() && node_wires.len() == 1 {
				node_wires.first()
			} else {
				None
			}
		} else if node_wires.len() == 1 {
			node_wires.first()
		} else {
			None
		};

		overlapping_wire.map(|input| (selected_node_id, insert_node_input_index, *input))
	}

	/// Duplicates the selected nodes and selects the copies, returning whether there were any to duplicate, since a lone dot has no copy.
	fn duplicate_selected_nodes(network_interface: &NodeNetworkInterface, selection_network_path: &[NodeId], responses: &mut VecDeque<Message>) -> bool {
		let all_selected_nodes = network_interface.upstream_chain_nodes(selection_network_path);
		let all_selected_nodes = network_interface.selection_with_bridging_dots(all_selected_nodes, selection_network_path);
		if all_selected_nodes.is_empty() {
			return false;
		}

		let copy_ids = all_selected_nodes.iter().enumerate().map(|(new, id)| (*id, NodeId(new as u64))).collect::<HashMap<NodeId, NodeId>>();

		let nodes = network_interface.copy_nodes(&copy_ids, selection_network_path).collect::<Vec<_>>();

		let new_ids = nodes.iter().map(|(id, _)| (*id, NodeId::new())).collect::<HashMap<_, _>>();
		responses.add(NodeGraphMessage::AddNodes { nodes, new_ids: new_ids.clone() });
		responses.add(NodeGraphMessage::SelectedNodesSet {
			nodes: new_ids.values().cloned().collect(),
		});
		true
	}

	/// Send the cached layout to the frontend for the control bar at the top of the node panel
	fn send_node_bar_layout(&self, responses: &mut VecDeque<Message>) {
		responses.add(LayoutMessage::SendLayout {
			layout: Layout(self.widgets.to_vec()),
			layout_target: LayoutTarget::NodeGraphControlBar,
		});
	}

	/// Updates the buttons for visibility, locked, and preview
	fn update_graph_bar_left(&mut self, network_interface: &mut NodeNetworkInterface, breadcrumb_network_path: &[NodeId], responses: &mut VecDeque<Message>) {
		let Some(subgraph_path_names) = Self::collect_subgraph_names(network_interface, breadcrumb_network_path) else {
			// If a node in a nested network could not be found, exit the nested network
			let breadcrumb_network_path_len = breadcrumb_network_path.len();
			if breadcrumb_network_path_len > 0 {
				responses.add(DocumentMessage::ExitNestedNetwork {
					steps_back: breadcrumb_network_path_len,
				});
			}
			return;
		};

		let Some(selected_nodes) = network_interface.selected_nodes_in_nested_network(breadcrumb_network_path) else {
			warn!("No selected nodes in update_selection_action_buttons");
			return;
		};

		let has_selection = selected_nodes.has_selected_nodes();
		let selection_includes_layers = network_interface.selected_nodes().selected_layers(network_interface.document_metadata()).count() > 0;
		let selection_all_locked = network_interface.selected_nodes().selected_unlocked_layers(network_interface).count() == 0;
		let selection_all_visible = selected_nodes.selected_nodes().all(|node_id| network_interface.is_visible(node_id, breadcrumb_network_path));

		let mut selected_layers = selected_nodes.selected_layers(network_interface.document_metadata());
		let selected_layer = selected_layers.next();
		let has_multiple_selection = selected_layers.next().is_some();
		for _ in selected_layers {}

		let mut widgets = vec![
			IconButton::new(if selection_all_visible { "EyeVisible" } else { "EyeHidden" }, 24)
				.hover_icon(if selection_all_visible { "EyeHide" } else { "EyeShow" })
				.tooltip_label(if selection_all_visible { "Hide Selected" } else { "Show Selected" })
				.tooltip_shortcut(action_shortcut!(NodeGraphMessageDiscriminant::ToggleSelectedVisibility))
				.on_update(|_| NodeGraphMessage::ToggleSelectedVisibility.into())
				.disabled(!has_selection)
				.widget_instance(),
			IconButton::new(if selection_all_locked { "PadlockLocked" } else { "PadlockUnlocked" }, 24)
				.hover_icon(if selection_all_locked { "PadlockUnlocked" } else { "PadlockLocked" })
				.tooltip_label(if selection_all_locked { "Unlock Selected" } else { "Lock Selected" })
				.tooltip_shortcut(action_shortcut!(NodeGraphMessageDiscriminant::ToggleSelectedLocked))
				.on_update(|_| NodeGraphMessage::ToggleSelectedLocked.into())
				.disabled(!has_selection || !selection_includes_layers)
				.widget_instance(),
			//
			Separator::new(SeparatorStyle::Unrelated).widget_instance(),
			//
			PopoverButton::new()
				.icon("Node")
				.tooltip_label("New Node")
				.tooltip_description("To add a node at the pointer location, perform the shortcut in an open area of the graph.")
				.tooltip_shortcut(action_shortcut_manual!(Key::MouseRight))
				.popover_layout({
					// Showing only compatible types
					let compatible_type = match (selection_includes_layers, has_multiple_selection, selected_layer) {
						(true, false, Some(layer)) => network_interface.output_type(&OutputConnector::node(layer.to_node(), 1), &[]).add_node_string(),
						_ => None,
					};

					let single_layer_selected = selection_includes_layers && !has_multiple_selection;

					let mut node_chooser = NodeCatalog::new();
					node_chooser.initial_search = compatible_type.unwrap_or("".to_string());

					let node_chooser = node_chooser
						.on_update(move |node_type| {
							if let (true, Some(layer)) = (single_layer_selected, selected_layer) {
								NodeGraphMessage::CreateNodeInLayerWithTransaction {
									node_type: node_type.clone(),
									layer: LayerNodeIdentifier::new_unchecked(layer.to_node()),
								}
								.into()
							} else {
								let node_id = NodeId::new();
								Message::Batched {
									messages: Box::new([
										NodeGraphMessage::CreateNodeFromContextMenu {
											node_id: Some(node_id),
											node_type: node_type.clone(),
											xy: None,
											add_transaction: true,
										}
										.into(),
										NodeGraphMessage::SelectedNodesSet { nodes: vec![node_id] }.into(),
									]),
								}
							}
						})
						.widget_instance();
					Layout(vec![LayoutGroup::row(vec![node_chooser])])
				})
				.widget_instance(),
			//
			Separator::new(SeparatorStyle::Unrelated).widget_instance(),
			//
			IconButton::new("Folder", 24)
				.tooltip_label("Group Selected")
				.tooltip_shortcut(action_shortcut!(DocumentMessageDiscriminant::GroupSelectedLayers))
				.on_update(|_| {
					let group_folder_type = GroupFolderType::Layer;
					DocumentMessage::GroupSelectedLayers { group_folder_type }.into()
				})
				.disabled(!has_selection)
				.widget_instance(),
			IconButton::new("NewLayer", 24)
				.tooltip_label("New Layer")
				.tooltip_shortcut(action_shortcut!(DocumentMessageDiscriminant::CreateEmptyFolder))
				.on_update(|_| DocumentMessage::CreateEmptyFolder.into())
				.widget_instance(),
			IconButton::new("Trash", 24)
				.tooltip_label("Delete Selected")
				.tooltip_shortcut(action_shortcut!(DocumentMessageDiscriminant::DeleteSelectedLayers))
				.on_update(|_| DocumentMessage::DeleteSelectedLayers.into())
				.disabled(!has_selection)
				.widget_instance(),
		];

		let mut selection = selected_nodes.selected_nodes();
		let (selection, no_other_selections) = (selection.next(), selection.count() == 0);

		let Some(network) = network_interface.nested_network(breadcrumb_network_path) else {
			warn!("No network in update_selection_action_buttons");
			return;
		};
		let previewing = if matches!(network_interface.previewing(breadcrumb_network_path), Previewing::Yes { .. }) {
			network.exports.iter().find_map(|export| {
				let NodeInput::Node { node_id, .. } = export else { return None };
				Some(*node_id)
			})
		} else {
			None
		};

		// If only one node is selected then show the preview or stop previewing button
		if let Some(node_id) = previewing {
			let button = TextButton::new("End Preview")
				.icon("FrameAll")
				.tooltip_description("Restore preview to the graph output.")
				.on_update(move |_| NodeGraphMessage::TogglePreview { node_id }.into())
				.widget_instance();
			widgets.extend([Separator::new(SeparatorStyle::Unrelated).widget_instance(), button]);
		} else if let Some(&node_id) = selection {
			let selection_is_not_already_the_output = !network
				.exports
				.iter()
				.any(|export| matches!(export, NodeInput::Node { node_id: export_node_id, .. } if *export_node_id == node_id));
			if selection_is_not_already_the_output && no_other_selections {
				let button = TextButton::new("Preview")
					.icon("FrameAll")
					.tooltip_label("Preview")
					.tooltip_description("Temporarily set the graph output to the selected node or layer. Perform the shortcut on a node or layer for quick access.")
					.tooltip_shortcut(action_shortcut_manual!(Key::Alt, Key::MouseLeft))
					.on_update(move |_| NodeGraphMessage::TogglePreview { node_id }.into())
					.widget_instance();
				widgets.extend([Separator::new(SeparatorStyle::Unrelated).widget_instance(), button]);
			}
		}

		let subgraph_path_names_length = subgraph_path_names.len();
		if subgraph_path_names_length >= 2 {
			widgets.extend([
				Separator::new(SeparatorStyle::Unrelated).widget_instance(),
				BreadcrumbTrailButtons::new(subgraph_path_names.iter().map(|name| truncate_breadcrumb_label(name)).collect())
					.on_update(move |index| {
						DocumentMessage::ExitNestedNetwork {
							steps_back: subgraph_path_names_length - (*index as usize) - 1,
						}
						.into()
					})
					.widget_instance(),
			]);
		}

		self.widgets[0] = LayoutGroup::row(widgets);
	}

	fn update_graph_bar_right(
		&mut self,
		graph_fade_artwork_percentage: f64,
		network_interface: &NodeNetworkInterface,
		breadcrumb_network_path: &[NodeId],
		navigation_handler: &NavigationMessageHandler,
	) {
		let Some(node_graph_ptz) = network_interface.node_graph_ptz(breadcrumb_network_path) else {
			log::error!("Could not get node graph PTZ");
			return;
		};

		let mut widgets = vec![
			NumberInput::new(Some(graph_fade_artwork_percentage))
				.percentage()
				.display_decimal_places(0)
				.label("Fade Artwork")
				.tooltip_description("Opacity of the graph background that covers the artwork.")
				.on_update(move |number_input: &NumberInput| {
					DocumentMessage::SetGraphFadeArtwork {
						percentage: number_input.value.unwrap_or(graph_fade_artwork_percentage),
					}
					.into()
				})
				.widget_instance(),
			Separator::new(SeparatorStyle::Unrelated).widget_instance(),
		];
		let has_selection = network_interface
			.selected_nodes_in_nested_network(breadcrumb_network_path)
			.is_some_and(|selected| selected.has_selected_nodes());
		widgets.extend(navigation_controls(node_graph_ptz, navigation_handler, true, has_selection));
		widgets.extend([
			Separator::new(SeparatorStyle::Unrelated).widget_instance(),
			TextButton::new("Node Graph")
				.icon("GraphViewOpen")
				.hover_icon("GraphViewClosed")
				.tooltip_label("Hide Node Graph")
				.tooltip_shortcut(action_shortcut!(DocumentMessageDiscriminant::GraphViewOverlayToggle))
				.on_update(move |_| DocumentMessage::GraphViewOverlayToggle.into())
				.widget_instance(),
		]);

		self.widgets[1] = LayoutGroup::row(widgets);
	}

	/// Collate the Inspector sections for a node graph
	pub fn collate_inspector_sections(context: &mut NodeInspectorContext) -> Vec<LayoutGroup> {
		// If the selected nodes are in the document network, use the document network. Otherwise, use the nested network
		let Some(selected_nodes) = context.network_interface.selected_nodes_in_nested_network(context.selection_network_path) else {
			warn!("No selected nodes in collate_inspector_sections");
			return Vec::new();
		};

		// We want:
		// - If only nodes (no layers) are selected: display each node's Inspector section
		// - If one layer is selected, and zero or more of its (primary flow) upstream nodes: display the Inspector sections for the layer and all its upstream nodes
		// - If multiple layers are selected, or one node plus other non-upstream nodes: display nothing
		// - If nothing is selected, display any pinned nodes/layers

		// First, we filter all the selections into layers and nodes
		let (mut layers, mut nodes) = (Vec::new(), Vec::new());
		for node_id in selected_nodes.selected_nodes() {
			if context.network_interface.is_layer(node_id, context.selection_network_path) {
				layers.push(*node_id);
			} else {
				nodes.push(*node_id);
			}
		}

		// The same layer/node may appear several times. Sort and dedup them for a stable ordering.
		layers.sort();
		layers.dedup();
		// Redirect dots are only bends in wires, so they have no parameters to inspect
		nodes.retain(|node_id| !context.network_interface.is_redirect_dot(node_id, context.selection_network_path));
		nodes.sort();
		nodes.dedup();

		// Next, we decide what to display based on the number of layers and nodes selected
		match *layers.as_slice() {
			// If no layers are selected, show Inspector sections for all selected nodes
			[] => {
				let selected_nodes = nodes.iter().map(|node_id| node_inspector::generate_node_inspector(*node_id, context)).collect::<Vec<_>>();
				if !selected_nodes.is_empty() {
					return selected_nodes;
				}

				// TODO: Display Inspector sections for encapsulating node when no nodes are selected in a nested network
				// This may require store a separate path for the Inspector
				// And if no nodes are selected, show Inspector sections for all pinned nodes (in the user's saved order, each draggable to reorder)
				let mut pinned_node_inspector = context
					.network_interface
					.ordered_pinned_nodes(context.selection_network_path)
					.into_iter()
					.map(|node_id| node_inspector::generate_node_inspector(node_id, context))
					.collect::<Vec<_>>();
				for pinned_section in pinned_node_inspector.iter_mut() {
					if let LayoutGroup::NodeSection(section) = pinned_section {
						section.draggable = true;
					}
				}

				// With nothing pinned either, explain what can appear here
				if pinned_node_inspector.is_empty() {
					return vec![
						LayoutGroup::row(vec![]),
						LayoutGroup::row(vec![
							Separator::new(SeparatorStyle::Unrelated).widget_instance(),
							TextLabel::new("Select layers or nodes to inspect their parameters.\nPin them for quick access when nothing is selected.")
								.multiline(true)
								.center_align(true)
								.disabled(true)
								.widget_instance(),
							Separator::new(SeparatorStyle::Unrelated).widget_instance(),
						]),
					];
				}

				pinned_node_inspector
			}
			// If one layer is selected, filter out all selected nodes that are not upstream of it. If there are no nodes left, show the Inspector section for the layer. Otherwise, show nothing.
			[layer] => {
				let nodes_not_upstream_of_layer = nodes.into_iter().filter(|&selected_node_id| {
					!context
						.network_interface
						.is_node_upstream_of_another_by_horizontal_flow(layer, context.selection_network_path, selected_node_id)
				});
				if nodes_not_upstream_of_layer.count() > 0 {
					return Vec::new();
				}

				// The layer's section, containing its chain's sections unless another input's chain is shown instead
				let mut layer_section = node_inspector::generate_node_inspector(layer, context);

				// The sections of the layer's own chain can be dragged to reorder it, except a node without a primary input (e.g. a generator)
				let expanded_input_chain = node_inspector::expanded_input_chain(&layer, context.inspector_expanded_input_chains, context.network_interface, context.selection_network_path);
				if expanded_input_chain == Some(network_interface::LAYER_SECONDARY_INPUT_INDEX)
					&& let LayoutGroup::NodeSection(section) = &mut layer_section
				{
					for layout_group in section.layout.0.iter_mut() {
						if let LayoutGroup::NodeSection(chain_section) = layout_group
							&& chain_section.output_wire.is_some()
							&& !chain_section.node_reference
						{
							chain_section.draggable = context.network_interface.has_primary_input(&NodeId(chain_section.id), context.selection_network_path);
						}
					}
				}

				// The layers this one's output feeds, which a stack used in several places can be many of, and the graph's output none of.
				// Followed through any nodes between, each layer takes it either from its bottom (as the sibling above in its stack) or into its content (as its parent).
				let network_path = context.selection_network_path;
				let outward_connectors = |node_id: NodeId| {
					context
						.network_interface
						.with_outward_wires(network_path, |outward_wires| outward_wires.get(&OutputConnector::primary_output(node_id)).cloned())
						.flatten()
						.unwrap_or_default()
				};
				let (mut siblings, mut parents) = (Vec::new(), Vec::new());
				let mut pending_connectors = outward_connectors(layer);
				let mut visited_nodes = HashSet::new();
				while let Some(connector) = pending_connectors.pop() {
					let Some(node_id) = connector.node_id() else { continue };

					if context.network_interface.is_layer(&node_id, network_path) {
						let receivers = if connector.input_index() == 0 { &mut siblings } else { &mut parents };
						receivers.push(node_id);
						continue;
					}

					// A node passes it on only when taking it as its primary input, rather than as a parameter
					if connector.input_index() == 0 && visited_nodes.insert(node_id) {
						pending_connectors.extend(outward_connectors(node_id));
					}
				}

				// Sorted for a stable button order, since outward wires are unordered
				siblings.sort_unstable();
				siblings.dedup();
				parents.sort_unstable();
				parents.dedup();

				// The layer feeding this one from below in its stack, unless this is the bottom
				let layer_below = node_inspector::input_chain(layer, 0, context.network_interface, network_path).and_then(|(_, stack_layer)| stack_layer);

				// Each is only referred to by a button, wired to the layer's section. Parents sit just above, the wire turning into their content,
				// and siblings above them, the wire continuing up past that turn into their bottom.
				let mut sections = Vec::new();

				if let Some(siblings_section) = node_inspector::layer_references_section(&siblings, "Select Sibling Layer", context) {
					sections.push(siblings_section);
				}
				if let Some(mut parents_section) = node_inspector::layer_references_section(&parents, "Select Parent Layer", context) {
					if let LayoutGroup::NodeSection(section) = &mut parents_section {
						section.content_wire = Some(node_inspector::output_section_wire(layer, context));
						section.content_wire_continues = !siblings.is_empty();
					}
					sections.push(parents_section);
				}
				if !sections.is_empty()
					&& let LayoutGroup::NodeSection(section) = &mut layer_section
				{
					section.output_wire = Some(node_inspector::output_section_wire(layer, context));
				}
				sections.push(layer_section);
				if let Some(layer_below) = layer_below
					&& let Some(mut below_section) = node_inspector::layer_references_section(&[layer_below], "Select Sibling Layer", context)
				{
					if let LayoutGroup::NodeSection(section) = &mut below_section {
						section.output_wire = Some(node_inspector::output_section_wire(layer_below, context));
					}
					sections.push(below_section);
				}

				sections
			}
			// If multiple layers and/or nodes are selected, show nothing
			_ => Vec::new(),
		}
	}

	fn collect_wires(&mut self, network_interface: &mut NodeNetworkInterface, graph_wire_style: GraphWireStyle, breadcrumb_network_path: &[NodeId]) -> Vec<WirePathUpdate> {
		let mut added_wires = network_interface
			.node_graph_input_connectors(breadcrumb_network_path)
			.iter()
			.filter_map(|connector| network_interface.newly_loaded_input_wire(connector, graph_wire_style, breadcrumb_network_path))
			.collect::<Vec<_>>();

		let changed_wire_inputs = added_wires.iter().map(|update| (update.id, update.input_index)).collect::<Vec<_>>();
		self.frontend_wires.extend(changed_wire_inputs);

		let mut orphaned_wire_inputs = self.frontend_wires.clone();
		self.frontend_wires = network_interface
			.node_graph_wire_inputs(breadcrumb_network_path)
			.iter()
			.filter_map(|visible_wire_input| orphaned_wire_inputs.take(visible_wire_input))
			.collect::<HashSet<_>>();
		added_wires.extend(orphaned_wire_inputs.into_iter().map(|(id, input_index)| WirePathUpdate {
			id,
			input_index,
			wire_path_update: None,
		}));

		if let Some(wire_to_root) = network_interface.wire_to_root(graph_wire_style, &GlideOffsets::default(), breadcrumb_network_path) {
			added_wires.push(wire_to_root);
		} else {
			added_wires.push(WirePathUpdate {
				id: NodeId(u64::MAX),
				input_index: u32::MAX as usize,
				wire_path_update: None,
			})
		}

		added_wires
	}

	pub(crate) fn collect_nodes(&self, network_interface: &mut NodeNetworkInterface, breadcrumb_network_path: &[NodeId]) -> Vec<FrontendNode> {
		let Some(network) = network_interface.nested_network(breadcrumb_network_path) else {
			log::error!("Could not get nested network when collecting nodes");
			return Vec::new();
		};
		let mut nodes = Vec::new();
		for (node_id, visible) in network.nodes.iter().map(|(node_id, node)| (*node_id, node.visible)).collect::<Vec<_>>() {
			let primary_input_connector = InputConnector::primary_input(node_id);

			let primary_input = if network_interface
				.input_from_connector(&primary_input_connector, breadcrumb_network_path)
				.is_some_and(|input| input.is_exposed())
			{
				network_interface.frontend_input_from_connector(&primary_input_connector, breadcrumb_network_path)
			} else {
				None
			};
			let exposed_inputs = (1..network_interface.number_of_inputs(&node_id, breadcrumb_network_path))
				.filter_map(|input_index| network_interface.frontend_input_from_connector(&InputConnector::node_at_index(node_id, input_index), breadcrumb_network_path))
				.collect();

			let primary_output = network_interface.frontend_output_from_connector(&OutputConnector::primary_output(node_id), breadcrumb_network_path);

			let exposed_outputs = (1..network_interface.number_of_outputs(&node_id, breadcrumb_network_path))
				.filter_map(|output_index| network_interface.frontend_output_from_connector(&OutputConnector::node(node_id, output_index), breadcrumb_network_path))
				.collect();
			let (primary_output_connected_to_layer, primary_input_connected_to_layer) = if network_interface.is_layer(&node_id, breadcrumb_network_path) {
				(
					network_interface.primary_output_connected_to_layer(&node_id, breadcrumb_network_path),
					network_interface.primary_input_connected_to_layer(&node_id, breadcrumb_network_path),
				)
			} else {
				(false, false)
			};

			let Some(position) = network_interface.position(&node_id, breadcrumb_network_path) else {
				log::error!("Could not get position for node: {node_id}");
				continue;
			};
			let is_export = network_interface
				.input_from_connector(&InputConnector::Export(0), breadcrumb_network_path)
				.is_some_and(|export| export.as_node().is_some_and(|export_node_id| node_id == export_node_id));
			let is_root_node = network_interface.root_node(breadcrumb_network_path).is_some_and(|root_node| root_node.node_id == node_id);
			let previewed = is_export && !is_root_node;

			let locked = network_interface.is_locked(&node_id, breadcrumb_network_path);

			nodes.push(FrontendNode {
				id: node_id,
				is_layer: network_interface
					.node_metadata(&node_id, breadcrumb_network_path)
					.is_some_and(|node_metadata| node_metadata.persistent_metadata.is_layer()),
				can_be_layer: network_interface.is_eligible_to_be_layer(&node_id, breadcrumb_network_path),
				is_redirect_dot: network_interface.is_redirect_dot(&node_id, breadcrumb_network_path),
				reference: network_interface.reference(&node_id, breadcrumb_network_path).map(|reference| reference.serialized()),
				display_name: network_interface.display_name(&node_id, breadcrumb_network_path),
				implementation_name: network_interface.implementation_name(&node_id, breadcrumb_network_path),
				primary_input,
				exposed_inputs,
				primary_output,
				exposed_outputs,
				primary_output_connected_to_layer,
				primary_input_connected_to_layer,
				position: position.into(),
				previewed,
				visible,
				locked,
			});
		}

		nodes
	}

	fn collect_subgraph_names(network_interface: &mut NodeNetworkInterface, breadcrumb_network_path: &[NodeId]) -> Option<Vec<String>> {
		let mut current_network_path = vec![];
		let mut current_network = network_interface.nested_network(&current_network_path).unwrap();
		let mut subgraph_names = vec!["Document".to_string()];
		for node_id in breadcrumb_network_path {
			let node = current_network.nodes.get(node_id)?;
			if let Some(network) = node.implementation.get_network() {
				current_network = network;
			};
			subgraph_names.push(network_interface.display_name(node_id, &current_network_path));
			current_network_path.push(*node_id)
		}
		Some(subgraph_names)
	}

	fn node_graph_errors(&self, network_interface: &mut NodeNetworkInterface, breadcrumb_network_path: &[NodeId]) -> Vec<NodeGraphErrorDiagnostic> {
		let depth = breadcrumb_network_path.len();
		let inside = |path: &[NodeId]| path.starts_with(breadcrumb_network_path) && path.len() > depth;
		let graph_errors: Vec<_> = network_interface
			.resolved_types
			.node_graph_errors
			.iter()
			.filter(|error| inside(&error.node_path))
			.map(|error| match error.node_path.len() == depth + 1 {
				true => (error.node_path[depth], format!("{:?}", error.error)),
				false => (error.node_path[depth], "Node graph type error within this node".to_string()),
			})
			.collect();
		// Evaluation errors come from the last graph that compiled, so a type error hides them
		let errors = match graph_errors.is_empty() {
			true => self
				.evaluation_errors
				.iter()
				.filter(|error| inside(&error.node_path))
				.map(|error| match error.node_path.len() == depth + 1 {
					true => (error.node_path[depth], error.message.clone()),
					false => (error.node_path[depth], "Node graph error within this node".to_string()),
				})
				.collect(),
			false => graph_errors,
		};

		let mut shown = HashSet::new();
		errors
			.into_iter()
			.filter(|(node, _)| shown.insert(*node))
			.filter_map(|(node, error)| {
				let mut position = network_interface.position(&node, breadcrumb_network_path)?;
				// Convert to graph space
				position *= 24;
				if network_interface.is_layer(&node, breadcrumb_network_path) {
					position += IVec2::new(12, -12)
				}
				Some(NodeGraphErrorDiagnostic {
					node_id: node,
					position: position.into(),
					error,
				})
			})
			.collect()
	}

	/// Sends the Layers panel the details of the given layers, which it needs only for the rows it has in view.
	// O(given layers × nesting depth), apart from what the active tool would edit in the selected layers
	fn update_layer_panel(
		layers: impl IntoIterator<Item = NodeId>,
		network_interface: &NodeNetworkInterface,
		selection_network_path: &[NodeId],
		layers_panel_open: bool,
		tool_edit_target: &EditTarget,
		expanded_chains: &[NodeId],
		responses: &mut VecDeque<Message>,
	) {
		if !layers_panel_open {
			return;
		}

		// What the active tool would edit in each layer it can edit
		let tool_targets = network_interface
			.selected_nodes()
			.selected_visible_and_unlocked_layers(network_interface)
			.filter_map(|layer| Some((layer.to_node(), tool_edit_target.resolve(layer, network_interface)?)))
			.collect::<HashMap<_, _>>();

		let selected_layers = network_interface
			.selected_nodes()
			.selected_layers(network_interface.document_metadata())
			.map(|layer| layer.to_node())
			.collect::<HashSet<_>>();
		let selected_nodes = network_interface.selected_nodes().selected_nodes().copied().collect::<HashSet<_>>();
		let edited_nodes = network_interface.transaction_edited_nodes();

		let node_metadata = &network_interface.document_network_metadata().persistent_metadata.node_metadata;
		for node_id in layers {
			// The Layers panel may still list a layer that has since been deleted
			if node_metadata.get(&node_id).is_some_and(|metadata| metadata.persistent_metadata.is_layer()) {
				let layer = LayerNodeIdentifier::new(node_id, network_interface);

				let descendant_of_selected = layer
					.ancestors(network_interface.document_metadata())
					.skip(1)
					.filter(|ancestor| *ancestor != LayerNodeIdentifier::ROOT_PARENT)
					.any(|ancestor| selected_layers.contains(&ancestor.to_node()));

				let children_allowed =
						// The layer has other layers as children along the secondary input's horizontal flow
						layer.has_children(network_interface.document_metadata())
						|| (
							// Check if the last node in the chain has an exposed left input
							network_interface.upstream_flow_back_from_nodes(vec![node_id], &[], network_interface::FlowType::HorizontalFlow).last().is_some_and(|node_id|
								network_interface.document_node(&node_id, &[]).map_or_else(||{log::error!("Could not get node {node_id} in update_layer_panel"); false}, |node| {
									if network_interface.is_layer(&node_id, &[]) {
										node.inputs.iter().filter(|input| input.is_exposed()).nth(1).is_some_and(|input| input.as_value().is_some())
									} else {
										node.inputs.iter().filter(|input| input.is_exposed()).nth(0).is_some_and(|input| input.as_value().is_some())
									}
								}))
						);

				let clippable = layer.can_be_clipped(network_interface.document_metadata()) && network_interface.layer_hosts_blending_nodes(&node_id, &[]);

				let tool_target = tool_targets.get(&node_id);
				let description_if_outlined = |node: NodeId| tool_target.filter(|target| target.outlined_node() == Some(node)).map(|target| target.tooltip_description().to_string());
				let tool_target_insertion = match tool_target {
					Some(target @ ResolvedEditTarget::Inserted { definition, index }) => Some(LayerPanelChainInsertion {
						index: *index as u32,
						icon: resolve_document_node_type(definition).and_then(|definition| definition.icon).unwrap_or("NodeCustomNode").to_string(),
						name: definition.implementation_name_from_identifier(),
						description: target.tooltip_description().to_string(),
					}),
					_ => None,
				};

				// Listed left to right as in the graph
				let chain_nodes = network_interface
					.layer_chain_nodes(node_id, &[])
					.into_iter()
					.rev()
					.map(|chain_node_id| LayerPanelChainNode {
						id: chain_node_id,
						icon: network_interface.node_icon(&chain_node_id, &[]).to_string(),
						name: network_interface.display_name(&chain_node_id, &[]),
						implementation_name: network_interface.implementation_name(&chain_node_id, &[]),
						selected: selected_nodes.contains(&chain_node_id),
						reorderable: network_interface.has_primary_input(&chain_node_id, &[]),
						visible: network_interface.is_visible(&chain_node_id, &[]),
						tool_target_description: description_if_outlined(chain_node_id),
						edit_in_progress: edited_nodes.contains(&chain_node_id),
					})
					.collect::<Vec<_>>();

				let data = LayerPanelEntry {
					id: node_id,
					implementation_name: network_interface.implementation_name(&node_id, &[]),
					icon_name: network_interface.node_icon(&node_id, &[]).to_string(),
					chain_nodes,
					chain_expanded: expanded_chains.contains(&node_id),
					tool_target_description: description_if_outlined(node_id),
					edit_in_progress: edited_nodes.contains(&node_id),
					tool_target_insertion,
					alias: network_interface.display_name(&node_id, &[]),
					in_selected_network: selection_network_path.is_empty(),
					children_allowed,
					visible: network_interface.is_visible(&node_id, &[]),
					unlocked: !network_interface.is_locked(&node_id, &[]),
					selected: selected_layers.contains(&node_id),
					descendant_of_selected,
					clipped: get_clip_mode(layer, network_interface).unwrap_or(false) && clippable,
					clippable,
				};
				responses.add(FrontendMessage::UpdateDocumentLayerDetails { data });
			}
		}
	}

	fn update_node_graph_hints(&self, responses: &mut VecDeque<Message>) {
		// A wire is in progress and its start and end connectors are set
		let wiring = self.wire_in_progress_from_connector.is_some();

		// Node dragging is in progress (having already moved at least one pixel from the mouse down position)
		let dragging_nodes = self.drag_start.as_ref().is_some_and(|(_, dragged)| *dragged);

		// A box selection is in progress
		let dragging_box_selection = self.box_selection_start.is_some_and(|(_, box_selection_dragged)| box_selection_dragged);

		// An import or export is being dragged to a new position
		let reordering_import_export = self.is_reordering_import_export() && self.end_index.is_some();

		// Cancel the ongoing action
		if wiring || dragging_nodes || dragging_box_selection || reordering_import_export {
			HintData(vec![HintGroup(vec![HintInfo::mouse(MouseMotion::Rmb, ""), HintInfo::keys([Key::Escape], "Cancel").prepend_slash()])]).send_layout(responses);
			return;
		}

		// Default hints for all other states
		let mut hint_data = HintData(vec![
			HintGroup(vec![HintInfo::mouse(MouseMotion::Rmb, "Add Node")]),
			HintGroup(vec![HintInfo::mouse(MouseMotion::Lmb, "Select Node"), HintInfo::keys([Key::Shift], "Extend").prepend_plus()]),
			HintGroup(vec![
				HintInfo::mouse(MouseMotion::LmbDrag, "Select Area"),
				HintInfo::keys([Key::Shift], "Extend").prepend_plus(),
				HintInfo::keys([Key::Alt], "Subtract").prepend_plus(),
				HintInfo::keys([Key::Control], "Exclude Layers").prepend_plus(),
			]),
		]);
		if self.has_selection {
			hint_data.0.extend([
				HintGroup(vec![HintInfo::mouse(MouseMotion::LmbDrag, "Drag Selected")]),
				HintGroup(vec![
					HintInfo::keys([Key::Backspace], "Delete Selected"),
					HintInfo::keys([Key::Control], "Keep Children").prepend_plus(),
				]),
				HintGroup(vec![
					HintInfo::keys_and_mouse([Key::Alt], MouseMotion::LmbDrag, "Move Duplicate"),
					HintInfo::keys([Key::Control, Key::KeyD], "Duplicate").add_mac_keys([Key::Command, Key::KeyD]),
				]),
			]);
		}
		hint_data.0.extend([
			HintGroup(vec![HintInfo::mouse(MouseMotion::LmbDouble, "Enter Node Subgraph")]),
			HintGroup(vec![HintInfo::keys_and_mouse([Key::Alt], MouseMotion::Lmb, "Preview Node Output")]),
			HintGroup(vec![HintInfo::mouse(MouseMotion::MmbDrag, "Pan Graph"), HintInfo::keys([Key::Alt], "Pan Artwork").prepend_plus()]),
		]);
		hint_data.send_layout(responses);
	}
}

impl Default for NodeGraphMessageHandler {
	fn default() -> Self {
		Self {
			network: Vec::new(),
			has_selection: false,
			widgets: [LayoutGroup::row(Vec::new()), LayoutGroup::row(Vec::new())],
			drag_start: None,
			begin_dragging: false,
			nodes_added_in_drag: false,
			node_has_moved_in_drag: false,
			latest_left_press: None,
			double_click_used_by_press: false,
			dot_drag_out: None,
			shift_without_push: false,
			box_selection_start: None,
			drag_start_chain_nodes: Vec::new(),
			wire_insertion_preview: None,
			hovered_connector: None,
			selection_before_pointer_down: Vec::new(),
			disconnecting: None,
			initial_disconnecting: false,
			select_if_not_dragged: None,
			wire_in_progress_from_connector: None,
			wire_in_progress_to_connector: None,
			wire_in_progress_type: FrontendGraphDataType::General,
			wire_in_progress_from_new_import: None,
			wire_in_progress_from_input: None,
			wire_in_progress_from_new_export: None,
			wire_hovered_node: None,
			wire_expanded_node: None,
			wire_hover_tick_subscribed: false,
			glide_network_path: Vec::new(),
			glide_last_tick_time: None,
			glide_tick_subscribed: false,
			context_menu: None,
			deselect_on_pointer_up: None,
			auto_panning: Default::default(),
			preview_on_mouse_up: None,
			reordering_export: None,
			reordering_import: None,
			end_index: None,
			frontend_nodes: Vec::new(),
			frontend_wires: HashSet::new(),
			evaluation_errors: Vec::new(),
		}
	}
}

impl PartialEq for NodeGraphMessageHandler {
	fn eq(&self, other: &Self) -> bool {
		self.network == other.network
			&& self.has_selection == other.has_selection
			&& self.widgets == other.widgets
			&& self.drag_start == other.drag_start
			&& self.begin_dragging == other.begin_dragging
			&& self.nodes_added_in_drag == other.nodes_added_in_drag
			&& self.node_has_moved_in_drag == other.node_has_moved_in_drag
			&& self.latest_left_press == other.latest_left_press
			&& self.double_click_used_by_press == other.double_click_used_by_press
			&& self.dot_drag_out == other.dot_drag_out
			&& self.box_selection_start == other.box_selection_start
			&& self.initial_disconnecting == other.initial_disconnecting
			&& self.select_if_not_dragged == other.select_if_not_dragged
			&& self.wire_in_progress_from_connector == other.wire_in_progress_from_connector
			&& self.wire_in_progress_to_connector == other.wire_in_progress_to_connector
			&& self.wire_in_progress_from_new_import == other.wire_in_progress_from_new_import
			&& self.wire_in_progress_from_input == other.wire_in_progress_from_input
			&& self.wire_in_progress_from_new_export == other.wire_in_progress_from_new_export
			&& self.context_menu == other.context_menu
	}
}

/// A press of the left mouse button in the graph, kept to tell whether the next press is the second of a double-click.
#[derive(Debug, Clone, Copy, PartialEq)]
struct LeftPress {
	/// When the press was made, in milliseconds.
	time: f64,
	/// Where the press was made, in viewport space.
	position: DVec2,
	/// Whether this press was itself the second of a double-click, which ends that run of clicks.
	is_double: bool,
	/// Whether the press was released where it was made, as a click that a second press can make a double-click.
	is_click: bool,
}

impl LeftPress {
	/// Whether a press made at this time and place is the second of a double-click begun by this press.
	fn continued_by(&self, time: f64, position: DVec2) -> bool {
		// Desktop times presses that pass through the browser on another clock, so a negative gap counts as too long
		let soon_after = (0. ..=DOUBLE_CLICK_MILLISECONDS as f64).contains(&(time - self.time));
		self.is_click && !self.is_double && soon_after && self.position.distance(position) <= DOUBLE_CLICK_ALLOWED_TRAVEL
	}
}

/// The connector a redirect dot is dragged out of, and so the wires the dot takes over.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum DotDragOutSource {
	/// The wires leaving the output that a dot can bend, which then fan out from the dot.
	Output(OutputConnector),
	/// The wire into the export.
	Export(usize),
}

/// The message adding the export that a dimmed connector for adding one stands in for at `export_index`, where index 0 is the empty primary.
fn add_export_at(export_index: usize) -> NodeGraphMessage {
	if export_index == 0 {
		NodeGraphMessage::AddPrimaryExport
	} else {
		NodeGraphMessage::AddSecondaryExport
	}
}
