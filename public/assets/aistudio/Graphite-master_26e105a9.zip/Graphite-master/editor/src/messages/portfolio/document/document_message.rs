use std::path::PathBuf;
use std::sync::Arc;

use super::utility_types::misc::{GroupFolderType, SnappingState};
use crate::messages::input_mapper::utility_types::keyboard::Key;
use crate::messages::portfolio::document::data_panel::DataPanelMessage;
use crate::messages::portfolio::document::overlays::utility_types::{OverlayContext, OverlaysType};
use crate::messages::portfolio::document::utility_types::document_metadata::LayerNodeIdentifier;
use crate::messages::portfolio::document::utility_types::misc::{AlignAggregate, AlignAxis, FlipAxis, GridSnapping};
use crate::messages::portfolio::document::utility_types::network_interface::{ChainNodeCopy, NodeTemplate};
use crate::messages::portfolio::utility_types::PanelType;
use crate::messages::prelude::*;
use glam::{DAffine2, IVec2, UVec2};
use graph_craft::document::NodeId;
use graphene_std::Appearance;
use graphene_std::list::Item;
use graphene_std::raster::BlendMode;
use graphene_std::transform::Footprint;
use graphene_std::vector::Vector;
use graphene_std::vector::click_target::ClickTarget;
use graphene_std::vector::style::RenderMode;

#[impl_message(Message, PortfolioMessage, Document)]
#[derive(derivative::Derivative, Clone, serde::Serialize, serde::Deserialize)]
#[derivative(Debug, PartialEq)]
pub enum DocumentMessage {
	Noop,
	// Sub-messages
	#[child]
	GraphOperation(GraphOperationMessage),
	#[child]
	Navigation(NavigationMessage),
	#[child]
	NodeGraph(NodeGraphMessage),
	#[child]
	Overlays(OverlaysMessage),
	#[child]
	Inspector(InspectorMessage),
	#[child]
	DataPanel(DataPanelMessage),
	#[child]
	Resource(ResourceMessage),

	// Messages
	AlignSelectedLayers {
		axis: AlignAxis,
		aggregate: AlignAggregate,
	},
	RemoveArtboards,
	ClearLayersPanel,
	CreateEmptyFolder,
	DeleteNode {
		node_id: NodeId,
	},
	DeleteSelectedLayers,
	DeselectAllLayers,
	DocumentHistoryBackward,
	DocumentHistoryForward,
	DocumentStructureChanged,
	DrawArtboardOverlays {
		context: OverlayContext,
	},
	DuplicateSelectedLayers,
	DuplicateSelectedLayersTo {
		parent: LayerNodeIdentifier,
		insert_index: usize,
	},
	EnterNestedNetwork {
		node_id: NodeId,
	},
	Escape,
	ExitNestedNetwork {
		steps_back: usize,
	},
	FlipSelectedLayers {
		flip_axis: FlipAxis,
	},
	RotateSelectedLayers {
		degrees: f64,
	},
	GraphViewOverlay {
		open: bool,
	},
	GraphViewOverlayToggle,
	GridOptions {
		options: GridSnapping,
	},
	GridOverlays {
		context: OverlayContext,
	},
	GridVisibility {
		visible: bool,
	},
	LayersPanelHoverOverlays {
		context: OverlayContext,
	},
	BlendSelectedLayers,
	MorphSelectedLayers,
	ExpandFillStrokeOnSelectedLayers,
	ExpandFillStrokeOnSelectedLayersNoTransaction,
	GroupSelectedLayers {
		group_folder_type: GroupFolderType,
	},
	MoveSelectedLayersTo {
		parent: LayerNodeIdentifier,
		insert_index: usize,
	},
	ReorderInspectorSection {
		node_id: NodeId,
		insert_index: usize,
		duplicate: bool,
	},
	MoveChainNodes {
		node_ids: Vec<NodeId>,
		layer: NodeId,
		insert_index: usize,
	},
	DuplicateChainNodes {
		node_ids: Vec<NodeId>,
		layer: NodeId,
		insert_index: usize,
		select_copies: bool,
	},
	PasteChainNodes {
		copies: Vec<ChainNodeCopy>,
	},
	PasteNodes {
		nodes: Vec<(NodeId, NodeTemplate)>,
	},
	MoveSelectedLayersToGroup {
		parent: LayerNodeIdentifier,
	},
	NudgeSelectedLayers {
		delta_x: f64,
		delta_y: f64,
		resize: Key,
		resize_opposite: Key,
	},
	InsertImage {
		name: Option<String>,
		data: Arc<[u8]>,
		size: UVec2,
		mouse: Option<(f64, f64)>,
		parent_and_insert_index: Option<(LayerNodeIdentifier, usize)>,
		/// When true (file-open flow), place the image at the document origin so `WrapContentInArtboard`
		/// can wrap it without a content Transform node. When false, place at the cursor or viewport center.
		place_at_origin: bool,
	},
	InsertSvg {
		name: Option<String>,
		svg: String,
		mouse: Option<(f64, f64)>,
		parent_and_insert_index: Option<(LayerNodeIdentifier, usize)>,
		/// When true (file-open flow), place the SVG at the document origin so `WrapContentInArtboard`
		/// can wrap it without a content Transform node. When false, place at the cursor or viewport center.
		place_at_origin: bool,
	},
	Redo,
	RenameDocument {
		new_name: String,
	},
	RenderRulers,
	RenderScrollbars,
	SaveDocument,
	SaveDocumentAs,
	SavedDocument {
		path: Option<PathBuf>,
	},
	MarkAsSaved,
	SelectParentLayer,
	SelectAllLayers,
	SelectedLayersLower,
	SelectedLayersLowerToBack,
	SelectedLayersRaise,
	SelectedLayersRaiseToFront,
	SelectedLayersReverse,
	SelectedLayersReorder {
		relative_index_offset: isize,
	},
	ClipLayer {
		id: NodeId,
	},
	SelectLayer {
		id: NodeId,
		ctrl: bool,
		shift: bool,
	},
	SelectChainNode {
		layer: NodeId,
		node_id: NodeId,
		ctrl: bool,
		shift: bool,
	},
	SetActivePanel {
		active_panel: PanelType,
	},
	SetBlendModeForSelectedLayers {
		blend_mode: BlendMode,
	},
	SetGraphFadeArtwork {
		percentage: f64,
	},
	/// Renames a layer in the network the node graph is showing, which may be a subgraph.
	SetLayerNameInGraph {
		node_id: NodeId,
		name: String,
	},
	SetLayersPanelHoveredLayer {
		id: Option<NodeId>,
	},
	/// The layers with a row in view in the Layers panel, and among them those it lacks the details of, which it's sent.
	SetLayersPanelView {
		layers: Vec<NodeId>,
		layers_missing_details: Vec<NodeId>,
	},
	SetNodePinned {
		node_id: NodeId,
		pinned: bool,
	},
	SetOpacityForSelectedLayers {
		opacity: f64,
	},
	SetFillForSelectedLayers {
		fill: f64,
	},
	SetOverlaysVisibility {
		visible: bool,
		overlays_type: Option<OverlaysType>,
	},
	SetRangeSelectionLayer {
		new_layer: Option<LayerNodeIdentifier>,
	},
	SetSnapping {
		#[serde(skip)]
		#[derivative(Debug = "ignore", PartialEq = "ignore")]
		closure: Option<for<'a> fn(&'a mut SnappingState) -> &'a mut bool>,
		snapping_state: bool,
	},
	SetSnappingAngleStep {
		degrees: f64,
	},
	SetToNodeOrLayer {
		node_id: NodeId,
		is_layer: bool,
	},
	SetRenderMode {
		render_mode: RenderMode,
	},
	ShowNodeInGraph {
		node_id: NodeId,
	},
	ShowSelectionInGraph,
	AddTransaction,
	StartTransaction,
	EndTransaction,
	CommitTransaction,
	CancelTransaction,
	AbortTransaction,
	RepeatedAbortTransaction {
		undo_count: usize,
	},
	ToggleLayerExpansion {
		tree_path: Vec<NodeId>,
		recursive: bool,
	},
	ToggleNodeInspectorSectionExpanded {
		node_id: NodeId,
		recursive: bool,
	},
	ToggleNodeInspectorInputChain {
		node_id: NodeId,
		input_index: usize,
	},
	ToggleLayerChainExpanded {
		layer_id: NodeId,
	},
	/// Hides or shows a node in the network holding the selection, which may be a subgraph.
	ToggleNodeVisibility {
		node_id: NodeId,
	},
	ToggleSelectedVisibility,
	ToggleSelectedLocked,
	ToggleGridVisibility,
	ToggleOverlaysVisibility,
	ToggleSnapping,
	UpdateUpstreamTransforms {
		upstream_footprints: HashMap<NodeId, Footprint>,
		local_transforms: HashMap<NodeId, DAffine2>,
		first_element_source_id: HashMap<NodeId, Option<NodeId>>,
		document_to_viewport: DAffine2,
	},
	UpdateClickTargets {
		click_targets: HashMap<NodeId, Vec<Arc<ClickTarget>>>,
		group_layers: HashSet<NodeId>,
	},
	UpdateOutlines {
		outlines: HashMap<NodeId, Vec<Arc<ClickTarget>>>,
	},
	UpdateTextFrames {
		text_frames: HashMap<NodeId, DAffine2>,
	},
	UpdateClipTargets {
		clip_targets: HashSet<NodeId>,
	},
	// `Message` is only serialized at `editor_wrapper.rs`, and only inputs from JS pass through it.
	// `UpdateVectorData` and `UpdateAppearanceAttributes` are produced inside `editor.handle_message` by `node_graph_executor.rs` and consumed in the same dispatch loop, so they never reach that serialization point.
	#[serde(skip)]
	UpdateVectorData {
		vector_data: HashMap<NodeId, Arc<Item<Vector>>>,
	},
	#[serde(skip)]
	UpdateAppearanceAttributes {
		appearance_attributes: HashMap<NodeId, Arc<Appearance>>,
	},
	Undo,
	UngroupSelectedLayers,
	UngroupLayer {
		layer: LayerNodeIdentifier,
	},
	PTZUpdate,
	SelectionStepBack,
	SelectionStepForward,
	WrapContentInArtboard {
		place_artboard_at_origin: bool,
		/// When `Some`, use this canvas (origin, dimensions) for the artboard instead of measuring the content bounding box.
		/// The origin comes from the SVG viewBox's min-x/min-y values and the dimensions from its width/height.
		artboard_canvas: Option<(IVec2, IVec2)>,
	},
	ZoomCanvasTo100Percent,
	ZoomCanvasTo200Percent,
	ZoomCanvasToFitAll,
}
