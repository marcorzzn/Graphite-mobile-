use crate::messages::frontend::IconName;
use crate::messages::input_mapper::utility_types::misc::ActionShortcut;
use crate::messages::layout::utility_types::widget_prelude::*;
use crate::messages::portfolio::document::node_graph::utility_types::FrontendGraphDataType;
use crate::messages::tool::tool_messages::tool_prelude::WidgetCallback;
use derivative::*;
use graphene_std::color::SRGBA8;
use graphene_std::vector::style::FillChoice;
use graphite_proc_macros::WidgetBuilder;

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Default, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct IconButton {
	// Content
	#[widget_builder(constructor)]
	#[widget_builder(string)]
	pub icon: IconName,
	#[serde(rename = "hoverIcon")]
	pub hover_icon: Option<String>,
	#[widget_builder(constructor)]
	pub size: u32, // TODO: Convert to an `IconSize` enum
	pub disabled: bool,

	// Styling
	pub emphasized: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Drag and drop
	#[serde(rename = "dragDropKinds")]
	pub drag_drop_kinds: DragDropKinds,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<IconButton>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_drag_drop: WidgetCallback<IconButton>,
}

/// What can be dragged in the Layers panel and dropped onto an icon button to perform its `on_drag_drop` action.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum DragDropKinds {
	/// Nothing, so the button isn't a drop target.
	#[default]
	None,
	/// Layers.
	Layers,
	/// Layers, or the nodes in a layer's chain.
	LayersAndChainNodes,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct PopoverButton {
	// Content
	pub style: Option<String>,
	#[widget_builder(string)]
	pub icon: Option<IconName>,
	pub disabled: bool,

	// Children
	#[serde(rename = "popoverLayout")]
	pub popover_layout: Layout,
	#[serde(rename = "popoverMinWidth")]
	pub popover_min_width: Option<u32>,
	#[serde(rename = "menuDirection")]
	pub menu_direction: Option<MenuDirection>,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Default, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum MenuDirection {
	Top,
	#[default]
	Bottom,
	Left,
	Right,
	TopLeft,
	TopRight,
	BottomLeft,
	BottomRight,
	Center,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, Default, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct ParameterExposeButton {
	// Content
	pub exposed: bool,
	#[serde(rename = "dataType")]
	pub data_type: FrontendGraphDataType,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<ParameterExposeButton>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

/// A parameter's name, for an input fed by a chain of nodes, that shows or hides that chain's sections within its node's Inspector section.
#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, Default, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct ParameterChainToggle {
	// Content
	#[widget_builder(constructor)]
	pub name: String,
	pub expanded: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<ParameterChainToggle>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, Default, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct TextButton {
	// Content
	#[widget_builder(constructor)]
	pub label: String,
	#[widget_builder(string)]
	pub icon: Option<IconName>,
	#[serde(rename = "hoverIcon")]
	pub hover_icon: Option<String>,
	pub disabled: bool,

	// Children
	#[serde(rename = "menuListChildren")]
	pub menu_list_children: MenuListEntrySections,
	#[serde(rename = "menuListChildrenHash")]
	#[widget_builder(skip)]
	pub menu_list_children_hash: u64,

	// Styling
	pub emphasized: bool,
	pub flush: bool,
	pub narrow: bool,
	pub sizing: WidgetSizing,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<TextButton>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, Default, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct ImageButton {
	// Content
	#[widget_builder(constructor)]
	pub image: String,
	pub width: Option<String>,
	pub height: Option<String>,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<()>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, Derivative, serde::Serialize, serde::Deserialize, WidgetBuilder)]
#[derivative(Debug, PartialEq, Default)]
pub struct ColorInput {
	// Content
	#[widget_builder(constructor)]
	pub value: FillChoice<SRGBA8>,
	/// Straight-alpha color samples drawn by the frontend as the stops of an SVG gradient filling the swatch. Auto-populated from `value` at layout-send time.
	/// Empty when `value` is `FillChoice::<SRGBA8>::None`, in which case the frontend uses its "none" fallback styling.
	#[serde(rename = "swatchSamples")]
	#[widget_builder(skip)]
	pub swatch_samples: Vec<GradientSample>,
	#[serde(rename = "allowNone")]
	#[derivative(Default(value = "true"))]
	pub allow_none: bool,
	// #[serde(rename = "allowTransparency")] pub allow_transparency: bool, // TODO: Implement
	#[serde(rename = "menuDirection")]
	pub menu_direction: Option<MenuDirection>,
	pub disabled: bool,
	pub mixed: bool,

	// Styling
	pub narrow: bool,
	pub sizing: WidgetSizing,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<ColorInput>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}

/// Shortens a breadcrumb label to fit the trail, replacing the tail with an ellipsis.
/// Quotes delimit a string value, so a quoted label budgets only the text between them.
pub fn truncate_breadcrumb_label(label: &str) -> String {
	const MAX_CHARACTERS: usize = 40;

	let quoted = label.len() >= 2 && label.starts_with('"') && label.ends_with('"');
	let content = if quoted { &label[1..label.len() - 1] } else { label };

	if content.chars().count() <= MAX_CHARACTERS {
		return label.to_string();
	}

	let mut truncated: String = content.chars().take(MAX_CHARACTERS - 1).collect();
	truncated.push('…');

	if quoted { format!("\"{truncated}\"") } else { truncated }
}

#[cfg_attr(feature = "wasm", derive(tsify::Tsify))]
#[derive(Clone, serde::Serialize, serde::Deserialize, Derivative, Default, WidgetBuilder)]
#[derivative(Debug, PartialEq)]
pub struct BreadcrumbTrailButtons {
	// Content
	#[widget_builder(constructor)]
	pub labels: Vec<String>,
	pub disabled: bool,

	// Tooltips
	#[serde(rename = "tooltipLabel")]
	pub tooltip_label: String,
	#[serde(rename = "tooltipDescription")]
	pub tooltip_description: String,
	#[serde(rename = "tooltipShortcut")]
	pub tooltip_shortcut: Option<ActionShortcut>,

	// Callbacks
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_update: WidgetCallback<u64>,
	#[serde(skip)]
	#[derivative(Debug = "ignore", PartialEq = "ignore")]
	pub on_commit: WidgetCallback<()>,
}
