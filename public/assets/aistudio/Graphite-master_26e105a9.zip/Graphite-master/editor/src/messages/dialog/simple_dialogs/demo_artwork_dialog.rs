use crate::messages::layout::utility_types::widget_prelude::*;
use crate::messages::prelude::*;

/// A dialog to let the user browse a gallery of demo artwork that can be opened.
pub struct DemoArtworkDialog;

/// `(name, thumbnail, filename)`
pub const ARTWORK: [(&str, &str, &str); 7] = [
	("Isometric Fountain", "ThumbnailIsometricFountain", "isometric-fountain.graphite"),
	("Changing Seasons", "ThumbnailChangingSeasons", "changing-seasons.graphite"),
	("Painted Dreams", "ThumbnailPaintedDreams", "painted-dreams.graphite"),
	("Parametric Dunescape", "ThumbnailParametricDunescape", "parametric-dunescape.graphite"),
	("Red Dress", "ThumbnailRedDress", "red-dress.graphite"),
	("Procedural String Lights", "ThumbnailProceduralStringLights", "procedural-string-lights.graphite"),
	("Valley of Spires", "ThumbnailValleyOfSpires", "valley-of-spires.graphite"),
];

impl DialogLayoutHolder for DemoArtworkDialog {
	const ICON: &'static str = "Image";
	const TITLE: &'static str = "Demo Artwork";

	fn layout_buttons(&self) -> Layout {
		let widgets = vec![TextButton::new("Close").emphasized(true).on_update(|_| FrontendMessage::DialogClose.into()).widget_instance()];

		Layout(vec![LayoutGroup::row(widgets)])
	}
}

impl LayoutHolder for DemoArtworkDialog {
	fn layout(&self) -> Layout {
		let mut rows_of_images_with_buttons: Vec<_> = ARTWORK
			.chunks(4)
			.flat_map(|chunk| {
				fn make_dialog(name: &str, filename: &str) -> Message {
					DialogMessage::CloseAndThen {
						followups: vec![
							FrontendMessage::TriggerFetchAndOpenDocument {
								name: name.to_string(),
								filename: filename.to_string(),
							}
							.into(),
						],
					}
					.into()
				}

				let images = chunk
					.iter()
					.map(|(name, thumbnail, filename)| ImageButton::new(*thumbnail).width("256px").on_update(|_| make_dialog(name, filename)).widget_instance())
					.collect();

				let buttons = chunk
					.iter()
					.map(|(name, _, filename)| {
						TextButton::new(*name)
							.sizing(WidgetSizing::default().min_width(256))
							.flush(true)
							.on_update(|_| make_dialog(name, filename))
							.widget_instance()
					})
					.collect();

				vec![LayoutGroup::row(images), LayoutGroup::row(buttons), LayoutGroup::row(vec![])]
			})
			.collect();
		let _ = rows_of_images_with_buttons.pop();

		Layout(rows_of_images_with_buttons)
	}
}
