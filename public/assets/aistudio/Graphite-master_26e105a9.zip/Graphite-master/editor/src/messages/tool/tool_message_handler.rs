use super::common_functionality::shape_editor::ShapeState;
use super::common_functionality::shapes::shape_utility::ShapeType::{Ellipse, Line, Rectangle};
use super::common_functionality::snap_session::SnapSession;
use super::utility_types::{ToolActionMessageContext, ToolFsmState, tool_message_to_tool_type};
use crate::application::generate_uuid;
use crate::messages::layout::utility_types::widget_prelude::*;
use crate::messages::portfolio::document::overlays::utility_types::OverlayProvider;
use crate::messages::prelude::*;
use crate::messages::tool::common_functionality::edit_target::EditTarget;
use crate::messages::tool::transform_layer::transform_layer_message_handler::TransformLayerMessageContext;
use crate::messages::tool::utility_types::{HintData, ToolType};
use crate::node_graph_executor::NodeGraphExecutor;
use graphene_std::color::SRGBA8;
use graphene_std::raster::color::Color;

const ARTBOARD_OVERLAY_PROVIDER: OverlayProvider = |context| DocumentMessage::DrawArtboardOverlays { context }.into();
const SNAPPING_OVERLAY_PROVIDER: OverlayProvider = |context| ToolMessage::DrawSnappingOverlays { context }.into();

#[derive(ExtractField)]
pub struct ToolMessageContext<'a> {
	pub document_id: DocumentId,
	pub document: &'a mut DocumentMessageHandler,
	pub input: &'a InputPreprocessorMessageHandler,
	pub fonts: &'a FontsMessageHandler,
	pub node_graph: &'a NodeGraphExecutor,
	pub preferences: &'a PreferencesMessageHandler,
	pub viewport: &'a ViewportMessageHandler,
}

#[derive(Debug, Default, ExtractField)]
pub struct ToolMessageHandler {
	pub tool_state: ToolFsmState,
	pub transform_layer_handler: TransformLayerMessageHandler,
	pub shape_editor: ShapeState,
	pub snap_session: SnapSession,
	/// Whether the snapping session is being sent a tick on every animation frame, which it only asks for while the pointer rests on something it could wake.
	snapping_ticks: bool,
	pub tool_is_active: bool,
	/// What the active tool would edit in the selected layers, as last shown in the Layers panel.
	pub edit_target: EditTarget,
}

impl ToolMessageHandler {
	fn handle_message(&mut self, message: ToolMessage, responses: &mut VecDeque<Message>, context: ToolMessageContext) {
		let ToolMessageContext {
			document_id,
			document,
			input,
			fonts,
			node_graph,
			preferences,
			viewport,
		} = context;

		match message {
			// Messages
			ToolMessage::TransformLayer(message) => {
				let context = TransformLayerMessageContext {
					document,
					document_id,
					input,
					tool_data: &self.tool_state.tool_data,
					shape_editor: &mut self.shape_editor,
					snap_session: &mut self.snap_session,
					viewport,
				};
				self.transform_layer_handler.process_message(message, responses, context);

				self.keep_snapping_ticks_as_wanted(responses);
			}

			ToolMessage::ActivateToolSelect => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Select }),
			ToolMessage::ActivateToolArtboard => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Artboard }),
			ToolMessage::ActivateToolNavigate => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Navigate }),
			ToolMessage::ActivateToolEyedropper => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Eyedropper }),
			ToolMessage::ActivateToolText => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Text }),
			ToolMessage::ActivateToolFill => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Fill }),
			ToolMessage::ActivateToolGradient => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Gradient }),

			ToolMessage::ActivateToolPath => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Path }),
			ToolMessage::ActivateToolPen => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Pen }),
			ToolMessage::ActivateToolFreehand => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Freehand }),
			ToolMessage::ActivateToolSpline => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Spline }),
			ToolMessage::ActivateToolShape => {
				if self.tool_state.tool_data.active_shape_type.is_some() {
					self.tool_state.tool_data.active_shape_type = None;
					self.tool_state.tool_data.active_tool_type = ToolType::Shape;
				}
				responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Shape });
				// Sync current_shape with the dropdown selection (options.shape_type)
				responses.add(ShapeToolMessage::SyncShapeWithOptions);
				responses.add(ShapeToolMessage::HideShapeTypeWidget { hide: false })
			}
			ToolMessage::ActivateToolBrush => responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Brush }),
			ToolMessage::ActivateToolShapeLine | ToolMessage::ActivateToolShapeRectangle | ToolMessage::ActivateToolShapeEllipse => {
				let shape = match message {
					ToolMessage::ActivateToolShapeLine => Line,
					ToolMessage::ActivateToolShapeRectangle => Rectangle,
					ToolMessage::ActivateToolShapeEllipse => Ellipse,
					_ => unreachable!(),
				};

				self.tool_state.tool_data.active_shape_type = Some(shape.tool_type());
				responses.add_front(ToolMessage::ActivateTool { tool_type: ToolType::Shape });
				responses.add(ShapeToolMessage::HideShapeTypeWidget { hide: true });
				responses.add(ShapeToolMessage::SetShape { shape });
			}
			ToolMessage::ActivateTool { tool_type } => {
				let tool_data = &mut self.tool_state.tool_data;
				let old_tool = tool_data.active_tool_type.get_tool();
				let tool_type = tool_type.get_tool();

				responses.add(ToolMessage::RefreshToolOptions);
				responses.add(ToolMessage::RefreshToolShelf);

				// Do nothing if switching to the same tool
				if self.tool_is_active && tool_type == old_tool {
					return;
				}

				if tool_type != ToolType::Shape {
					tool_data.active_shape_type = None;
				}

				self.tool_is_active = true;

				// Send the old and new tools a transition to their FSM Abort states
				let mut send_abort_to_tool = |old_tool: ToolType, new_tool: ToolType, update_hints_and_cursor: bool| {
					if let Some(tool) = tool_data.tools.get_mut(&new_tool) {
						let mut data = ToolActionMessageContext {
							document,
							document_id,
							global_tool_data: &self.tool_state.document_tool_data,
							input,
							shape_editor: &mut self.shape_editor,
							snap_session: &mut self.snap_session,
							node_graph,
							preferences,
							viewport,
							fonts,
						};

						if let Some(tool_abort_message) = tool.event_to_message_map().tool_abort {
							tool.process_message(tool_abort_message, responses, &mut data);
						}

						if update_hints_and_cursor {
							if self.transform_layer_handler.is_transforming() {
								self.transform_layer_handler.hints(responses);
							} else {
								tool.process_message(ToolMessage::UpdateHints, responses, &mut data);
							}
							tool.process_message(ToolMessage::UpdateCursor, responses, &mut data);
						}
					}

					// If a G/R/S transform is active while using Path, Select, Pen, or Shape,
					// and the user switches to a different tool, cancel the current transform
					// operation to avoid leaving it in an inconsistent state
					if matches!(old_tool, ToolType::Path | ToolType::Select | ToolType::Pen | ToolType::Shape) {
						responses.add(TransformLayerMessage::CancelTransformOperation);
					}
				};

				// The old tool goes first so it can finish its edit before the new tool's abort, which also leaves the new tool's hints and cursor showing
				send_abort_to_tool(old_tool, old_tool, false);
				send_abort_to_tool(old_tool, tool_type, true);

				// Nothing a tool was snapping, or had woken, carries over to the next tool
				self.snap_session.end_gesture();
				self.snap_session.sleep_all();

				// Unsubscribe old tool from the broadcaster
				tool_data.tools.get(&old_tool).unwrap().deactivate(responses);

				// Store the new active tool
				tool_data.active_tool_type = tool_type;

				// Subscribe new tool
				tool_data.tools.get(&tool_type).unwrap().activate(responses);

				// Re-add the artboard overlay provider when tools are reactivated
				responses.add(OverlaysMessage::AddProvider { provider: ARTBOARD_OVERLAY_PROVIDER });
				responses.add(OverlaysMessage::AddProvider { provider: SNAPPING_OVERLAY_PROVIDER });

				// Re-subscribe the transform layer to selection change events, which `DeactivateTools` also unsubscribes
				responses.add(BroadcastMessage::SubscribeEvent {
					on: EventMessage::SelectionChanged,
					send: Box::new(TransformLayerMessage::SelectionChanged.into()),
				});

				// Send the SelectionChanged message to the active tool, this will ensure the selection is updated
				responses.add(EventMessage::SelectionChanged);

				// Update the working colors for the active tool
				responses.add(EventMessage::WorkingColorChanged);

				// Send tool options to the frontend
				responses.add(ToolMessage::RefreshToolOptions);
			}
			ToolMessage::DeactivateTools => {
				let tool_data = &mut self.tool_state.tool_data;
				tool_data.tools.get(&tool_data.active_tool_type).unwrap().deactivate(responses);
				self.release_snapping(responses);

				// Unsubscribe the transform layer to selection change events
				responses.add(BroadcastMessage::UnsubscribeEvent {
					on: EventMessage::SelectionChanged,
					send: Box::new(TransformLayerMessage::SelectionChanged.into()),
				});

				responses.add(OverlaysMessage::RemoveProvider { provider: ARTBOARD_OVERLAY_PROVIDER });
				responses.add(OverlaysMessage::RemoveProvider { provider: SNAPPING_OVERLAY_PROVIDER });

				HintData::clear_layout(responses);
				responses.add(FrontendMessage::UpdateMouseCursor { cursor: Default::default() });

				self.tool_is_active = false;
			}
			ToolMessage::InitTools => {
				// Subscribe the transform layer to selection change events
				responses.add(BroadcastMessage::SubscribeEvent {
					on: EventMessage::SelectionChanged,
					send: Box::new(TransformLayerMessage::SelectionChanged.into()),
				});

				responses.add(BroadcastMessage::SubscribeEvent {
					on: EventMessage::SelectionChanged,
					send: Box::new(SelectToolMessage::SyncHistory.into()),
				});

				self.tool_is_active = true;
				self.release_snapping(responses);

				let tool_data = &mut self.tool_state.tool_data;
				let document_data = &self.tool_state.document_tool_data;
				let active_tool = &tool_data.active_tool_type;

				// Subscribe tool to broadcast messages
				tool_data.tools.get(active_tool).unwrap().activate(responses);

				// Register initial properties
				tool_data.tools.get(active_tool).unwrap().refresh_options(responses);

				// Notify the frontend about the initial active tool
				tool_data.send_layout(responses, LayoutTarget::ToolShelf, preferences.brush_tool);

				// Notify the frontend about the initial working colors
				document_data.update_working_colors(responses);

				let mut data = ToolActionMessageContext {
					document,
					document_id,
					global_tool_data: &self.tool_state.document_tool_data,
					input,
					shape_editor: &mut self.shape_editor,
					snap_session: &mut self.snap_session,
					node_graph,
					preferences,
					viewport,
					fonts,
				};

				// Set initial hints and cursor
				tool_data.active_tool_mut().process_message(ToolMessage::UpdateHints, responses, &mut data);
				tool_data.active_tool_mut().process_message(ToolMessage::UpdateCursor, responses, &mut data);

				responses.add(OverlaysMessage::AddProvider { provider: ARTBOARD_OVERLAY_PROVIDER });
				responses.add(OverlaysMessage::AddProvider { provider: SNAPPING_OVERLAY_PROVIDER });
			}
			ToolMessage::DrawSnappingOverlays { mut context } => self.snap_session.draw_overlays(document, &mut context),
			ToolMessage::SnappingTick => {
				if self.snap_session.tick(input.time) {
					responses.add(OverlaysMessage::Draw);
				}
				self.keep_snapping_ticks_as_wanted(responses);
			}
			ToolMessage::RefreshToolOptions => {
				let tool_data = &mut self.tool_state.tool_data;

				tool_data.tools.get(&tool_data.active_tool_type).unwrap().refresh_options(responses);
			}
			ToolMessage::RefreshToolShelf => {
				let tool_data = &mut self.tool_state.tool_data;
				tool_data.send_layout(responses, LayoutTarget::ToolShelf, preferences.brush_tool);
			}
			ToolMessage::ResetColors => {
				let document_data = &mut self.tool_state.document_tool_data;

				document_data.primary_color = Color::BLACK;
				document_data.secondary_color = Color::WHITE;

				document_data.update_working_colors(responses); // TODO: Make this an event
			}
			ToolMessage::SelectRandomWorkingColor { primary } => {
				// Select a random working color (RGBA) based on an UUID
				let document_data = &mut self.tool_state.document_tool_data;

				let random_number = generate_uuid();
				let r = (random_number >> 16) as u8;
				let g = (random_number >> 8) as u8;
				let b = random_number as u8;
				let random_color = Color::from(SRGBA8::new(r, g, b, 255));

				if primary {
					document_data.primary_color = random_color;
				} else {
					document_data.secondary_color = random_color;
				}

				document_data.update_working_colors(responses); // TODO: Make this an event
			}
			ToolMessage::SelectWorkingColor { color, primary } => {
				let document_data = &mut self.tool_state.document_tool_data;

				if primary {
					document_data.primary_color = color;
				} else {
					document_data.secondary_color = color;
				}

				document_data.update_working_colors(responses); // TODO: Make this an event
			}
			ToolMessage::ToggleSelectVsPath => {
				// If we have the select tool active, toggle to the path tool and vice versa
				let tool_data = &mut self.tool_state.tool_data;
				let active_tool_type = tool_data.active_tool_type;
				if active_tool_type == ToolType::Select {
					responses.add(ToolMessage::ActivateTool { tool_type: ToolType::Path });
				} else {
					responses.add(ToolMessage::ActivateTool { tool_type: ToolType::Select });
				}
			}
			ToolMessage::SwapColors => {
				let document_data = &mut self.tool_state.document_tool_data;

				std::mem::swap(&mut document_data.primary_color, &mut document_data.secondary_color);

				document_data.update_working_colors(responses); // TODO: Make this an event
			}

			// Sub-messages
			tool_message => {
				let tool_type = match &tool_message {
					ToolMessage::UpdateCursor | ToolMessage::UpdateHints => self.tool_state.tool_data.active_tool_type,
					tool_message => tool_message_to_tool_type(tool_message),
				};
				let tool_data = &mut self.tool_state.tool_data;

				if let Some(tool) = tool_data.tools.get_mut(&tool_type) {
					let graph_view_overlay_open = document.graph_view_overlay_open();

					if tool_type == tool_data.active_tool_type {
						let mut data = ToolActionMessageContext {
							document,
							document_id,
							global_tool_data: &self.tool_state.document_tool_data,
							input,
							shape_editor: &mut self.shape_editor,
							snap_session: &mut self.snap_session,
							node_graph,
							preferences,
							viewport,
							fonts,
						};
						if matches!(tool_message, ToolMessage::UpdateHints) {
							if graph_view_overlay_open {
								// When graph view is open, forward the hint update to the node graph handler
								responses.add(NodeGraphMessage::UpdateHints);
							} else if self.transform_layer_handler.is_transforming() {
								self.transform_layer_handler.hints(responses);
							} else {
								tool.process_message(ToolMessage::UpdateHints, responses, &mut data)
							}
						} else {
							tool.process_message(tool_message, responses, &mut data);
						}
					}
				}

				self.keep_snapping_ticks_as_wanted(responses);
			}
		}
	}

	/// Updates the node the Layers panel outlines as edited by the active tool, which changes with the tool and its state.
	fn refresh_edit_target(&mut self, responses: &mut VecDeque<Message>) {
		// Tools are deactivated while the graph is open, so they edit nothing then
		let edit_target = if self.tool_is_active {
			self.tool_state.tool_data.active_tool().edit_target()
		} else {
			EditTarget::Nothing
		};

		if edit_target != self.edit_target {
			self.edit_target = edit_target;
			responses.add(NodeGraphMessage::UpdateLayerPanel);
		}
	}
}

#[message_handler_data]
impl MessageHandler<ToolMessage, ToolMessageContext<'_>> for ToolMessageHandler {
	fn process_message(&mut self, message: ToolMessage, responses: &mut VecDeque<Message>, context: ToolMessageContext) {
		// Any message may switch the tool or change its state, so the refresh follows every one, even those handled with an early return
		self.handle_message(message, responses, context);
		self.refresh_edit_target(responses);
	}

	fn actions(&self) -> ActionList {
		let mut list = actions!(ToolMessageDiscriminant;
			ActivateToolSelect,
			ActivateToolArtboard,
			ActivateToolNavigate,
			ActivateToolEyedropper,
			ActivateToolFill,
			ActivateToolGradient,

			ActivateToolPath,
			ActivateToolPen,
			ActivateToolFreehand,
			ActivateToolSpline,
			ActivateToolShapeLine,
			ActivateToolShapeRectangle,
			ActivateToolShapeEllipse,
			ActivateToolShape,
			ActivateToolText,

			ToggleSelectVsPath,

			SelectRandomWorkingColor,
			ResetColors,
			SwapColors,
		);
		list.extend(self.tool_state.tool_data.active_tool().actions());
		list.extend(self.transform_layer_handler.actions());

		list
	}
}

impl ToolMessageHandler {
	/// Lets go of what the snapping session holds and has woken, so none of it carries over while the tools are off or into another document.
	fn release_snapping(&mut self, responses: &mut VecDeque<Message>) {
		self.snap_session.end_gesture();
		self.snap_session.sleep_all();
		self.keep_snapping_ticks_as_wanted(responses);
	}

	/// Starts or stops the ticks sent to the snapping session on each animation frame, to match whether it has any use for them.
	fn keep_snapping_ticks_as_wanted(&mut self, responses: &mut VecDeque<Message>) {
		let wanted = self.snap_session.wants_ticks();
		if wanted == self.snapping_ticks {
			return;
		}
		self.snapping_ticks = wanted;

		let (on, send) = (EventMessage::AnimationFrame, Box::new(ToolMessage::SnappingTick.into()));
		if wanted {
			responses.add(BroadcastMessage::SubscribeEvent { on, send });
		} else {
			responses.add(BroadcastMessage::UnsubscribeEvent { on, send });
		}
	}

	pub fn actions_with_preferences(&self, preferences: &PreferencesMessageHandler) -> ActionList {
		let mut list = self.actions();

		if preferences.brush_tool {
			list.extend(actions!(ToolMessageDiscriminant;
				ActivateToolBrush,
			));
		}

		list
	}
}
