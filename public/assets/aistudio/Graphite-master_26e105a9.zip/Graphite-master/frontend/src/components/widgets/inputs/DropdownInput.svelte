<script lang="ts">
	import { createEventDispatcher, onDestroy } from "svelte";
	import MenuList from "/src/components/floating-menus/MenuList.svelte";
	import LayoutRow from "/src/components/layout/LayoutRow.svelte";
	import IconLabel from "/src/components/widgets/labels/IconLabel.svelte";
	import TextLabel from "/src/components/widgets/labels/TextLabel.svelte";
	import { openDropdownMenuCount } from "/src/stores/dropdown-menus";
	import { widgetSizingStyles } from "/src/utility-functions/widgets";
	import type { MenuListEntry, ActionShortcut, WidgetSizing } from "/wrapper/pkg/graphite_wasm_wrapper";

	const DASH_ENTRY: MenuListEntry = {
		value: "",
		label: "-",
		icon: undefined,
		annotation: "",
		disabled: false,
		children: [],
		childrenHash: 0n,
		font: undefined,
		tooltipLabel: "",
		tooltipDescription: "",
		tooltipShortcut: undefined,
		tooltipCode: "",
	};

	const dispatch = createEventDispatcher<{ selectedIndex: number; previewIndex: number; fileDrop: File }>();

	let self: LayoutRow | undefined;

	// Content
	export let selectedIndex: number | undefined = undefined; // When not provided, a dash is displayed
	export let drawIcon = false;
	export let disabled = false;
	// Children
	export let entries: MenuListEntry[][];
	export let entriesHash: bigint | undefined = undefined;
	// Styling
	export let narrow = false;
	export let sizing: Partial<WidgetSizing> | undefined = undefined;
	export let sizedToSelection = false;
	// Behavior
	export let virtualScrolling = false;
	export let takesFileDrop = false;
	// Tooltips
	export let tooltipLabel: string | undefined = undefined;
	export let tooltipDescription: string | undefined = undefined;
	export let tooltipShortcut: ActionShortcut | undefined = undefined;

	let activeEntry = makeActiveEntry();
	let initialSelectedIndex: number | undefined = undefined;
	// The entry the open menu last previewed, until it's committed
	let previewedIndex: number | undefined = undefined;
	let open = false;
	let fileDragOver = false;
	// The width of the menu's widest entry, so the dropdown keeps one width whichever entry is chosen
	let naturalWidth = 0;
	let measuredWidth = 0;
	// When sized to its selection instead, the width it had as a menu opened
	let heldWidth: number | undefined = undefined;
	let countedAsOpen = false;

	$: watchSelectedIndex(selectedIndex);
	$: watchEntries(entries);
	$: watchOpen(open);
	$: if ($openDropdownMenuCount === 0) naturalWidth = measuredWidth;
	$: watchOpenDropdownMenuCount($openDropdownMenuCount);
	$: width = sizedToSelection ? heldWidth : naturalWidth || undefined;

	onDestroy(() => {
		if (countedAsOpen) openDropdownMenuCount.update((count) => count - 1);
	});

	function watchOpenDropdownMenuCount(count: number) {
		if (count === 0) heldWidth = undefined;
		else if (sizedToSelection && heldWidth === undefined) heldWidth = self?.div?.()?.getBoundingClientRect().width;
	}

	function watchOpen(open: boolean) {
		// A preview the menu closes on without committing goes back to the value it opened with
		if (!open) revertPreview();
		initialSelectedIndex = open ? selectedIndex : undefined;

		if (open !== countedAsOpen) {
			openDropdownMenuCount.update((count) => count + (open ? 1 : -1));
			countedAsOpen = open;
		}
	}

	// Called only when `selectedIndex` is changed from outside this component
	function watchSelectedIndex(_: typeof selectedIndex) {
		activeEntry = makeActiveEntry();
	}

	// Called only when `entries` is changed from outside this component
	function watchEntries(_: typeof entries) {
		activeEntry = makeActiveEntry();
	}

	function previewEntry(entry: MenuListEntry) {
		// Opened showing no value, there's none to go back to after a preview
		if (initialSelectedIndex === undefined) return;

		const index = entryIndex(entry);
		if (index === undefined) return;

		previewedIndex = index;
		dispatch("previewIndex", index);
	}

	function commitEntry(entry: MenuListEntry) {
		const index = entryIndex(entry);
		if (index === undefined) return;

		// Undone first, so the history step saved by the commit holds the value from before the menu opened
		revertPreview();

		activeEntry = entry;
		dispatch("selectedIndex", index);
	}

	function revertPreview() {
		if (previewedIndex !== undefined && initialSelectedIndex !== undefined && previewedIndex !== initialSelectedIndex) dispatch("previewIndex", initialSelectedIndex);
		previewedIndex = undefined;
	}

	function entryIndex(entry: MenuListEntry): number | undefined {
		const index = entries.flat().findIndex((candidate) => candidate.value === entry.value);
		if (index !== -1) return index;

		// eslint-disable-next-line no-console
		console.error("Dropdown entry not found in entries:", entry);
		return undefined;
	}

	function makeActiveEntry(): MenuListEntry {
		const allEntries = entries.flat();

		if (selectedIndex !== undefined && selectedIndex >= 0 && selectedIndex < allEntries.length) {
			return allEntries[selectedIndex];
		}
		return DASH_ENTRY;
	}

	function takesDraggedFile(e: DragEvent): boolean {
		return takesFileDrop && !disabled && Boolean(e.dataTransfer?.types.includes("Files"));
	}

	function fileDragOverWidget(e: DragEvent) {
		if (!takesDraggedFile(e)) return;

		// The browser refuses the drop unless the dragover is canceled
		e.preventDefault();
		fileDragOver = true;
	}

	function fileDragLeaveWidget(e: DragEvent) {
		// Moving between the widget's own children is not leaving it
		if (e.relatedTarget instanceof Node && self?.div?.()?.contains(e.relatedTarget)) return;

		fileDragOver = false;
	}

	function fileDropOnWidget(e: DragEvent) {
		if (!takesDraggedFile(e)) return;

		// The drop is kept from also reaching a panel that imports dropped files
		e.preventDefault();
		e.stopPropagation();
		fileDragOver = false;

		const file = e.dataTransfer?.files[0];
		if (file) dispatch("fileDrop", file);
	}
</script>

<LayoutRow
	class="dropdown-input"
	classes={{ narrow, "file-drag-over": fileDragOver }}
	styles={{
		...(width !== undefined ? { width: `${width}px` } : {}),
		...widgetSizingStyles(sizing),
	}}
	on:dragover={fileDragOverWidget}
	on:dragleave={fileDragLeaveWidget}
	on:drop={fileDropOnWidget}
	bind:this={self}
	data-dropdown-input
>
	<LayoutRow class="dropdown-box" classes={{ disabled, open }} {tooltipLabel} {tooltipDescription} {tooltipShortcut} on:click={() => !disabled && (open = true)} data-floating-menu-spawner>
		{#if activeEntry.icon}
			<IconLabel class="dropdown-icon" icon={activeEntry.icon} />
		{/if}
		<TextLabel class="dropdown-label">{activeEntry.label}</TextLabel>
		<IconLabel class="dropdown-arrow" icon="DropdownArrow" />
	</LayoutRow>
	<MenuList
		on:naturalWidth={({ detail }) => (measuredWidth = detail)}
		measuresNaturalWidth={!sizedToSelection}
		on:preview={({ detail }) => previewEntry(detail)}
		on:activeEntry={({ detail }) => commitEntry(detail)}
		on:open={({ detail }) => (open = detail)}
		{open}
		activeEntry={activeEntry === DASH_ENTRY ? undefined : activeEntry}
		{entries}
		entriesHash={entriesHash || 0n}
		{drawIcon}
		{virtualScrolling}
		holdsValue={true}
		direction="Bottom"
		scrollableY={true}
	/>
</LayoutRow>

<style lang="scss">
	.dropdown-input {
		position: relative;
		flex: 1 1 auto;
		--widget-height: 24px;

		&.narrow.narrow {
			--widget-height: 20px;
		}

		&.file-drag-over::after {
			content: "";
			position: absolute;
			inset: -4px;
			border: 1px dashed var(--color-e-nearwhite);
			border-radius: 4px;
			pointer-events: none;
		}

		.dropdown-box {
			align-items: center;
			white-space: nowrap;
			border-radius: 2px;
			background: var(--color-1-nearblack);
			height: var(--widget-height);

			.dropdown-label {
				margin: 0;
				margin-left: 8px;
				flex: 1 1 auto;
				overflow: hidden;
				text-overflow: ellipsis;
			}

			.dropdown-icon {
				margin: 4px 8px;
				flex: 0 0 auto;

				& + .dropdown-label {
					margin-left: 0;
				}
			}

			.dropdown-arrow {
				margin: 4px;
				margin-right: 2px;
				flex: 0 0 auto;
			}

			&:hover,
			&.open {
				background: var(--color-4-dimgray);
			}

			&.disabled {
				background: var(--color-2-mildblack);

				.text-label {
					color: var(--color-8-uppergray);
				}

				svg {
					fill: var(--color-8-uppergray);
				}
			}
		}

		.menu-list .floating-menu-container .floating-menu-content {
			max-height: 400px;
		}
	}

	// The row stops clipping so the file drag outline, drawn outside the dropdown, shows in full
	.widget-span.row:has(> .dropdown-input.file-drag-over) {
		overflow: visible;
	}
</style>
