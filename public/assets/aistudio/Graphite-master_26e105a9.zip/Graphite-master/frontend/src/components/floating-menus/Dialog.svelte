<script lang="ts">
	import { getContext, onMount } from "svelte";
	import FloatingMenu from "/src/components/layout/FloatingMenu.svelte";
	import LayoutCol from "/src/components/layout/LayoutCol.svelte";
	import LayoutRow from "/src/components/layout/LayoutRow.svelte";
	import TextButton from "/src/components/widgets/buttons/TextButton.svelte";
	import IconLabel from "/src/components/widgets/labels/IconLabel.svelte";
	import TextLabel from "/src/components/widgets/labels/TextLabel.svelte";
	import WidgetLayout from "/src/components/widgets/WidgetLayout.svelte";
	import type { DialogStore } from "/src/stores/dialog";
	import { crashReportUrl } from "/src/utility-functions/crash-report";
	import { wipeDocuments } from "/src/utility-functions/persistence";

	const dialog = getContext<DialogStore>("dialog");

	let self: FloatingMenu | undefined;

	onMount(() => {
		// Focus the button which is marked as emphasized, or otherwise the first button, in the dialog
		const button = self?.div?.()?.querySelector("[data-emphasized]") || self?.div?.()?.querySelector("[data-text-button]");
		const emphasizedOrFirstButton = button instanceof HTMLButtonElement ? button : undefined;
		emphasizedOrFirstButton?.focus();
	});
</script>

<!-- TODO: Use https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog for improved accessibility -->
<FloatingMenu open={true} class="dialog" type="Dialog" direction="Center" bind:this={self} data-dialog>
	<LayoutRow class="header-area">
		{#if $dialog.icon}
			<IconLabel icon={$dialog.icon} />
		{/if}
		<TextLabel>{$dialog.title}</TextLabel>
	</LayoutRow>
	<LayoutRow class={`content ${$dialog.title === "Demo Artwork" ? "center" : "" /* TODO: Replace this with a less hacky approach that's compatible with localization/translation */}`}>
		<LayoutCol class="column-1">
			{#if $dialog.column1.length > 0}
				<WidgetLayout layout={$dialog.column1} layoutTarget="DialogColumn1" class="details" />
			{/if}
			{#if $dialog.panicDetails}
				<div class="widget-layout details">
					<div class="widget-span row"><TextLabel bold={true}>The editor crashed — sorry about that</TextLabel></div>
					<div class="widget-span row"><TextLabel>Please report this by filing an issue on GitHub:</TextLabel></div>
					<div class="widget-span row"><TextButton label="Report Bug" icon="Warning" flush={true} action={() => window.open(crashReportUrl($dialog.panicDetails), "_blank")} /></div>
					<div class="widget-span row"><TextLabel multiline={true}>Reload the editor to continue. If this occurs<br />immediately on repeated reloads, clear storage:</TextLabel></div>
					<div class="widget-span row">
						<TextButton
							label="Clear Saved Documents"
							icon="Trash"
							flush={true}
							action={async () => {
								await wipeDocuments();
								window.location.reload();
							}}
						/>
					</div>
				</div>
			{/if}
		</LayoutCol>
		{#if $dialog.column2.length > 0}
			<LayoutCol class="column-2">
				<WidgetLayout layout={$dialog.column2} layoutTarget="DialogColumn2" class="details" />
			</LayoutCol>
		{/if}
	</LayoutRow>
	<LayoutRow class="footer-area">
		{#if $dialog.buttons.length > 0}
			<WidgetLayout layout={$dialog.buttons} layoutTarget="DialogButtons" class="details" />
		{/if}
		{#if $dialog.panicDetails}
			<TextButton label="Copy Error Log" action={() => navigator.clipboard.writeText($dialog.panicDetails)} />
			<TextButton label="Reload" emphasized={true} action={() => window.location.reload()} />
		{/if}
	</LayoutRow>
</FloatingMenu>

<style lang="scss">
	.dialog {
		position: absolute;
		pointer-events: none;
		width: 100%;
		height: 100%;

		> .floating-menu-container > .floating-menu-content {
			pointer-events: auto;
			padding: 0;
		}

		.header-area,
		.footer-area {
			background: var(--color-1-nearblack);
			flex: 0 0 auto;
		}

		.header-area,
		.footer-area,
		.content {
			padding: 16px 24px;
		}

		.header-area {
			border-radius: 4px 4px 0 0;

			.icon-label {
				width: 24px;
				height: 24px;

				+ .text-label {
					margin-left: 12px;
				}
			}

			.text-label {
				line-height: 24px;
			}
		}

		.content {
			margin: -4px 0;
			padding-right: calc(24px + 1px * var(--even-integer-subpixel-expansion-x));
			padding-bottom: calc(16px + 1px * var(--even-integer-subpixel-expansion-y));

			&.center .row {
				justify-content: center;
			}

			.column-1 + .column-2 {
				margin-left: 48px;

				.text-button {
					justify-content: left;
				}
			}

			.text-label.multiline {
				user-select: text;
			}

			// Used by the "Third-Party Software License Notices" dialog
			.details:has(.text-label.multiline.monospace) {
				max-height: 60vh;
				max-width: 80vw;
				overflow: auto;
			}

			// Used by the "Open Demo Artwork" dialog
			.image-label {
				border-radius: 2px;
			}
		}

		.footer-area {
			border-radius: 0 0 4px 4px;
			justify-content: right;

			.text-button {
				min-width: 96px;
			}
		}
	}
</style>
