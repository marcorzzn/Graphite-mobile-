use crate::ui::Cursor;
use crate::wrapper::Texture;
use crate::wrapper::messages::DesktopWrapperMessage;

pub(crate) enum AppEvent {
	UiUpdate(wgpu::Texture),
	CursorChange(Cursor),
	WebCommunicationInitialized,
	DesktopWrapperMessage(DesktopWrapperMessage),
	ViewportTexture(Option<Texture>),
	ClipboardRead,
	ClipboardWrite {
		content: String,
	},
	Exit,
	UiCrashed,
	OpenFiles(Vec<std::path::PathBuf>),
	#[cfg(target_os = "macos")]
	MenuEvent {
		id: String,
	},
}

#[derive(Clone)]
pub(crate) struct AppEventScheduler {
	pub(crate) proxy: winit::event_loop::EventLoopProxy,
	pub(crate) sender: std::sync::mpsc::Sender<AppEvent>,
}

impl AppEventScheduler {
	pub(crate) fn schedule(&self, event: AppEvent) {
		let _ = self.sender.send(event);
		self.proxy.wake_up();
	}
}

pub(crate) trait CreateAppEventSchedulerEventLoopExt {
	fn create_app_event_scheduler(&self, sender: std::sync::mpsc::Sender<AppEvent>) -> AppEventScheduler;
}

impl CreateAppEventSchedulerEventLoopExt for winit::event_loop::EventLoop {
	fn create_app_event_scheduler(&self, sender: std::sync::mpsc::Sender<AppEvent>) -> AppEventScheduler {
		AppEventScheduler { proxy: self.create_proxy(), sender }
	}
}
