#[cfg(target_os = "macos")]
use graphite_editor::messages::layout::utility_types::layout_widget::LayoutTarget;
use graphite_editor::messages::prelude::FrontendMessage;

use super::DesktopWrapperMessageDispatcher;
use super::messages::{DesktopFrontendMessage, IngestAction, SaveFileDialogContext};

pub(super) fn intercept_frontend_message(dispatcher: &mut DesktopWrapperMessageDispatcher, message: FrontendMessage) -> Option<FrontendMessage> {
	match message {
		FrontendMessage::RenderOverlays { context } => {
			dispatcher.respond(DesktopFrontendMessage::UpdateOverlays(context.take_scene()));
		}
		FrontendMessage::TriggerBrowse { options, action } => {
			let title = match action {
				IngestAction::Open => "Open Document",
				IngestAction::Import => "Import File",
				_ => "Select File",
			};
			dispatcher.respond(DesktopFrontendMessage::OpenFileDialog {
				title: title.to_string(),
				options,
				action,
			});
		}
		FrontendMessage::TriggerSaveDocument {
			document_id,
			name,
			path,
			folder,
			filters,
			content,
		} => {
			let content = content.into_vec();
			if let Some(path) = path {
				dispatcher.respond(DesktopFrontendMessage::WriteFile { path, content });
			} else {
				dispatcher.respond(DesktopFrontendMessage::SaveFileDialog {
					title: "Save Document".to_string(),
					default_filename: name,
					default_folder: folder,
					filters,
					context: SaveFileDialogContext::Document { document_id, content },
				});
			}
		}
		FrontendMessage::TriggerSaveFile { name, folder, filters, content } => {
			let content = content.into_vec();
			dispatcher.respond(DesktopFrontendMessage::SaveFileDialog {
				title: "Save File".to_string(),
				default_filename: name,
				default_folder: folder,
				filters,
				context: SaveFileDialogContext::File { content },
			});
		}
		FrontendMessage::TriggerVisitLink { url } => {
			dispatcher.respond(DesktopFrontendMessage::OpenUrl(url));
		}
		FrontendMessage::UpdateViewportPhysicalBounds { x, y, width, height } => {
			dispatcher.respond(DesktopFrontendMessage::UpdateViewportPhysicalBounds { x, y, width, height });
		}
		FrontendMessage::UpdateUIScale { scale } => {
			dispatcher.respond(DesktopFrontendMessage::UpdateUIScale { scale });
			return Some(FrontendMessage::UpdateUIScale { scale });
		}
		FrontendMessage::TriggerPersistenceReadState => {
			dispatcher.respond(DesktopFrontendMessage::PersistenceReadState);
		}
		FrontendMessage::TriggerPersistenceWriteState { state } => {
			dispatcher.respond(DesktopFrontendMessage::PersistenceWriteState { state });
		}
		FrontendMessage::TriggerOpenLaunchDocuments => {
			dispatcher.respond(DesktopFrontendMessage::OpenLaunchDocuments);
		}
		FrontendMessage::TriggerSavePreferences { preferences } => {
			dispatcher.respond(DesktopFrontendMessage::PersistenceWritePreferences { preferences });
		}
		FrontendMessage::TriggerLoadPreferences => {
			dispatcher.respond(DesktopFrontendMessage::PersistenceLoadPreferences);
		}
		#[cfg(target_os = "macos")]
		FrontendMessage::UpdateLayout {
			layout_target: LayoutTarget::MenuBar,
			diff,
		} => {
			use graphite_editor::messages::tool::tool_messages::tool_prelude::{DiffUpdate, WidgetDiff};
			match diff.as_slice() {
				[
					WidgetDiff {
						widget_path,
						new_value: DiffUpdate::Layout(layout),
					},
				] if widget_path.is_empty() => {
					let entries = crate::utils::menu::convert_menu_bar_layout_to_menu_items(layout);
					dispatcher.respond(DesktopFrontendMessage::UpdateMenu { entries });
				}
				_ => {}
			}
		}
		FrontendMessage::TriggerClipboardRead => {
			dispatcher.respond(DesktopFrontendMessage::ClipboardRead);
		}
		FrontendMessage::TriggerClipboardWrite { content } => {
			dispatcher.respond(DesktopFrontendMessage::ClipboardWrite { content });
		}
		FrontendMessage::WindowPointerLock => {
			dispatcher.respond(DesktopFrontendMessage::PointerLock);
		}
		FrontendMessage::WindowUpdateDirectInput { enabled } => {
			dispatcher.respond(DesktopFrontendMessage::WindowUpdateDirectInput { enabled });
		}
		FrontendMessage::WindowClose => {
			dispatcher.respond(DesktopFrontendMessage::WindowClose);
		}
		FrontendMessage::WindowMinimize => {
			dispatcher.respond(DesktopFrontendMessage::WindowMinimize);
		}
		FrontendMessage::WindowMaximize => {
			dispatcher.respond(DesktopFrontendMessage::WindowMaximize);
		}
		FrontendMessage::WindowFullscreen => {
			dispatcher.respond(DesktopFrontendMessage::WindowFullscreen);
		}
		FrontendMessage::WindowDrag => {
			dispatcher.respond(DesktopFrontendMessage::WindowDrag);
		}
		FrontendMessage::WindowFocus => {
			dispatcher.respond(DesktopFrontendMessage::WindowFocus);
		}
		FrontendMessage::WindowHide => {
			dispatcher.respond(DesktopFrontendMessage::WindowHide);
		}
		FrontendMessage::WindowHideOthers => {
			dispatcher.respond(DesktopFrontendMessage::WindowHideOthers);
		}
		FrontendMessage::WindowShowAll => {
			dispatcher.respond(DesktopFrontendMessage::WindowShowAll);
		}
		FrontendMessage::WindowRestart => {
			dispatcher.respond(DesktopFrontendMessage::Restart);
		}
		FrontendMessage::TriggerDisplayThirdPartyLicensesDialog => {
			dispatcher.respond(DesktopFrontendMessage::LoadThirdPartyLicenses);
		}
		m => return Some(m),
	}
	None
}
