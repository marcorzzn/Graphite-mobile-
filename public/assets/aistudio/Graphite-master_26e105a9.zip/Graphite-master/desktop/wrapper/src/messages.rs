use graphite_editor::messages::prelude::FrontendMessage;
use std::path::PathBuf;

pub(crate) use graphite_editor::messages::prelude::Message as EditorMessage;

pub use graphite_editor::messages::frontend::utility_types::{DocumentInfo, FileDialogOptions, FileFilter, PersistedState};
pub use graphite_editor::messages::input_mapper::utility_types::keyboard::{Key, ModifierKeys};
pub use graphite_editor::messages::input_mapper::utility_types::pointer::{EditorPointerState, MouseKeys, ScrollDelta};
pub use graphite_editor::messages::portfolio::ingest::utility_types::IngestAction;
pub use graphite_editor::messages::prelude::DocumentId;
pub use graphite_editor::messages::prelude::InputPreprocessorMessage as InputMessage;
pub use graphite_editor::messages::prelude::PreferencesMessageHandler as Preferences;

pub enum DesktopFrontendMessage {
	ToWeb(Vec<FrontendMessage>),
	OpenLaunchDocuments,
	OpenFileDialog {
		title: String,
		options: FileDialogOptions,
		action: IngestAction,
	},
	SaveFileDialog {
		title: String,
		default_filename: String,
		default_folder: Option<PathBuf>,
		filters: Vec<FileFilter>,
		context: SaveFileDialogContext,
	},
	WriteFile {
		path: PathBuf,
		content: Vec<u8>,
	},
	OpenUrl(String),
	UpdateViewportPhysicalBounds {
		x: f64,
		y: f64,
		width: f64,
		height: f64,
	},
	UpdateUIScale {
		scale: f64,
	},
	WindowUpdateDirectInput {
		enabled: bool,
	},
	UpdateOverlays(vello::Scene),
	PersistenceWritePreferences {
		preferences: Preferences,
	},
	PersistenceLoadPreferences,
	PersistenceWriteState {
		state: PersistedState,
	},
	PersistenceReadState,
	UpdateMenu {
		entries: Vec<MenuItem>,
	},
	ClipboardRead,
	ClipboardWrite {
		content: String,
	},
	PointerLock,
	WindowClose,
	WindowMinimize,
	WindowMaximize,
	WindowFullscreen,
	WindowDrag,
	WindowFocus,
	WindowHide,
	WindowHideOthers,
	WindowShowAll,
	Restart,
	LoadThirdPartyLicenses,
}

pub enum DesktopWrapperMessage {
	FromWeb(Box<EditorMessage>),
	Wake,
	Input(InputMessage),
	IngestFile { path: PathBuf, content: Vec<u8>, action: IngestAction },
	SaveFileDialogResult { path: PathBuf, context: SaveFileDialogContext },
	UpdateMaximized { maximized: bool },
	UpdateFullscreen { fullscreen: bool },
	LoadPersistedState { state: PersistedState },
	LoadPreferences { preferences: Preferences },
	MenuEvent { id: String },
	ClipboardReadResult { content: Option<String> },
	PointerLockMove { x: f64, y: f64 },
	LoadThirdPartyLicenses { text: String },
}

pub enum SaveFileDialogContext {
	Document { document_id: DocumentId, content: Vec<u8> },
	File { content: Vec<u8> },
}

pub enum MenuItem {
	Action {
		id: String,
		text: String,
		enabled: bool,
		shortcut: Option<Shortcut>,
	},
	Checkbox {
		id: String,
		text: String,
		enabled: bool,
		shortcut: Option<Shortcut>,
		checked: bool,
	},
	SubMenu {
		id: String,
		text: String,
		enabled: bool,
		items: Vec<MenuItem>,
	},
	Separator,
}

pub use keyboard_types::{Code as KeyCode, Modifiers};
pub struct Shortcut {
	pub key: KeyCode,
	pub modifiers: Modifiers,
}
